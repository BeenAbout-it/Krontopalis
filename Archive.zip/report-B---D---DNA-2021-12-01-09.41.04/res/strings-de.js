var de = {
    locale: "de",
    localeName: "Deutsch",
    locale_selector_title: "Angeboten in:",
    remoteConnection: {
        initializing : "Initialisiere Remoteverbindung..."
    },
    connectDialog: {
        title: "Verbinden Sie sich mit Ihrem Netzwerk",
        click_network_manager: "Klicken Sie __img__ oben rechts auf Ihrem Bildschirm, um verfügbare drahtlose Netzwerke anzuzeigen...",
        please_plug_wire: "Bitte verbinden Sie Ihren Computer mit einem kabelgebundenen Netzwerk.",
        dialog_will_auto_close: "Dieser Dialog wird nach erfolgreicher Netzwerkverbindung automatisch geschlossen.",
        continue_without_internet: "Sie können ohne eine aktive Internetverbindung fortfahren, allerdings wird der __product_name__ keine Updates erhalten können, welche Sie vor aktueller Schadsoftware schützen würden.",
        continue_without_metadefender_update_packages: "<br><b>MetaDefender Core hat kürzlich ein Update erhalten und muss die Dateien der Antiviren-Engine aktualisieren, um scannen zu können. Bitte verbinden Sie sich mit dem Internet, um fortzufahren.</b>",
        button_skip: "Internetverbindung überspringen",
        proxy_url_prompt: "Host:Port",
        proxy_user_prompt: "Benutzer",
        proxy_password_prompt: "Passwort",
        enter_proxy_url_dimmed: "host:port",
        enter_proxy_user_dimmed: "Nur falls erforderlich",
        button_submit_proxy_url: "Einstellen",
        proxy_setting: "Erfordert Ihr Netzwerk einen HTTP Proxy?",
        confirm_invalid_proxy_info: "Ungültige Proxy Konfiguration",
        confirm_proxy_set : "Der HTTP Proxy wurde eingerichtet.",
        confirm_proxy_removed : "Der HTTP Proxy wurde entfernt."
    },
    dialogBluetoothMouse: {
        title: "Bluetooth Maus Installation",
        message: "<span class=\"searchingBluetooth\"><B>Suche nach kabelloser Maus.</B></span><BR>Stellen Sie sicher, dass sich die Maus in einem \"erkennbaren\" Modus befindet. Sollten Sie eine kabellose Apple Maus verwenden, schalten Sie diese aus und anschließend wieder ein.  Die LED auf der Maus sollte anschließend blinken.  Bei Verwendung einer kabellosen Nicht-Apple Maus muss diese in den \"Paarungsmodus\" geschaltet werden.<BR><BR>Überprüfen Sie das Kabel bei einer kabelgebundenen Maus.<BR><BR>Sollte der __product_name__ keine Verbindung mit Ihrer Maus herstellen können, dann können Sie den Computer abschalten indem Sie den Einschalt-Knopf für 5 Sekunden lang gedrückt halten…",
        details_waiting_for_ack: "Gefundene Maus <B>__device_name__.</B>  Zum Abschluss der Paarung bitte auf <B>Fortfahren</B> klicken.  Für den Fall, dass sich der Mauszeiger nicht bewegt und eine weitere Maus verfügbar ist, hat Ihr Computer unter Umständen versucht, sich mit dieser \"falschen\" Maus zu verbinden...",
        button_ack_mouse: "Fortfahren",

    },
    dialogInputDevicesIncompatible:{
        title: "Tastatur oder Maus inkompatibel",
        message: "__product_name__ hat Schwierigkeiten, Ihre Tastatur oder Maus zu erkennen. Bitte schließen Sie eine Tastatur oder Maus an, um weiter zu scannen.<br> Wenn Sie keine kabelgebundene Tastatur oder Maus haben, halten Sie den Netzschalter 5 Sekunden lang gedrückt, um den __product_name__ zu beenden. <br> ",
        confirmed: "&nbsp; Eingabegerät gefunden! __product_name__ wird in Kürze fortgesetzt.",
        button_skip_detection: "Fortfahren"
    },
    dialogPartitionsReadOnly: {
        partitions_journaled: {
            title_all_volumes_journaled: "\"nur Scanning\" Modus",
            title_some_volumes_journaled: "Einige Laufwerke sind im \"nur Scanning\" Modus",
            message_all_volumes_journaled: "Auf allen Volumes dieses Computers ist die Aufzeichnung aktiviert. __product_name__ scannt diesen Computer. "
                + "Um jedoch zu bereinigen, müssen Sie ein Factory-Upgrade Ihres __product_name__ durchführen und anschließend den Scan neu starten. <BR> <BR>",
            message_some_volumes_journaled: "Auf einigen Volumes dieses Computers ist die Journalfunktion aktiviert. Volumes mit deaktiviertem Journal werden gescannt und gesäubert. "
                + "Volumes mit aktivierter Journalfunktion werden jedoch nur gescannt (sodass Sie zumindest feststellen können, ob der Computer infiziert ist)."
                + "Führen Sie zum Reinigen ein Factory Upgrade Ihres __product_name__ durch und starten Sie den Scan erneut. <BR> <BR>",
        },
        partitions_readonly_unclean_ntfs: {
            title: "Windows wurde nicht vollständig heruntergefahren",
            message: "Windows wurde nicht vollständig heruntergefahren. Um jegliche Gefahr von Korruption zu verhindern: <BR>"
                + "&nbsp; 1. Beenden Sie __product_name__ und starten Sie Windows neu.<BR>"
                + "&nbsp; 2. Fügen Sie __product_name__ ein und doppelklicken Sie auf <B>__product_name__.exe</B>.<BR>"
                + "&nbsp; 3. Befolgen Sie die Anweisungen auf dem Bildschirm.<BR>"
                + "Wenn aus irgendeinem Grund Windows nicht mehr neustarten kann, klicken Sie auf \"Trotzdem fortfahren\""
        }
    },
    dialogUncleanMountWarning: {
        title: "Windows wurde nicht vollständig heruntergefahren.",
        message: "Windows wurde nicht vollständig heruntergefahren.  Die Reinigung eines Computers, der nicht vollständig heruntergefahren wurde, hat ein sehr kleines Risiko, dass Korruption verursacht wird. Wenn möglich, um jegliche Gefahr von Beschädigungen zu verhindern, bitte<BR>"
                 + "&nbsp; 1. Beenden Sie __product_name__ und starten Sie Windows neu.<BR>"
                 + "&nbsp; 2. Fügen Sie __product_name__ ein und doppelklicken Sie auf <B>__product_name__.exe</B>.<BR>"
                 + "&nbsp; 3. Befolgen Sie die Anweisungen auf dem Bildschirm.<BR>"
                 + "Wenn aus irgendeinem Grund Windows nicht mehr neustarten kann, klicken Sie auf \"Weiter zur Reinigung\"",
        undo: "Windows wurde nicht vollständig heruntergefahren.  Wenn möglich, um jegliche Gefahr von Beschädigungen zu verhindern, bitte<BR>"
                 + "&nbsp; 1. Beenden Sie __product_name__ und starten Sie Windows neu.<BR>"
                 + "&nbsp; 2. Fügen Sie __product_name__ ein und doppelklicken Sie auf <B>__product_name__.exe</B>.<BR>"
                 + "&nbsp; 3. Befolgen Sie die Anweisungen auf dem Bildschirm.<BR>"
                 + "Wenn aus irgendeinem Grund Windows nicht mehr neustarten kann, klicken Sie auf \"Rückgängig machen\"",
        button_cancel: "Abbrechen",
        button_continue: "Weiter zur Reinigung",
        button_undo: "Rückgängig machen"
    },
    dialogBluetoothKeyboard: {
        title: 'Bluetooth Tastatur Installation',
        message: "<span class=\"searchingBluetooth\"><B>Suche nach schnurloser Tastatur.</B></span><BR> Stellen Sie sicher, dass sich die Tastatur in einem \"erkennbaren\" Modus befindet. Sollten Sie eine kabellose Apple Tastatur verwenden, schalten Sie diese aus und anschließend wieder ein.  Die LED auf der Tastatur sollte anschließend blinken.  Bei Verwendung einer kabellosen Nicht-Apple Tastatur, muss sich diese im \"Paarungsmodus\" befinden.<BR><BR>Überprüfen Sie das Kabel bei einer kabelgebundenen Tastatur.",
        details_waiting_for_ack: "Gefundene Tastatur <B>__device_name__.</B>  Um die Verbindung abzuschließen, geben Sie <B>\"__pin_code__\" ein</B> und drücken anschließend die <B>ENTER</B> Taste.",
        pin_acknowledged: "&nbsp; Versuch zu verbinden",
        pin_error:"Das Pairing ist fehlgeschlagen. Bitte versuchen Sie es erneut mit dem neuen Pin"
    },
    dialogInputRequired: {
        title: "Bitte drücken Sie eine Taste oder bewegen Sie Ihre Maus",
        message: "__product_name__ wartet auf Ihre Eingabe. <BR> Wenn Ihre Tastatur oder Maus nicht funktioniert, schließen Sie bitte eine kabelgebundene Tastatur oder Maus an. <BR> Wenn Sie keine kabelgebundene Tastatur oder Maus haben, halten Sie bitte die Ein- / Austaste für 5 gedrückt. Sekunden, um __product_name__ zu beenden."
    },
    dialogUsbDisconnect: {
        title: "__product_name__ USB Verbindung getrennt",
        message: "Der __product_name__ wurde aus dem USB Steckplatz entfernt. Wurde er eventuell berührt?<BR><BR>Bitte schalten Sie Ihren Computer aus indem Sie den Einschaltknopf für 5 Sekunden lang gedrückt halten und wiederholen Sie den __product_name__ Startvorgang."
    },
    dialogNotAuthorized: {
        title: "Bitte Kundensupport kontaktieren",
        not_authorized_for_pcs: "Dieser __product_name__ ist ausschließlich für Mac Computer konzipiert. Dies ist ein Windows Computer. <BR> <BR> Wenn Sie den falschen __product_name__ bestellt haben, kann unser Support-Team Ihren __product_name__ kostenlos auf Windows Computer umwandeln. Bitte senden Sie eine E-Mail an <B> support@__product_name__.com </B> Fügen Sie die Seriennummer von der Seite Ihres __product_name__ in die Anfrage ein.",
        not_authorized_for_macs: "Dieser __product_name__ ist ausschließlich für Windows Computer konzipiert. Dies ist ein Mac Computer.<BR> <BR> Wenn Sie den falschen __product_name__ bestellt haben, kann unser Support-Team Ihren __product_name__ kostenlos auf Mac Computer umwandeln. Bitte senden Sie eine E-Mail an <B> support@__product_name__.com </B> Fügen Sie die Seriennummer von der Seite Ihres __product_name__ in die Anfrage ein.",
        invalid_serial_number: "Dieser __product_name__ ist nicht zum Start autorisiert.  Sollte dieser __product_name__ in einem Hub oder einen Drucker eingesteckt sein, dann stecken Sie ihn bitte direkt in Ihren Computer und versuchen es anschließend erneut.",
        no_serial_number: "Sollte dieser __product_name__ in einem Hub oder einen Drucker eingesteckt sein, dann stecken Sie ihn bitte direkt in Ihren Computer und versuchen es anschließend erneut.",
        opswat_contact_message: "<B>Bitte senden Sie ein Ticket über unser Supportsystem unter https://portal.opswat.com/ oder kontaktieren Sie uns unter +1(415) 590-7300.</B>",
        ticket_for_support: "Ticket für Kundensupport:",
    },
    dialogNotAuthorizedEnterKey: {
        title: "__product_name__ aktivieren",
        enter_key: "Bitte Produktcode eingeben, um den __product_name__ zu aktivieren.",
        enter_key_dimmed: "Produktcode eingeben",
        button_continue: "Fortfahren",
        invalid_key: "Ungültiger Code. Bitte erneut versuchen."
    },
    dialogExpired : {
        title: "Erneuerung erforderlich",
        message: "Ihr __product_name__ Abonnement ist abgelaufen.<BR><BR>Bitte erneuern Sie Ihr Abonnement um den __product_name__ weiter verwenden zu können.<BR><BR>Eine Erneuerung des __product_name__ dauert weniger als eine Minute."
    },
    dialogDeviceCountExceeded: {
        title: "Hinzufügen von Computern zu Ihrem Abonnement",
        message: "Dieser __product_name__ wurde auf der maximalen Anzahl von Computern verwendet.",
    },
    dialogResultsInfected : {
        title: "Scan Abgeschlossen – Infektionen gefunden",
        button_clean_computer: "Computer bereinigen",
        message: "__product_name__ hat Infektionen auf Ihrem Computer gefunden.<BR><BR>(Um nur bestimmte Dateien zu bereinigen klicken Sie auf \"Resultate ansehen.\")",
    },
    dialogResultsInfectedButAllJournaled : {
        title: "Scan abgeschlossen – Infektionen gefunden",
        message: "__product_name__hat auf Ihrem Computer Infektionen festgestellt. <BR> <BR> Um die Bedrohungen zu beseitigen, beenden Sie bitte __product_name__, aktualisieren Sie Ihren __product_name__in der Fabrik und starten Sie __product_name__ neu."
    },
    dialogResultsFilevaultEmail: {
        title: "Scan abgeschlossen - Infektionen gefunden",
        messageFilevault: "__product_name__ hat Infektionen auf Ihrem Computer gefunden.<BR><BR> Da Ihre Datenträger mit FileVault verschlüsselt sind, müssen diese Bedrohungen manuell entfernt werden. Um die Bedrohungen zu säubern, bitte eine der Möglichkeiten durchführen:<BR>"
                 + "&nbsp; 1. Geben Sie Ihre E-Mail Adresse unten ein.  Anweisungen zum manuellen Entfernen werden an Ihren Posteingang gesendet.<BR>",
        messageApfs: "__product_name__ hat Infektionen auf Ihrem Computer gefunden.<BR><BR> Da Ihre Datenträger mit Apfs formatiert sind, müssen diese Bedrohungen manuell entfernt werden. Um die Bedrohungen zu säubern, bitte geben Sie Ihre E-Mail Adresse unten ein.  Anweisungen zum manuellen Entfernen werden an Ihren Posteingang gesendet.<BR><BR>",
        messageFilevaultContinued: "&nbsp; 2. Beenden Sie __product_name__, schalten Sie FileVault aus (besuchen Sie support..__product_name__.com und suchen Sie nach Anweisungen in \"FileVault\"), und starten Sie dann einen __product_name__-Scan erneut.  Hinweis: Das Ausschalten von FileVault kann mehrere Stunden dauern. <BR>",
        emailSent: "E-Mail gesendet!",
        emailFailure: "E-Mail konnte nicht gesendet werden. Überprüfen Sie die Internetverbindung und überprüfen Sie die E-Mail-Adresse.",
        failedValidation: "Email ist ungültig. Bitte versuche es erneut."
    },
    dialogResultsClean: {
        title: "Scan abgeschlossen – Keine Infektionen gefunden",
        message: "Keine Infektionen gefunden."
    },
    dialogCleaningDone: {
        title: "Bereinigung des Computers",
        action_required: "Handlung erforderlich",
        mac_readonly_message: "Einige Infektionen müssen manuell entfernt werden. Um sie manuell zu entfernen, starten Sie Ihr Mac-Betriebssystem neu, öffnen Sie den USB-Stick __product_name__ im Finder und doppelklicken Sie auf die Datei QUARANTINE",
        threats_found_but_not_cleaned:"Potenzielle Bedrohungen wurden erkannt, aber keiner wurde entfernt. Diese Bedrohungen bleiben auf Ihrem Computer.",
        partial_message: "Alle gewählten Bedrohungen wurden erfolgreich entfernt, potenzielle Bedrohungen verbleiben jedoch auf Ihrem Computer.",
        failed_message: "Die ausgewählten Bedrohungen konnten nicht entfernt werden.",
        partial_fail_message: "Einige, aber nicht alle Bedrohungen wurden erfolgreich entfernt.",
        complete_message: "Alle Infektionen wurden erfolgreich entfernt."
    },
    dialogCleaning: {
        title: "Bereinigung des Computers",
        message: "Der __product_name__ bereinigt Ihren Computer."
    },
    dialogExit: {
        title: "Verlasse __product_name__",
        message: "Ihr Computer wird heruntergefahren. Sobald er abschaltet ist entfernen Sie bitte den __product_name__ und starten führen einen Neustart durch.",
    },
    dialogExitWithInfections: {
        title: "Verlasse __product_name__",
        button_exit_anyway: "Trotzdem Beenden",
        message: 'Sollten Sie den __product_name__ jetzt verlassen, verbleibt möglicherweise bösartige Software auf Ihrem Computer.  Klicken Sie auf "Abbrechen" und anschließend "Aktionen ausführen" um die bösartigen Anwendungen zu entfernen.'
    },
    dialogConfirmUndo: {
        title: "Quarantäne rückgängig machen",
        message: "Alle Dateien, die während der Überprüfung entfernt wurden, werden auf Ihrem Computer wiederhergestellt, einschließlich möglicher Bedrohungen.",
        readonly_message: "Die meisten Elemente, die während des ausgewählten Scans entfernt wurden, werden auf Ihrem Computer wiederhergestellt, einschließlich potenzieller Bedrohungen. Einige Elemente werden nicht wiederhergestellt, da eine oder mehrere Partitionen schreibgeschützt bereitgestellt werden."
    },
    dialogConfirmUndoItem: {
        title: "Quarantäne rückgängig machen",
        message: "Dieses Object ist potenzielle Schadsoftware. Möchten Sie dennoch Ihren Rechner wieder herstellen?",
        readonly_tooltip: "Dieses Element kann nicht wiederhergestellt werden, da die Partition schreibgeschützt bereitgestellt wurde"
    },
    dialogConfirmImprovementProgram: {
        title: "Kunden verbesserungsprogramm",
        message: "Indem Sie uns erlauben, Ihnen eine E-Mail zu senden, stimmen Sie dem automatischen Senden von Diagnosedaten und potentiell schädlichen Dateien an __product_name__ Technologies Inc. zu.",
        button_ok: "E-Mail senden",
        button_cancel: "Abbrechen"
    },
    dialogRestartScan: {
        title: "Überprüfung neu starten",
        message: "Dies wird die aktuelle Überprüfung abbrechen und im Anschluss eine Neue starten."
    },
    dialogEula: {
        title: "__company_name__ Endbenutzer-Lizenzvereinbarung",
        button_accept_and_run: "Akzeptieren und starten",
        message: "Bitte lesen Sie sich die Lizenzbedingungen durch",
        improvement_program: "Automatisches Senden von Diagnosedaten und potenziell schädlichen Dateien an __company_legal_name__."
    },
    dialogDoesNotMeetMinReqs: {
        title: "Systemanforderungen",
        message: "Dieser Computer hat weniger als __min_ram__ RAM. Der __product_name__ kann daher nicht gestartet werden.",
        min_ram: "512 MB",
        min_ram_metadefender_stick: "8 GB"
    },
    dialogLinkEmail: {
        title: "Registrierung Ihres __product_name__s",
        message: "Bitte geben Sie Ihre E-Mail Adresse ein um Ihren __product_name__ zu registrieren.",
        email: "E-Mail",
        confirm_email: "Bestätigungs-E-Mail",
        name: "Name",
        first_name: "Vorname",
        last_name: "Nachname",
        registering: "Registrieren Sie Ihren __product_name__.",
        INVALID_EMAIL: "Die E-Mail Adresse ist ungültig.",
        emails_dont_match: "Die E-Mails stimmen nicht überein.",
        button_skip : "Überspringen"
    },
    dialogUnlockFilevault: {
        title: "Einige Ihrer Datenträger sind mit Filevault verschlüsselt.",
        unlocking: "Filevault Entsperren",
        message: "Bitte geben Sie unten Ihr Mac-Passwort ein. Ihr Kennwort wird verwendet, um Ihre Datenträger vorübergehend für das Scannen freizuschalten. Ihr Passwort wird nicht gespeichert.",
        metadefender_second_message: "Experimentelles Feature: Wenn das MetaDefender-Laufwerk Ihr Volume nicht entsperren kann, müssen Sie FileVault deaktivieren, um die Verarbeitung fortzusetzen. Bitte wählen Sie \"FileVault schließen\" unter Apple-Menü> Systemeinstellungen> Sicherheit und Datenschutz in der Systemsteuerung.", 
        not_all_drives_unlocked: "Einige Datenträger bleiben gesperrt. Bitte versuchen Sie ein anderes Mac-Passwort, um diese Datenträger freizuschalten.",
        could_not_unlock: "FileVault kann nicht entsperrt werden.  Bitte versuchen Sie es mit einem anderen Mac-Passwort. Hinweis: Externe Laufwerke werden derzeit nicht unterstützt.",
        password: "Mac Passwort",
        button_skip: "Überspringen"
    },
    dialogFactoryUpgradeInstructionsEmail: {
        title: "SENDE ANWEISUNGEN FÜR WERKZEUG UPGRADE",
        header: "Auf Werkseinstellungen zurücksetzen",
        stepsListPartOne: "1. Geben Sie Ihre E-Mail-Adresse ein. Anweisungen werden an Ihre E-Mail gesendet.",
        stepsListPartTwo: "2. Beenden Sie __product_name__, starten Sie Ihren Computer neu und folgen Sie den Anweisungen in der E-Mail.<BR>3. Starten Sie einen anderen Scan mit Ihrem werkseitig aktualisierten __product_name__.",
        emailSent: "E-Mail an Ihren Posteingang gesendet!",
        emailFailure: "E-Mail konnte nicht gesendet werden. Überprüfen Sie die Internetverbindung und überprüfen Sie die E-Mail-Adresse.",
        failedValidation: "Email ist ungültig. Bitte versuche es erneut.",
        button_skip: "Überspringen"
    },
    dialogSettings: {
        title: "die Einstellungen",
        button_send_instructions: "Anweisungen senden"
    },
    dialogLoadingRenewal: {
        title: "Lade Express Erneuerung"
    },
    notif : {
        take_a_break: {
            title: "Zeit für eine Pause!",
            title_metadefender: "Der Scan hat begonnen",
            message: "Diese Überprüfung kann zwischen einer und mehreren Stunden dauern.  Ein Eingriff des Benutzers wird nur am Ende des Vorgangs erfordert sein.",
            message_plug_suffix: '<BR><BR>Bitte verbinden Sie Ihren Computer mit einem Ladegerät sodass der Akku geladen bleibt.'
        },
        recovered_from_crash: {
            title: "Automatischer Neustart",
            message: "Die letzte __product_name__ Überprüfung hat einen Fehler festgestellt.  Keine Sorge... wir haben dies bemerkt und automatisch eine neue Überprüfung gestartet. Wir wollten Sie nur gerne darauf aufmerksam machen."
        },
        restored_dnsapi_dll: {
            title: "Restauriert Systemdatei",
            message: "__product_name__ erkannt und wiederhergestellt eine fehlende kritische Systemdatei namens dnsapi.dll."
        },
        restored_netfilter2_sys: {
            title: "Falsch unter Quarantäne gestellte Datei wurde wiederhergestellt",
            message: "__product_name__ hat eine falsch isolierte Datei namens netfilter2.sys erkannt und automatisch wiederhergestellt.<BR>Wenn Sie keinen Scan ausführen möchten, können Sie __product_name__ jetzt sicher beenden, indem Sie auf das X in der oberen rechten Ecke klicken."
        },
        right_click_detected: {
            title: "Benutzen Sie die rechte Maustaste?",
            message: "__product_name__ erfordert die Verwendung der linken Maustaste (auch wenn Sie Linkshänder sind ;))."
        },
        left_click: {
            title: "Tipp",
            message: "Wenn die linke Maustaste nicht funktioniert können Sie die \"Tab\" Taste verwenden bis ein Knopf ausgewählt ist und anschließend die \"Enter\" Taste drücken."
        },
        bluetooth_reconnect: {
            title: "Bluetooth Hinweis",
            message: "Es besteht kein Grund zur Sorge, sollte Ihr Computer Sie nach der Verwendung des __product_name__ dazu auffordern, Ihre Bluetooth Maus erneut zu verbinden. Dies ist ein normaler Vorgang."
        },
        device_pci: {
            title: "Nicht unterstützte Netzwerkkarte",
            message: "Bitte senden Sie eine E-Mail an support@__product_name__.com und leiten die folgenden Informationen an uns weiter, sodass wir dieses Problem beheben können.<BR>"
        },
        keyboard_layout: {
            title: "Untypische Buchstaben oder Zeichen",
            message: "Erscheinen nicht die gewünschten Buchstaben beim Schreiben?<BR>Klicken Sie auf <i class=\"fa fa-keyboard-o\" aria-hidden=\"true\"></i> um die Tastatur zu wechseln."
        },
        scan_report: {
            title: "Scanbericht erstellt",
            message: "Sehen Sie sich den Bericht im Verzeichnis 'reports' auf Ihrem __product_name__ an",
            message_meta_defender_stick: "__scan_report_path__ generiert, schauen Sie in die NTFS-Partition Ihres Geräts __product_name__, um detaillierte Scan-Ergebnisse zu erhalten!"
        },
    },
    action: {
        keep: "Beibehalten",
        quarantine: "Entfernen",
        journaled: "Factory Upgrade und erneutes Scannen zum Reinigen",
        readonly_non_journaled: "Beenden und starten von Run__product_name__.exe um zu reinigen.",
        manual_clean: "Manuell gereinigt werden müssen.<br><a href='' onclick='ShowManualCleanModal();'>Anweisungen.</a>"
    },
    time: {
        day: "__count__ Tag",
        day_plural: "__count__ Tage",
        hour: "__count__ Stunde",
        hour_plural: "__count__ Stunden",
        minute: "__count__ Minute",
        minute_plural: "__count__ Minuten",
        second: "__count__ Sekunde",
        second_plural: "__count__ Sekunden",
        ago: "Vor __time__",
        calculating: "Berechne...",
        complete : "Abgeschlossen",
        left : "verbleibend",
        several_hours: "Ein paar Stunden...",
        finishing_up: "Beenden...."
    },
    accordion: {
        scan: {
            title: "Scan",
            filevault_configuration_not_supported: "Dieser Mac verwendet eine FileVault-Konfiguration, die von __product_name__ noch nicht unterstützt wird. Mit FileVault verschlüsselte Volumes werden nicht gescannt.",
            filevault_need_to_factory_upgrade: "Ihr __product_name__ benötigt ein kostenloses, einmaliges Factory-Upgrade, um mit einer Technologie umzugehen, die Ihr Mac verwendet (FileVault).<br> Bitte <a href=\"#\" onclick='return ShowFactoryUpgradeInstructionsSendingModal(\"MAC\");'>klicken Sie hier</a>, um sich eine E-Mail über das Fabrik-Upgrade zu senden und dann einen weiteren Scan zu starten.",
            apfs_need_to_factory_upgrade: "Ihr __product_name__ benötigt ein kostenloses, einmaliges Factory-Upgrade, um mit einer Technologie umzugehen, die Ihr Mac verwendet (APFS).<br> Bitte <a href=\"#\" onclick='return ShowFactoryUpgradeInstructionsSendingModal(\"MAC\");'>klicken Sie hier</a>, um sich eine E-Mail über das Fabrik-Upgrade zu senden und dann einen weiteren Scan zu starten.",
            drive_disconnected: "Eines Ihrer Laufwerke wurde während des Scans getrennt.",
            status: {
                need_to_run_chk_disk: "Einige Ihrer Partitionen befinden sich in einem unsicheren Zustand und können nicht gescannt werden. Sie müssen einen Befehl zum Überprüfen der Festplatte unter Windows ausführen. Bitte besuchen Sie 'fixmestick.com/run-chkdsk' für Anweisungen.",
                at_least_one_partition_read_only: "Windows wurde nicht vollständig heruntergefahren. Wenn möglich, beenden Sie die __product_name__, starten Sie Windows neu, und starten Sie einen Scanvorgang mit UR__product_name__.exe.",
                at_least_one_partition_journaled: " Einige Volumes sind Journaled und können nicht gesäubert werden. Um dies zu beheben, besuchen Sie bitte unsere Website und aktualisieren Sie Ihre __product_name__.",
                encryption_detected: "Das __product_name__ ist unfähig eines zu scannen oder mehrere Ihrer BitLocker Verschlüsselungslaufwerke. Um diese Laufwerke zu scannen, starten Sie __product_name__ von Windows.",
                encryption_detected_metadefender: "Ein Volume oder mehrere Volumes sind verschlüsselt und können nicht gescannt werden. Um diese Volumes zu scannen, starten Sie bitte Windows neu und folgen Sie den Anweisungen in der Datei 'README.txt' im Ordner /tools/bitlocker in der NTFS-Partition Ihres Sticks.",
                hfs_filevault_detected: "Ein oder mehrere Datenträger werden mit einer früheren Version von Apple Filevault verschlüsselt und können nicht gescannt werden. Bitte deaktivieren Sie Filevault von macOs und starten Sie __product_name__ erneut, um diese Volumes zu überprüfen.",
                apfs_filevault_detected: "Ein oder mehrere Datenträger werden mit Apple Filevault verschlüsselt.",
                hfs_filevault_detected_metadefender: "Ein oder mehrere Datenträger werden mit einer früheren Version von Apple Filevault verschlüsselt und können nicht gescannt werden. Wählen Sie unter \"Apple-Menü\"> \"Systemeinstellungen\"> \"Sicherheit und Datenschutz\" in Ihren Steuerungsfeldern \"FileVault deaktivieren\".",
                apfs_filevault_detected_metadefender: "Ein oder mehrere Datenträger werden mit Apple Filevault verschlüsselt. <br> <br> Verschlüsselte Volumes: __encrypted_volumes__",
                safe: "Computer Status: Sicher.  ",
                safe_so_far: "Computer Status: Bis jetzt sicher.",
                safe_so_far_metadefender: "Computer Status: Prüfung läuft.",
                not_safe: "Computer Status: Gefährdet.",
                not_safe_review_when_finished: "Vorläufige Scan Resultate zeigen an, dass schädliche Dateien auf Ihrem Computer vorhanden sind. Sie können gefundene Dateien nach Abschluss der Überprüfung einsehen.",
                safe_all_infections_quarantined: "Alle Infektionen wurden entfernt.",
                throttling_too_hot: "Der Computer wird sehr heiß.  Die Überprüfung wird etwas verlangsamt, um einer Überhitzung vorzubeugen.",
                keep_cool_mode: 'Keep-Cool Modus aktiviert',
                reduced_functionality:"__product_name__ läuft im ressourcenschonenden Modus.",
                quick_scan:"__product_name__ führt ein schnelles Scannen durch"
            },
            no_files_marked_quarantine: 'Keine Dateien zum "Entfernen" markiert.',
            threats_found : "__product_name__ hat potentielle Bedrohungen auf Ihrem Computer entdeckt.",
            no_threats_found : "Gute Neuigkeiten! Während dieser Überprüfung wurden keinerlei Bedrohungen auf Ihrem Computer festgestellt.",
            scan_complete_message : "Überprüfung von __num_items__ Dateien in __time__.",
            button_apply_actions : "Aktionen anwenden",
            button_skip_updates: "Updates überspringen",
            applying_update_packages: "Anwenden von Paketen im MetaDefender Drive Update-Verzeichnis. Paket __current_package__ von __total_packages__...",
            engines_init: "Motoren initialisiert.",
            applying_update: "Aktualisierung im Gange. __product_name__ wird in Kürze erneut gestartet...",
            details :  {
                time_elapsed : "Vergangene Zeit:",
                time_remaining : "Verbleibende Zeit:",
                items_scanned : "Dateien gescannt:",
                total_items : "Gesamte Anzahl der Dateien:",
                item : "Datei:"
            },
            results:  {
                scan_results_caption : "Bedrohung(en) gefunden",
                cleaning_results_caption : "Bereinigung der Resultate",
                file : "Datei",
                file_size: "Dateigröße",
                last_modified: "Zuletzt Bearbeitet",
                threats : "Bedrohungen",
                action : "Aktion",
                result : "Resultat",
                cleaning_state: {
                    ignored: "Löschvorgang konnte nicht beendet werden.",
                    disconnected:"Laufwerk getrennt",
                    quarantined: "Entfernt",
                    disinfected: "Desinfiziert",
                    manual_clean: "Manuell gereinigt werden müssen.<br><a href='' onclick='ShowManualCleanModal();'>Anweisungen.</a>"
                }
            },
            steps: {
                checking_internet_connection: "Überprüfe<BR>Internetverbindung",
                checking_for_product_updates: "Controleren op <BR> __product_shortname__-updates",
                updating_malware_definition: "Aktualisiere<BR>Malware Definitionen",
                initializing_malware_scanners: "Initialisiere<BR>Malware Scanner",
                scanning_computer: "Überprüfe<BR>Computer",
                results: "Resultate"
            },
            steps_metadefender: {
                checking_internet_connection: "Internetverbinding controleren",
                checking_for_product_updates: "Nach<BR>__product_shortname__-Updates suchen und Lizenz überprüfen",
                updating_malware_definition: "Updaten van de definitie van malware en kwetsbaarheid",
                initializing_malware_scanners: "Initialiseren <BR> __product_shortname__",
                scanning_computer: "Scannen op <BR> Malware en kwetsbaarheid met __product_shortname__",
                results: "Resultaten"
            },
            endscan: {
                checking_startup_programs: "Startprogramme überprüfen ...",
                checking_hard_links: "Überprüfen von harten Links ...",
                checking_lnk_shortcuts: "Überprüfen von Lnk-Verknüpfungen ...",
                checking_hosts_files: "Hosts-Dateien überprüfen ...",
                waiting_on_cloud_scanner: "Warten auf Cloud Scanner ..."
            }
        },
        undo: {
            title: "Quarantäne rückgängig machen",
            success: "<B>Quarantäne erfolgreich rückgängig gemacht!</B>  Alle Dateien wurden an dem Originalspeicherort wiederhergestellt.",
            partial: "<B> Die Quarantäne wurde teilweise rückgängig gemacht. </ B> Einige Dateien wurden nicht wiederhergestellt.",
            item_success: "<B>__quarantined_item__</B> wurde auf Ihrem Computer wieder hergestellt.",
            no_quarantines: "Stellen Sie entferne Dateien einer vorherigen Überprüfung wieder her sollten Sie der Meinung sein, dass dies zu Problemen mit Ihrem Computer geführt hat.<BR><BR><B>Keine Dateien in der __product_name__ Quarantäne.</B>",
            some_quarantines: "Verwenden Sie Rückgängig machen, um entfernte Dateien einer vorherigen Prüfung wieder herzustellen, sollten Sie der Meinung sein, dass dies zu Problemen mit Ihrem Computer geführt hat.",
            table: {
                caption: "Scan Sitzung(en)",
                col_date: "Datum",
                col_items: "Dateien",
                col_action: "Aktion",
                button_undo: "Rückgängig machen",
                button_undo_item: "Die Datei wiederherstellen"
            }
        },
        custom: {
            title: "Angepasste Überprüfung",
            button_apply: "Anwenden",
            select_folders: "Wählen Sie die Festplatten und Order für die Überprüfung:",
            select_at_least_one_folder: "Bitte wählen Sie mindestens einen Ordner."
        },
        quick: {
            title: "Schnell-Scan",
            message: "Nur wenig Zeit? Der Schnell-Scan prüft nur die häufigsten Angriffsmethoden.",
            in_progress_message: "Das schnelle Scannen läuft gerade.",
            no_file: "<B>Für die besten Schnell-Scan-Resultate beenden Sie bitte __product_name__, starten Sie Ihren Computer neu und im Anschluss einen neuen Scan, indem Sie auf __product_name__.exe doppelklicken. Dadurch kann __product_name__ zusätzliche Informationen über aktive Bedrohungen auf Ihrem Computer sammeln.</B>",
            button: "Schnell-Scan starten"
        }
    },
    scan_report: {
        header: "Scanrapport",
        summary: {
            header: "Scan samenvatting:",
            scan_type: "Scan-Typ: ",
            computer_name: "Computer naam: ",
            start_time: "Scan tijd: ",
            duration: "Looptijd: ",
            app_version: "Client versie: ",
            live_os_version: "LiveOs Versie: ",
            metadefender_drive_os_version: "MetaDefender Drive OS Versie: ",
            num_files_scanned: "Totaal aantal bestanden gescand: ",
            num_malware_files: "Geïnfecteerde bestanden: ",
            num_vulnerabilities: "Sicherheitslücken insgesamt: "
        },
        definitions: {
            header: "Versies van motordefinities:",
            definition: "DB-Version: ",
            last_updated: "Letzte Aktualisierung: "
        },
        threats: {
            header_infections: "Dreigingsrapport:",
            header_vulnerabilities: "Sicherheitslücken:",
            index: "#",
            filename: "Bestandsnaam",
            size: "Bestandsgrootte",
            modified: "Laatst gewijzigd",
            threats: "Gevaren"
        }
    },
    button_continue_scan_only: "Trotzdem fortfahren.",
    button_exit_scan : "__product_name__ Verlassen",
    button_see_results : "Resultate anzeigen",
    button_ok : "OK",
    button_cancel : "Abbrechen",
    button_renew: "Express Erneuerung",
    button_retry: "Erneut versuchen",
    button_send_email: "Senden Sie eine E-Mail",
    undoing_quarantine : "Quarantäne wird rückgängig gemacht. Bitte warten Sie einen Augenblick.",
    mounting_disks : "Untersuche Festplatten. Bitte einen Moment warten...",
    jqgrid : {
        recordtext: "Zeuge {0} - {1} von {2}",
        emptyrecords: "Keine Resultate vorhanden",
        loadtext: "Lade...",
        pgtext : "Seite {0} von {1}"
    }
}

if (GetExternal().IsLocaleSupportedByUi(de.locale))
{
    arrLocalizedStrings.push(de);
}
