var jp = {
    locale: "jp",
    localeName: "日本語",
    locale_selector_title: "言語：",
    remoteConnection: {
        initializing : "リモート接続を起動中..."
    },
    connectDialog: {
        title: "ネットワークへ接続中",
        click_network_manager: "スクリーン右にある __img__ をクリックし、利用可能なワイヤレスネットワークを参照してください。",
        please_plug_wire: "有線のネットワークに接続してください。",
        dialog_will_auto_close: "接続が確立されたらこのメッセージは自動的に閉じます。",
        continue_without_internet: "インターネット接続がなくても継続はできますが、__product_name__は最新の脅威からPCを守るための最新のアップデートを更新できません。",
        continue_without_metadefender_update_packages: "<br><b>MetaDefender Coreは最近アップデートされました。スキャンするにはアンチウイルスエンジンファイルを更新する必要があります。続行するにはインターネットに接続してください。</b>",
        button_skip: "インターネット接続をスキップ",
        proxy_url_prompt: "Host:Port",
        proxy_user_prompt: "ユーザー",
        proxy_password_prompt: "パスワード",
        enter_proxy_url_dimmed: "host:port",
        enter_proxy_user_dimmed: "必要な場合のみ",
        button_submit_proxy_url: "設定",
        proxy_setting: "HTTPプロキシが必要なネットワークですか？ ",
        confirm_invalid_proxy_info: "プロキシ設定が失敗",
        confirm_proxy_set : " HTTPプロキシが設定できました。",
        confirm_proxy_removed : " HTTPプロキシが削除されました。"
    },
    dialogBluetoothMouse: {
        title: 'Bluetoothマウスの設定',
        message: "<span class=\"searchingBluetooth\"><B>ワイヤレスマウスを探しています。</B></span><BR>ワイヤレスマウスが検出可能か確認ください。Appleのワイヤレスマウスをお使いの場合は、電源をOFFにしてからONにしなおしてください。マウスのLEDが点滅し始めるはずです。Apple以外のワイヤレスマウスをお使いの場合は、ペアリングモードに設定してください。<BR><BR>USBマウスをお使いの場合はケーブルをチェックしてください。<BR><BR>__product_name__がマウスに接続できない場合、5秒間電源ボタンを押し続けコンピューターの電源を切ってください。",
        details_waiting_for_ack: "マウスを検出しました <B>__device_name__.</B>  ペアリングを行う場合は、クリックしてください <B>続ける</B>。マウスのポインターが動かず、他にワイヤレスマウスがある場合、コンピュータが他のワイヤレスマウスと接続しようとしている可能性があります。",
        button_ack_mouse: "続ける"
    },
    dialogInputDevicesIncompatible:{
        title: "キーボードまたはマウスの互換性がない",
        message: "__product_name__はキーボードやマウスの認識に問題があります。有線のキーボードまたはマウスを接続してスキャンを続行してください。<br>有線のキーボードまたはマウスを使用していない場合は、電源ボタンを5秒間押し続けると__product_name__が終了します。<br>",
        confirmed: "&nbsp; 入力デバイスが見つかりました！ __product_name__はまもなく続きます",
        button_skip_detection: "続ける"
    },
    dialogPartitionsReadOnly: {
        partitions_journaled: {
            title_all_volumes_journaled: "スキャンのみモード",
            title_some_volumes_journaled: "スキャンのみモードのボリュームもあります",
            message_all_volumes_journaled: "このコンピューターのすべてのボリュームにジャーナルがあります。 __product_name__はこのコンピューターをスキャンします。"
                + "しかし綺麗にするには、__ product_name __を工場でアップグレードしてからスキャンを再開する必要があります。<BR> <BR>",
            message_some_volumes_journaled: "このコンピューターの一部のボリュームにはジャーナルがあります。ジャーナリングをオフにしたボリュームはスキャンされ、クリーンアップされます。"
                + "しかしジャーナリングがオンになっているボリュームはスキャンされるだけです（だから少なくともコンピュータが感染しているかどうかはあなたが知るでしょう）。"
                + "クリーンアップするには、__ product_name__を工場でアップグレードしてからスキャンを再開してください。<BR> <BR>",
        },
        partitions_readonly_unclean_ntfs: {
            title: "Windowsが完全に終了しませんでした",
            message: "__product_name__はPCが感染しているかを確認するためスキャンのみモードを続けます。感染をクリーンアップするには、Windowsを完全に終了し、__product_name__を再度起動してください。<BR>Windowsを完全に終了するには： <BR>"
                + "&nbsp; 1.__product_name__を終了し、Windowsを再起動する。<BR>"
                + "&nbsp; 2. __product_name__を挿して、<B>Run__product_name__.exe</B>をダブルクリックする。<BR>"
                + "&nbsp; 3. Run__product_name__.exeの手順に沿う。"
        }
    },
    dialogUncleanMountWarning: {
        title: "Windowsが完全にシャットダウンしなかった.",
        message: "Windowsは完全にシャットダウンしませんでした。完全にシャットダウンしていないコンピュータをクリーニングすると、破損の危険性はごくわずかです。可能であれば、破損の危険を防ぐために、<BR>"
                 + "&nbsp; 1. __product_name__を終了し、Windowsを再起動します。<BR>"
                 + "&nbsp; 2. __product_name__を挿入し、<B> __product_name__.exe </ B>をダブルクリックします。<BR>"
                 + "&nbsp; 3. 画面の指示に従います.<BR>"
                 + "何らかの理由でWindowsを再起動できない場合は、\"きれいに進む \"",
        undo: "Windowsは完全にシャットダウンしませんでした。完全にシャットダウンしていないコンピュータにファイルを復元すると、破損の危険性はごくわずかです。可能であれば、破損の危険を防ぐために、<BR>"
                 + "&nbsp; 1. __product_name__を終了してWindowsを再起動する.<BR>"
                 + "&nbsp; 2. __product_name__を挿入し、<B> __product_name__.exe </ B>をダブルクリックします。<BR>"
                 + "&nbsp; 3. 画面の指示に従います。<BR>"
                 + "何らかの理由でWindowsを再起動できない場合は、\"Proceed to Undo Quarantine \"",
        button_cancel: "キャンセル",
        button_continue: "きれいに進む",
        button_undo: "Proceed to Undo Quarantine"
    },
    dialogBluetoothKeyboard: {
        title: 'Bluetoothキーボードの設定',
        message: "<span class=\"searchingBluetooth\"><B>ワイヤレスキーボードを検出しています。</B></span><BR>ワイヤレスキーボードを検出可能な状態にしてください。Apple社のワイヤレスキーボードを使っている場合、一度OFFにした後に再度ONにしてください。キーボードのLEDが点滅し始めるはずです。Apple社以外のワイヤレスキーボードを使っている場合、ペアリングモードに変更してください。<BR><BR>USBキーボードを使う場合はケーブル接続をご確認ください。",
        details_waiting_for_ack: "キーボードを検出しました<B>__device_name__.</B> ペアリングを認識する場合は<B>\"__ピン_コード__\"</B> をタイプして、<B>Enter</B>を押してください。",
        pin_acknowledged: "&nbsp; 接続しようとしています",
        pin_error: "ペアリングに失敗しました。新しいピンで再試行してください"
    },
    dialogInputRequired: {
        title: "キーを押すかマウスを動かしてください",
        message: "__product_name__はあなたの入力を待っています。<BR>キーボードまたはマウスが機能しない場合は、有線のキーボードまたはマウスを接続してください。<BR>有線のキーボードまたはマウスがない場合は、__product_name__を終了する場合は、電源ボタンを5秒間押してください。"
    },
    dialogUsbDisconnect: {
        title: "__product_name__USBが 解除されました",
        message: "__product_name__がUSBポートから外されました。<BR><BR>5秒間電源ボタンを押し、__product_name__を再起動してください。"
    },
    dialogNotAuthorized: {
        title: "サポートへ連絡してください",
        not_authorized_for_pcs: "この__product_name__はMac用です。このPCはWindows用です。<BR> <BR>間違った__product_name__を注文した場合、私たちのサポートチームはあなたの__product_name__をPCはWindows用上で無料で動かすことができます。<B> support@__product_name__.com </ B>。リクエストに__product_name__側からのシリアル番号を含めてください",
        not_authorized_for_macs: "この__product_name__はWindows用です。このPCはMacです。<BR> <BR>間違った__product_name__を注文した場合、私たちのサポートチームはあなたの__product_name__をMac上で無料で動かすことができます。<B> support@__product_name__.com </B>。リクエストに__product_name__側からのシリアル番号を含めてください",
        invalid_serial_number: "この__product_name__は起動できません。__product_name__がハブまたはプリンターに接続されている場合は、__product_name__を終了し、PCに直接挿し込み、再起動してください。",
        no_serial_number: "__product_name__を終了し、別のUSBポートに挿し込み、再起動してください。__product_name__がハブまたはプリンターに接続されている場合は、__product_name__を終了し、PCに直接挿し込み、再起動してください。",
        opswat_contact_message: "<B>私たちのサポートシステムを介してチケットを提出してくださいhttps://portal.opswat.com/,またはお問い合わせ+1(415) 590-7300.</B>",
        ticket_for_support: "サポートのためのチケット:",
    },
    dialogNotAuthorizedEnterKey: {
        title: "__product_name__をアクティベート",
        enter_key: "プロダクトキーを入力し、__product_name__をアクティベートしてください。",
        enter_key_dimmed: "プロダクトキーを入力",
        button_continue: "続ける",
        invalid_key: "無効なキーです。再度入力してください。"
    },
    dialogExpired : {
        title: "更新が必要です。",
        message: "__product_name__の有効期限が切れています。<BR><BR>__product_name__の利用を継続するために、サブスクリプションを更新してください。<BR><BR>__product_name__の更新は1分未満で完了します。",
    },
    dialogDeviceCountExceeded: {
        title: "サブスクリプションにPCを追加",
        message: "この__product_name__は、登録できるPCの上限に達しました。",
    },
    dialogResultsInfected : {
        title: "スキャン完了 – 感染を発見しました",
        button_clean_computer: "コンピュータをクリーンアップする",
        message: "__product_name__はコンピュータに感染を発見しました。<BR><BR>(特定のファイルをクリーンアップするには、\"結果を見る\"を選択してください。)",
    },
    dialogResultsInfectedButAllJournaled : {
        title: "スキャン完了 – 感染を発見しました",
        message: "<BR> <BR>脅威を駆除するには、__product_name__を終了し、__product_name__をアップグレードしてから__product_name__を再起動してください。"
    },
    dialogResultsFilevaultEmail: {
        title: "スキャン完了 - 感染が見つかりました",
        messageFilevault: "__product_name__があなたのコンピュータに感染を発見しました。<BR> <BR>ボリュームがFileVaultで暗号化されているため、これらの脅威を手動で削除する必要があります。脅威を駆除するには、次のいずれかを実行してください。 <BR>"
                 + "&nbsp; 1. 下にメールを入力してください。手動での削除指示が受信トレイに送信されます。<BR>",
        messageApfs: "__product_name__があなたのコンピュータで感染を検出しました。 <BR> <BR>ボリュームはApfsでフォーマットされているため、これらの脅威は手動で削除する必要があります。脅威をクリアするには、下記のメールアドレスを入力してください。手動での削除指示が受信トレイに送信されます。<BR><BR>",
        messageFilevaultContinued: "&nbsp; 2. __product_name__を終了し、FileVaultをオフにして（support.__product_name__.comにアクセスし、「FileVault」で検索してください）、__product_name__スキャンを再開してください。 FileVaultの電源を切るには、完了するまでに数時間かかることがあります。 <BR>",
        emailSent: "受信トレイに送信された電子メール!",
        emailFailure: "メール送信に失敗しました。インターネット接続を確認し、Eメールアドレスを確認してください。",
        failedValidation: "メールアドレスが無効です。もう一度やり直してください。"
    },
    dialogResultsClean: {
        title: "スキャン完了 – 感染は発見されませんでした",
        message: "感染は発見されませんでした。"
    },
    dialogCleaningDone: {
        title: "コンピュータをクリーンアップしています",
        action_required: "必要な処置",
        mac_readonly_message: "手動で駆除する必要があります。手動で駆除するには、お使いのMacオペレーティングシステムを再起動し、Finderで__product_name__ USBを開き、QUARANTINEファイルをダブルクリックしてください",
        threats_found_but_not_cleaned:"潜在的な脅威は検出されましたが、削除されていません。これらの脅威はコンピュータに残ります。",
        partial_message: "すべての脅威が削除されましたが、脅威の可能性のあるものがコンピュータに残っています。",
        failed_message: "選択した脅威を削除できませんでした。",
        partial_fail_message: "すべてではありませんが、一部の脅威は正常に削除されました。",
        complete_message: "すべての脅威の削除に成功しました。"
    },
    dialogCleaning: {
        title: "コンピュータをクリーンアップ中",
        message: "__product_name__がコンピュータをクリーンアップしています。"
    },
    dialogExit: {
        title: "__product_name__を終了中",
        message: "コンピュータを終了しています。電源がOFFになったら、__product_name__を外して電源をONにし、再起動してください。",
    },
    dialogExitWithInfections: {
        title: "__product_name__を終了中",
        button_exit_anyway: "終了する",
        message: '__product_name__を今終了すると、悪意のあるソフトウェアがコンピュータに残ったままになる可能性があります。”キャンセル”をクリックし、”アクションを実行する”を選び、悪意のあるソフトウェアを駆除してください。'
    },
    dialogConfirmUndo: {
        title: "検疫をundoする",
        message: "選択されたスキャンにおいて削除されたすべてのアイテム（脅威を含む）はコンピュータに復旧されます。",
        readonly_message: "選択したスキャン中に削除されたアイテムのほとんどは、潜在的な脅威を含め、コンピューターに復元されます。 1つ以上のパーティションが読み取り専用としてマウントされているため、一部のアイテムは復元されません。"
    },
    dialogConfirmUndoItem: {
        title: "検疫されたアイテムをUndoする",
        message: "このアイテムは脅威の可能性があります。本当にコンピュータにリストアしますか？ ",
        readonly_tooltip: "パーティションが読み取り専用でマウントされたため、このアイテムは復元できません"
    },
    dialogConfirmImprovementProgram: {
        title: "顧客改善プログラム",
        message: "当社が電子メールを送信することにより、診断データおよび潜在的に悪質なファイルを__product_name__ Technologies Inc.に自動的に送信することに同意したものとします。",
        button_ok: "メールを送る",
        button_cancel: "キャンセル"
    },
    dialogRestartScan: {
        title: "スキャンを再スタート",
        message: "現在のスキャンをキャンセルしてスキャンを再スタートします。"
    },
    dialogEula: {
        title: "__company_name__ エンドユーザーライセンス合意書",
        button_accept_and_run: "承認し実行",
        message: "ライセンス条件をお読みください。",
        improvement_program: "__company_legal_name__.に診断データと潜在的に悪意のあるファイルを自動的に送信する"
    },
    dialogDoesNotMeetMinReqs: {
        title: "システム要件",
        message: "このPCは最低__min_ram__のRAMがないため、__product_name__を実行できません。",
        min_ram: "512 MB",
        min_ram_metadefender_stick: "8 GB"
    },
    dialogLinkEmail: {
        title: "__product_name__を登録する",
        message: "__product_name__を登録するためメールアドレスを入力してください。",
        email: "メールアドレス",
        confirm_email: "Eメール確認",
        name: "氏名",
        first_name: "名",
        last_name: "姓",
        registering: "__product_name__を登録します。",
        INVALID_EMAIL: "メールアドレスが無効です。",
        emails_dont_match: "電子メールは一致しません。",
        button_skip : "スキップします"
    },
    dialogUnlockFilevault: {
        title: "一部のボリュームはFilevaultで暗号化されています",
        unlocking: "Filevaultのロックを解除する",
        message: "下記のMacパスワードを入力してください。パスワードはスキャンのためにボリュームを一時的にロック解除するために使用されます。パスワードは保存されません。",
        metadefender_second_message: "実験的機能：MetaDefender Driveがボリュームのロック解除に失敗した場合は、処理を続けるためにFileVaultを無効にする必要があります。コントロールパネルのアップルメニュー> [システム環境設定]> [セキュリティとプライバシー]の下にある[FileVaultを無効にする]を選択してください。",
        not_all_drives_unlocked: "一部のボリュームはロックされたままです。これらのボリュームをロック解除するには、別のMacパスワードを試してください。",
        could_not_unlock: "FileVaultをアンロックできません。別のMacパスワードをお試しください。メモ外部ドライブは現在サポートされていません。",
        password: "Macパスワード",
        button_skip: "スキップ"
    },
    dialogFactoryUpgradeInstructionsEmail: {
        title: "工場アップグレードのための指示を送信する",
        header: "出荷時設定にリセット",
        stepsListPartOne: "1. 下にメールを入力してください。 指示があなたの電子メールに送られます",
        stepsListPartTwo: "2. __product_name__を終了し、コンピューターを再始動して、電子メールの指示に従います。<BR>3. ファクトリをアップグレードした__product_name__で別のスキャンを開始します。",
        emailSent: "受信トレイに送信された電子メール!",
        emailFailure: "メール送信に失敗しました。インターネット接続を確認し、Eメールアドレスを確認してください。",
        failedValidation: "メールアドレスが無効です。もう一度やり直してください。",
        button_skip: "スキップ"
    },
    dialogSettings: {
        title: "設定",
        button_send_instructions: "指示を送る"
    },
    dialogLoadingRenewal: {
        title: "エクスプレス更新をロードします。"
    },
    notif : {
        take_a_break: {
            title: "休憩をとっていただいて大丈夫です！",
            title_metadefender: "スキャンが開始しました。しばらくお待ちください。",
            message: "このスキャンは1時間から数時間かかる場合があります。終了まで入力していただく箇所はありません。",
            message_plug_suffix: '<BR><BR>スキャン中に電源が切れないようにコンピュータにACアダプターを挿し込んでください。'
        },
        recovered_from_crash: {
            title: "自動再起動",
            message: "最後に実行した__product_name__のスキャンに問題がありました。ご心配はいりません。問題を検出し、前回中断した箇所から自動的に新たなスキャンを起動しました。お知らせまで。"
        },
        restored_dnsapi_dll: {
            title: "復旧されたシステムファイル",
            message: "__product_name__がdnsapi.dll という名前の欠損した重要システムファイルを検出し復旧しました。"
        },
        restored_netfilter2_sys: {
            title: "間違って隔離されたファイルを復元しました",
            message: "__product_name__は、誤って隔離されたnetfilter2.sysという名前のファイルを検出して自動的にリストアしました。<BR>スキャンを実行しない場合は、右上のXをクリックして__product_name__を終了できます。"
        },
        right_click_detected: {
            title: "マウスの右ボタンを使っていますか？",
            message: "__product_name__では、マウスの左ボタンを使うことが必要です（左利きでも恐縮ですが）。"
        },
        left_click: {
            title: "ヒント",
            message: "左ボタンのクリックがうまくいかない場合、Tabボタンで選択し、Enterを押してください。"
        },
        bluetooth_reconnect: {
            title: "Bluetoothに関するヒント",
            message: "__product_name__を終了し、パソコンを再起動した後、パソコンがBluetoothデバイスのペアリングをするように促しても気になさらないでください。特に問題があるわけではありません。"
        },
        device_pci: {
            title: "サポートされていないネットワークカード",
            message: "お持ちのネットワークカードに対応できるよう、support@__product_name__.com に以下の情報をメールで送信してください。<BR>"
        },
        keyboard_layout: {
            title: "異常な文字",
            message: "見慣れない文字が出ていますか？ <BR> <i class=\"fa fa-keyboard-o\" aria-hidden=\"true\"></i>アイコンをクリックし、キーボードを変更してください。"
        },
        scan_report: {
            title: "生成されたスキャンレポート",
            message: "あなた__product_name__ 'reports'ディレクトリにあるレポートをご覧ください。",
            message_meta_defender_stick: "__scan_report_path__が生成されました。__product_name__デバイスのNTFSパーティションを調べて、詳細なスキャン結果を確認してください！"
        },
    },
    action: {
        keep: "キープする",
        quarantine: "除去する",
        journaled: "工場アップグレードおよび再スキャンしてクリーンにする",
        readonly_non_journaled: "終了し、Run__product_name__.exeから起動しクリーンアップ",
        manual_clean: "手動でクリーニングする必要があります。<br> <a href='' onclick='ShowManualCleanModal();'>指示。</a>"
    },
    time: {
        day: "__count__ 日",
        day_plural: "__count__ 日",
        hour: "__count__ 時間",
        hour_plural: "__count__ 時間",
        minute: "__count__ 分",
        minute_plural: "__count__ 分",
        second: "__count__ 秒",
        second_plural: "__count__ 秒",
        ago: "__time__ 前",
        calculating: "計算しています...",
        complete : "完了しました",
        left : "残り",
        several_hours: "数時間",
        finishing_up: "仕上げ..."
    },
    accordion: {
        scan: {
            title: "スキャン",
            filevault_configuration_not_supported: "このMacは、現在__product_name__でサポートされていないFileVault暗号化設定を使用します。 FileVaultで暗号化されたボリュームはスキャンされません。",
            filevault_need_to_factory_upgrade: "__product_name__は、Macが使用しているテクノロジー（FileVault）を処理するために、工場出荷時の1回限りの無料アップグレードが必要です。<br> <a href=\"#\" onclick='return ShowFactoryUpgradeInstructionsSendingModal(\"MAC\");'>ここをクリック</a> して工場出荷時のアップグレード方法の電子メールを送信し、別のスキャンを開始してください。",
            apfs_need_to_factory_upgrade: "__product_name__は、Macが使用しているテクノロジー（APFS）を処理するために、工場出荷時の1回限りの無料アップグレードが必要です。<br> <a href=\"#\" onclick='return ShowFactoryUpgradeInstructionsSendingModal(\"MAC\");'>ここをクリック</a> して工場出荷時のアップグレード方法の電子メールを送信し、別のスキャンを開始してください。",
            drive_disconnected: "スキャン中にドライブの1つが切断されました。",
            status: {
                need_to_run_chk_disk: "一部のパーティションは安全でない状態であり、スキャンできません。 Windowsからディスクの確認コマンドを実行する必要があります。手順については、「www.fixmestick.com/run-chkdsk」にアクセスしてください。",
                at_least_one_partition_read_only: "スキャンのみモードでスキャンしているボリュームがあります",
                encryption_detected: "__product_name__はあなたのBitLockerドライブ暗号化の一つ以上をスキャンすることができません。",
                encryption_detected_metadefender: "1つ以上のボリュームが暗号化されており、スキャンできません。 これらのボリュームをスキャンするには、Windowsから再起動し、スティックのNTFSパーティションの/ tools / bitlockerフォルダにある 'README.txt'の指示に従ってください.",
                hfs_filevault_detected: "1つ以上のボリュームが以前のバージョンのApple Filevaultで暗号化されているため、スキャンできません。これらのボリュームをスキャンするには、macOsからFilevaultを無効にして__product_name__を再起動してください。",
                apfs_filevault_detected: "1つ以上のボリュームがApple Filevaultで暗号化されています。",
                hfs_filevault_detected_metadefender: "1つ以上のボリュームが以前のバージョンのApple Filevaultで暗号化されているため、スキャンできません。コントロールパネルのアップルメニュー> [システム環境設定]> [セキュリティとプライバシー]の下にある[FileVaultを無効にする]を選択してください。",
                apfs_filevault_detected_metadefender: "1つ以上のボリュームがApple Filevaultで暗号化されています。 <br> <br>暗号化されたボリューム：__encrypted_volumes__",
                safe: "コンピュータの状態: 安全  ",
                safe_so_far: "コンピュータの状態: 今のところ安全",
                safe_so_far_metadefender: "コンピュータの状態：検査が進行中です。",
                not_safe: "コンピュータの状態: 危険",
                not_safe_review_when_finished: "初期のスキャンから、悪意のあるソフトウェアがシステムに存在する可能性があることを示しています。検出されたアイテムはスキャンが終了したら確認できます。",
                safe_all_infections_quarantined: "すべての感染が削除されました。",
                throttling_too_hot: "コンピュータが非常に熱くなっています。オーバーヒートを避けるため、スキャン速度を落としています。",
                keep_cool_mode: '冷却保持モードを起動しました',
                reduced_functionality:"__product_name__はリソース節約モードで実行されています。",
                quick_scan:"__product_name__はクイックスキャンを実行しています。"
            },
            no_files_marked_quarantine: ' "削除"とマークされたファイルはありません。.',
            threats_found : "__product_name__は脅威の可能性のあるファイルを検出しました。",
            no_threats_found : "グッドニュースです！脅威の可能性のあるファイルは検出されませんでした。",
            scan_complete_message : " __num_items__ 個のアイテムのスキャンが __time__で完了しました。",
            button_apply_actions : "アクションを適用する",
            button_skip_updates: "更新をスキップする",
            applying_update_packages: "MetaDefender Drive Updateディレクトリにパッケージを適用する。 __current_package__ / __total_packages__...",
            engines_init: "エンジンは初期化されました。",
            applying_update: "アップデートを適用しています。__product_name__は間もなく再起動します...",
            details :  {
                time_elapsed : "経過時間：",
                time_remaining : "残り時間：",
                items_scanned : "スキャンされたアイテム：",
                total_items : "アイテムの合計：",
                item : "アイテム："
            },
            results:  {
                scan_results_caption : "脅威が見つかりました",
                cleaning_results_caption : "結果をクリーンアップ中",
                file : "File",
                file_size: "ファイルサイズ",
                last_modified: "最終更新日",
                threats : "脅威",
                action : "アクション",
                result : "結果",
                cleaning_state: {
                    ignored: "削除に失敗しました",
                    disconnected:"ドライブが切断されました",
                    quarantined: "検疫しました",
                    disinfected: "除去しました",
                    manual_clean: "手動でクリーニングする必要があります。<br> <a href='' onclick='ShowManualCleanModal();'>指示。</a>"
                }
            },
            steps: {
                checking_internet_connection: "チェック中<BR>インターネット接続",
                checking_for_product_updates: "チェック中<BR>製品アップデート",
                updating_malware_definition: "更新中<BR>マルウェア定義",
                initializing_malware_scanners: "初期化中<BR>マルウェアスキャン",
                scanning_computer: "スキャン中<BR>コンピュータ",
                results: "結果"
            },
            steps_metadefender: {
                checking_internet_connection: "インターネット接続の確認",
                checking_for_product_updates: "__product_shortname__<br><span style='white-space:nowrap;'>アップデートのチェック</span>",
                updating_malware_definition: "<span style='white-space: nowrap;'>マルウェアと脆弱性の</span><br><span style='white-space:nowrap;'>定義の更新</span>",
                initializing_malware_scanners: "__product_shortname__<span style='white-space:nowrap;'>の初期化</span>",
                scanning_computer: "__product_shortname__<br><span style='white-space:nowrap;'>マルウェアと脆弱性スキャン</span>",
                results: "結果"
            },
            endscan: {
                checking_startup_programs: "スタートアッププログラムを確認しています...",
                checking_hard_links: "ハードリンクをチェックしています...",
                checking_lnk_shortcuts: "ショートカットを確認しています...",
                checking_hosts_files: "ホストファイルをチェックしています...",
                waiting_on_cloud_scanner: "Cloud Scannerで待機しています..."
            }
        },
        undo: {
            title: "検疫を元に戻す",
            success: "<B>検疫のアンドゥに成功しました。</B>  すべてのファイルを元の場所にリストアしました。",
            partial: "<B>隔離が部分的に取り消されました。</ B>一部のファイルは復元されませんでした。",
            item_success: "<B>__quarantined_item__</B> がコンピュータにリストアしました",
            no_quarantines: "削除したファイルがコンピュータのエラーを引き起こしていると思われる場合、特定のスキャンセッションからファイルをリストアする場合アンドゥを利用してください。<BR><BR><B>__product_name__の検疫にアイテムはありません。</B>",
            some_quarantines: "削除したファイルがコンピュータのエラーを引き起こしていると思われる場合、特定のスキャンセッションからファイルをリストアする場合アンドゥを利用してください。",
            table: {
                caption: "セッションをスキャン",
                col_date: "日",
                col_items: "アイテム",
                col_action: "アクション",
                button_undo: "アンドゥ",
                button_undo_item: "アイテムをアンドゥ"
            }
        },
        custom: {
            title: "カスタムスキャン",
            button_apply: "適用する",
            select_folders: "スキャンしたいディスクとフォルダを選択してください：",
            select_at_least_one_folder: "最低一つのフォルダを選択してください。"
        },
        quick: {
            title: "クイックスキャン",
            message: "時間が不足していますか？ クイックスキャンは、最も一般的な脅威の場所をチェックします。",
            in_progress_message: "クイックスキャンは現在進行中です...",
            no_file: "<B>最高のクイックスキャンの結果を得るために、__product_name__を終了し、コンピュータを再起動して、__product_name__.exeをダブルクリックして別のスキャンを開始してください。 これは__product_name__は、コンピュータ上のアクティブな脅威に関する追加情報を収集できるようになります。</ B>",
            button: "クイックスキャンを開始します"
        }
    },
    scan_report: {
        header: "スキャンレポート",
        summary: {
            header: "スキャンの概要:",
            scan_type: "スキャンの種類：",
            computer_name: "コンピュータ名：",
            start_time: "開始時間：",
            duration: "実行時間：",
            app_version: "クライアントバージョン：",
            live_os_version: "LiveOs バージョン: ",
            metadefender_drive_os_version: "MetaDefender Drive OSバージョン：",
            num_files_scanned: "スキャンしたファイル数：",
            num_malware_files: "感染したファイル：",
            num_vulnerabilities: "合計脆弱性: "
        },
        definitions: {
            header: "エンジン定義バージョン:",
            definition: "DBバージョン: ",
            last_updated: "最終更新: "
        },
        threats: {
            header_infections: "脅威レポート:",
            header_vulnerabilities: "脆弱性:",
            index: "#",
            filename: "ファイル名",
            size: "ファイルサイズ",
            modified: "最終更新日",
            threats: "脅威"
        }
    },
    button_continue_scan_only: "ボリュームでスキャンのみモードを継続する",
    button_exit_scan : "__product_name__を終了する",
    button_see_results : "結果を見る",
    button_ok : "OK",
    button_cancel : "キャンセル",
    button_renew: "エキスプレス更新",
    button_retry: "再実行",
    button_send_email: "メールを送る",
    undoing_quarantine : "検疫を元に戻します。少々お待ちください...",
    mounting_disks : "ハードディスクを検査しています。少々お待ちください...",
    jqgrid : {
        recordtext: "{2} の中の {0} - {1} を見る",
        emptyrecords: "見るレコードがありません",
        loadtext: "ロード中...",
        pgtext : " {1} ページの {0} "
    }
}

if (GetExternal().IsLocaleSupportedByUi(jp.locale))
{
    arrLocalizedStrings.push(jp);

    // In case of Asian languages we also need to add a keyboard input option.
    // Do not want to display the keyboard option if language is ont supported by LiveOS otherwise the keyboard name will show in strange squares.
    g_keyboardOptions.push(["ibus-anthy", "日本語 (Anthy)"]);
    g_keyboardOptions.push([jp.locale, jp.localeName]);
}

