var cn = {
    locale: "cn",
    localeName: "中文",
    locale_selector_title: "后面已提供：",
    remoteConnection: {
        initializing: "启动远程连接……"
    },
    connectDialog: {
        title: "连接到您的网络",
        click_network_manager: "点击屏幕右上角的 __img__ 来查看可用的无线网络。",
        please_plug_wire: "请插入网线。",
        dialog_will_auto_close: "网络连接建立后，此对话框将自动关闭。",
        continue_without_internet: "断网状态下您仍可继续使用，但__product_name__将无法更新，因而无法为您提供最新版本的安全保护。",
        continue_without_metadefender_update_packages: "<br><b>MetaDefender Core最近有一个更新，必须刷新其反病毒引擎文件才能扫描。请连接到Internet继续。</b>",
        button_skip: "跳过网络连接",
        proxy_url_prompt: "主机：端口",
        proxy_user_prompt: "用户",
        proxy_password_prompt: "密码",
        enter_proxy_url_dimmed: "主机：端口",
        enter_proxy_user_dimmed: "仅当需要时设置",
        button_submit_proxy_url: "设置",
        proxy_setting: "您的网络是否需要一个HTTP代理服务器？",
        confirm_invalid_proxy_info: "无效的代理配置",
        confirm_proxy_set : "HTTP代理服务器已设定。",
        confirm_proxy_removed : "HTTP代理服务器已移除。"
    },
    dialogBluetoothMouse: {
        title: '设置蓝牙鼠标',
        message: "<span class=\"searchingBluetooth\"><B>搜索无线鼠标。</B></span><BR>请确保您的无线鼠标已设置为\"可被其他设备发现。\" 如果您正在使用苹果无线鼠标，请将鼠标重启。然后您鼠标的LED灯应开始闪烁。如果您正在使用其他品牌的无线鼠标，请将其设置为\"配对模式。\"<BR><BR>如果您要使用USB鼠标，请插好数据线。<BR><BR> 如果__product_name__无法连接到您鼠标，您可以长按电源键5秒关机后重试。",
        details_waiting_for_ack: "发现鼠标 <B>__device_name__。</B> 为确认配对，请点击 <B>继续</B>。如果该鼠标未能使指针移动，请更换其他无线鼠标，再使用该无线鼠标与电脑配对。",
        button_ack_mouse: "继续",

    },
    dialogInputDevicesIncompatible:{
        title: "键盘或鼠标不兼容",
        message: "__product_name__无法识别您的键盘或鼠标。请连接有线键盘或鼠标继续扫描。<br>如果您没有有线键盘或鼠标，请按住电源按钮5秒以退出__product_name__。<br>",
        confirmed: "&nbsp; 输入设备找到！ __product_name__将很快继续",
        button_skip_detection: "继续"
    },
    dialogPartitionsReadOnly: {
        partitions_journaled: {
            title_all_volumes_journaled: "“只扫描”模式",
            title_some_volumes_journaled: "一些卷处于“只扫描”模式下",
            message_all_volumes_journaled: "此计算机上的所有卷都具有日记功能。 __product_name__将扫描此计算机，"
                + "但要清理，您必须在出厂时升级__product_name__，然后重新开始扫描。<BR> <BR>",
            message_some_volumes_journaled: "此计算机上的某些卷具有日志功能。关闭日记功能的卷将被扫描和清理，"
                +"但只会扫描具有日记功能的卷（因此您至少会发现计算机是否被感染）。"
                +"要清理，请升级__product_name__，然后重新开始扫描。<BR> <BR>",
        },
        partitions_readonly_unclean_ntfs: {
            title: "Windows未完全关闭",
            message: "Windows未完全关闭，为了防止任何损坏的风险，请: <BR>"
                     + "&nbsp; 1. 退出__product_name__并重新启动Windows<BR>"
                     + "&nbsp; 2. 插入__product_name__并双击<B>__product_name__.exe</B>.<BR>"
                     + "&nbsp; 3. 按照屏幕上的说明进行操作。<BR>"
                     + "如果由于任何原因无法重新启动Windows，请单击\"继续\"",
        }
    },
    dialogUncleanMountWarning: {
        title: "Windows未完全关闭",
        message: "“Windows未完全关闭，为了防止任何损坏的风险，请: <BR>"
                 + "&nbsp; 1. 退出__product_name__并重新启动Windows<BR>"
                 + "&nbsp; 2. 插入__product_name__并双击<B>__product_name__.exe</B>.<BR>"
                 + "&nbsp; 3. 按照屏幕上的说明进行操作。<BR>"
                 + "如果由于任何原因无法重新启动Windows，请单击\"继续\"",
        undo: "“Windows未完全关闭，为了防止任何损坏的风险，请: <BR>"
                 + "&nbsp; 1. 退出__product_name__并重新启动Windows<BR>"
                 + "&nbsp; 2. 插入__product_name__并双击<B>__product_name__.exe</B>.<BR>"
                 + "&nbsp; 3. 按照屏幕上的说明进行操作。<BR>"
                 + "如果由于任何原因无法重新启动Windows，请单击\"继续\"",
        button_cancel: "取消",
        button_continue: "继续清理",
        button_undo: "恢复"
    },
    dialogBluetoothKeyboard: {
        title: '设置蓝牙键盘',
        message: "<span class=\"searchingBluetooth\"><B>搜索无线键盘。</B></span><BR>请确保您的无线键盘已设置为 \"可被其他设备发现。\" 如果您正在使用苹果无线键盘，请将键盘重启。然后您键盘的LED灯应开始闪烁。如果您正在使用其他品牌的无线键盘，请将其设置为\"配对模式。\"<BR><BR>如果您要使用USB键盘，请插好数据线。",
        details_waiting_for_ack: "发现键盘<B>__device_name__。</B> 为确认配对，请输入<B>\"__pin_code__\"</B>，然后敲击<B>ENTER（回车）</B>。",
        pin_acknowledged: "&nbsp; 尝试连接",
        pin_error:"配对失败。请用新的引脚重试"
    },
    dialogInputRequired: {
        title: "请按下键或移动鼠标",
        message: "__product_name__正在等待您的输入。<BR>如果您的键盘或鼠标不工作，请连接有线键盘或鼠标。<BR>如果您没有有线键盘或鼠标，请按住电源按钮5几秒钟退出__product_name__"
    },
    dialogUsbDisconnect: {
        title: "__product_name__已从USB端口断开",
        message: "__product_name__已从USB端口断开。也许设备被碰掉了，请检查并插好设备。<BR><BR>请长按电源键5秒关闭电脑，然后重新启动__product_name__。"
    },
    dialogNotAuthorized: {
        title: "请联系技术支持",
        not_authorized_for_pcs: "该版本的__product_name__只适用于Mac（苹果电脑），不适用于您的PC（Windows系统的个人电脑）。<BR> <BR>如果您订购了错误的__product_name__，我们的支持团队可以将您的__product_name__转换为在 PC（Windows系统的个人电脑）上运行，请发送电子邮件至<B> support@__product_name__.com </B>在请求中包含__product_name__一侧的序列号。",
        not_authorized_for_macs: "该版本的__product_name__只适用于PC（Windows系统的个人电脑），不适用于您的Mac（苹果电脑）。<BR> <BR>如果您订购了错误的__product_name__，我们的支持团队可以将您的__product_name__转换为在 Mac（苹果电脑） 上运行，请发送电子邮件至<B> support@__product_name__.com </B>在请求中包含__product_name__一侧的序列号。",
        invalid_serial_number: "您的__product_name__未获得授权。 如果您把__product_name__插在集线器或打印机上，请退出__product_name__，将其直接插在您的计算机上，然后再试一次。",
        no_serial_number: "请退出__product_name__，换另一个USB端口，插入重试。 如果您把__product_name__插在集线器或打印机上，请拔下并直接插在您的计算机上重试。",
        opswat_contact_message:"<B>请在https://portal.opswat.com/通过我们的支持系统提交一张票，或拨打+1(415) 590-7300来联络我们。</B>",
        ticket_for_support: "提交支持请求：",
    },
    dialogNotAuthorizedEnterKey: {
        title: "激活__product_name__",
        enter_key: "请输入产品密钥来激活__product_name__。",
        enter_key_dimmed: "输入产品密钥",
        button_continue: "继续",
        invalid_key: "密钥无效，请重试。"
    },
    dialogExpired : {
        title: "请续订",
        message: "您订购的__product_name__已过期。<BR><BR>请续订以便继续使用您的__product_name__。<BR><BR>只需不到一分钟的时间，就可以完成续订。",
    },
    dialogDeviceCountExceeded: {
        title: "为您订购的__product_name__添加计算机",
        message: "添加在该__product_name__上的计算机数量已达上限。",
    },
    dialogResultsInfected: {
        title: "扫描完成-发现感染",
        button_clean_computer: "开始查杀",
        message: "__product_name__已在您的计算机上发现病毒。<BR><BR>(如果只想查杀某些文件，请选择 \“查看结果。\”)",
    },
    dialogResultsInfectedButAllJournaled : {
        title: "扫描完成-发现感染",
        message: "__product_name__已在您的计算机上发现感染。<BR> <BR>要清除威胁，请退出__product_name__，出厂升级__product_name__，然后重新启动__product_name__。"
    },
    dialogResultsFilevaultEmail: {
        title: "扫描完成 - 发现感染",
        messageFilevault: "__product_name__在您的计算机上发现了感染。<BR> <BR>由于您的卷是使用FileVault加密的，因此必须手动删除这些威胁。要清除威胁，请： <BR>"
                 + "&nbsp; 1. 在下面输入你的邮箱。手动删除说明将被发送到您的收件箱。 <BR>",
        messageApfs: "__product_name__已经检测到您的计算机上的感染。 <BR> <BR>由于您的卷使用Apfs格式化，因此必须手动删除这些威胁。要清除威胁，请在下面输入您的电子邮件。手动删除说明将被发送到您的收件箱。<BR><BR>",
        messageFilevaultContinued: "&nbsp; 2. 退出__product_name__，关闭FileVault（请访问support.__product_name__.com并搜索“FileVault”中的说明），然后重新启动__product_name__扫描。注意关闭FileVault可能需要几个小时才能完成。 <BR>",
        emailSent: "邮件已发送!",
        emailFailure: "无法发送电子邮件。检查互联网连接并验证电子邮件地址。",
        failedValidation: "电子邮件无效。请再试一次。"
    },
    dialogResultsClean: {
        title: "扫描完成-未发现感染",
        message: "未发现感染。"
    },
    dialogCleaningDone: {
        title: "开始查杀",
        action_required: "需要采取的行动",
        mac_readonly_message: "需要手动删除一些感染。要手动删除，请重启到Mac操作系统，在'Finder'中打开__product_name__ USB，然后双击'QUARANTINE'文件",
        threats_found_but_not_cleaned:"检测到潜在的威胁，但没有一个被删除。这些威胁将保留在您的计算机上",
        partial_message: "所有已选定的威胁均已成功清除，但您的计算机仍受到潜在威胁。",
        failed_message: "无法删除所选的威胁。",
        partial_fail_message: "成功消除了部分但不是全部威胁。",
        complete_message: "已成功清除所有病毒。"
    },
    dialogCleaning: {
        title: "开始查杀",
        message: "__product_name__正在对电脑进行查杀。"
    },
    dialogExit: {
        title: "退出__product_name__",
        message: "您的电脑即将关闭。请在电脑关闭后拔下__product_name__，然后按下电源键重启电脑。",
    },
    dialogExitWithInfections: {
        title: "退出__product_name__",
        button_exit_anyway: "继续退出",
        message: '如果您现在退出__product_name__，恶意软件可能仍潜伏在您的计算机中。请点击“取消”，然后点击“应用操作”以删除恶意软件。'
    },
    dialogConfirmUndo: {
        title: "恢复所有隔离项",
        message: "经扫描选定的所有移除项目将重新恢复到您的计算机中，其中包括潜在的威胁。",
        readonly_message: "在选定的扫描过程中删除的大多数项目都将还原到您的计算机上，包括潜在的威胁。由于一个或多个分区以只读方式安装，因此某些项目将无法还原。",
    },
    dialogConfirmUndoItem: {
        title: "恢复隔离项",
        message: "该项目是一个潜在的威胁。您确定要把它恢复到您的计算机中吗？",
        readonly_tooltip: "由于分区以只读方式挂载，因此无法还原该项目"
    },
    dialogConfirmImprovementProgram: {
        title: "客户改进计划",
        message: "通过允许我们向您发送电子邮件，您同意自动将诊断数据和潜在的恶意文件发送给__product_name__ Technologies Inc.",
        button_ok: "发电子邮件",
        button_cancel: "取消"
    },
    dialogRestartScan: {
        title: "重新扫描",
        message: "您将取消当前的扫描并重新开始扫描。"
    },
    dialogEula: {
        title: "__company_name__ 最终用户许可协议",
        button_accept_and_run: "接受并运行",
        message: "请阅读许可条款",
        improvement_program: "自动将诊断数据和潜在恶意文件发送到__company_legal_name__."
    },
    dialogDoesNotMeetMinReqs: {
        title: "系统要求",
        message: "此电脑的内存不足__min_ram__，无法运行__product_name__。",
        min_ram: "512MB",
        min_ram_metadefender_stick: "8GB"
    },
    dialogLinkEmail: {
        title: "注册__product_name__账号",
        message: "请输入您的电子邮箱",
        email: "电子邮箱",
        confirm_email: "确认邮件",
        name: "姓名",
        first_name: "你的名字",
        last_name: "你的姓氏",
        registering: "注册__product_name__账号",
        INVALID_EMAIL: "邮箱地址无效。",
        emails_dont_match: "电子邮件不匹配",
        button_skip : "跳过"
    },
    dialogUnlockFilevault: {
        title: "您的一些卷使用Filevault加密",
        unlocking: "解锁Filevault",
        message: "请在下面输入您的Mac密码。您的密码将被用于临时解锁您的卷进行扫描。您的密码将不会被储存。",
        metadefender_second_message: "实验性功能：如果MetaDefender驱动器无法解锁您的卷，则必须禁用FileVault才能继续处理。请在控制面板下的Apple菜单>系统偏好设置>安全和隐私下选择“关闭FileVault”。",
        not_all_drives_unlocked: "有些卷保持锁定状态。请尝试使用不同的Mac密码来解锁这些卷。",
        could_not_unlock: "无法解锁FileVault。请尝试不同的Mac密码。注意当前不支持外部驱动器。",
        password: "Mac密码",
        button_skip: "跳跃"
    },
    dialogFactoryUpgradeInstructionsEmail: {
        title: "为工厂升级发送说明",
        header: "重置为出厂设置",
        stepsListPartOne: "1. 在下面输入你的邮箱。 说明将发送到您的电子邮件。",
        stepsListPartTwo: "2. 退出__product_name__，重新启动计算机，然后按照电子邮件中的说明进行操作。<BR>3. 用您的工厂升级的__product_name__启动另一个扫描。",
        emailSent: "邮件已发送!",
        emailFailure: "无法发送电子邮件。检查互联网连接并验证电子邮件地址。",
        failedValidation: "电子邮件无效。请再试一次。",
        button_skip: "跳跃"
    },
    dialogSettings: {
        title: "设置",
        button_send_instructions: "发送说明"
    },
    dialogLoadingRenewal: {
        title: "加载快速续订"
    },
    notif : {
        take_a_break: {
            title: "您可以去休息一下！",
            title_metadefender: "扫描已经开始",
            message: "本次扫描大约需要几个小时。 在扫描结束前，您不需要做任何操作。",
            message_plug_suffix: '<BR><BR>请连接好交流电源适配器，确保您的计算机在扫描过程中不会断电。'
        },
        recovered_from_crash: {
            title: "自动重启",
            message: "最后一次__product_name__扫描遇到问题。但无需担心，我们已发现该情况并从断点位置重启继续扫描。请悉知。"
        },
        restored_dnsapi_dll: {
            title: "恢复系统文件",
            message: "__product_name__检测并恢复了丢失的关键系统文件dnsapi.dll。"
        },
        restored_netfilter2_sys: {
            title: "恢复错误隔离的文件",
            message: "__product_name__检测到并自动恢复名为netfilter2.sys的错误隔离文件。<BR>如果您不想运行扫描，现在可以通过单击右上角的X安全地退出__product_name__。"
        },
        right_click_detected: {
            title: "您正在使用鼠标右键吗？",
            message: "__product_name__需要您使用鼠标左键（即使您习惯使用左手；））。"
        },
        left_click: {
            title: "提示",
            message: "如果左键点击无效，您可以敲击\"Tab（制表键）\"直到选中一个按钮，然后敲击\"Enter（回车）\"。"
        },
        bluetooth_reconnect: {
            title: "蓝牙提示",
            message: "如果您退出__product_name__并重启电脑后，电脑提示重新配对蓝牙设备，请不要惊慌，这是正常的。"
        },
        device_pci: {
            title: "不支持的网卡",
            message: "请填好下列信息并发送至support@__product_name__.com，我们将帮助您解决网卡问题。<BR>"
        },
        keyboard_layout: {
            title: "字符异常",
            message: "键盘打字失效？<BR>请点击<i class=\"fa fa-keyboard-o\" aria-hidden=\"true\"></i> 图标以更换您的键盘。"
        },
        scan_report: {
            title: "生成扫描报告",
            message: "请参阅__product_name__上“reports”目录中的报告。",
            message_meta_defender_stick: "__scan_report_path__生成，请查看您的__product_name__设备的NTFS分区中的详细扫描结果！"
        },
    },
    action: {
        keep: "保留",
        quarantine: "移除",
        journaled: "工厂升级并重新扫描以清理",
        readonly_non_journaled: "退出并重启Run__product_name__.exe进行清理",
        manual_clean: "必须手动清理。<br><a href='' onclick='ShowManualCleanModal();'>说明.</a>"
    },
    time: {
        day: "__count__ 天",
        day_plural: "__count__ 天",
        hour: "__count__ 小时",
        hour_plural: "__count__ 小时",
        minute: "__count__ 分",
        minute_plural: "__count__ 分",
        second: "___count__ 秒",
        second_plural: "__count__ 秒",
        ago: "__time__ 前",
        calculating: "计算中……",
        complete : "完成",
        left : "剩余",
        several_hours: "几个小时",
        finishing_up: "整理起来...."

    },
    accordion: {
        scan: {
            title: "扫描",
            filevault_configuration_not_supported: "此Mac使用__product_name__目前不支持的FileVault加密配置。 使用FileVault加密的卷不会被扫描。",
            filevault_need_to_factory_upgrade: "您的__product_name__需要免费的一次性工厂升级来处理您的Mac正在使用的技术（FileVault）。<br> 请 <a href=\"#\" onclick='return ShowFactoryUpgradeInstructionsSendingModal(\"MAC\");'>点击这里</a> 发送电子邮件，了解如何进行工厂升级，然后启动另一个扫描。",
            apfs_need_to_factory_upgrade: "您的__product_name__需要免费的一次性工厂升级来处理您的Mac正在使用的技术（APFS）。<br> 请 <a href=\"#\" onclick='return ShowFactoryUpgradeInstructionsSendingModal(\"MAC\");'>点击这里</a> 发送电子邮件，了解如何进行工厂升级，然后启动另一个扫描。",
            drive_disconnected: "扫描期间您的一个驱动器已断开连接。",
            status: {
                need_to_run_chk_disk: "您的某些分区处于不安全状态，无法扫描。您需要从Windows运行check disk命令。请访问'fixmestick.com/run-chkdsk'获取指示。",
                at_least_one_partition_read_only: " Windows未完全关闭。 如果可能，退出__product_name__，重新启动Windows，并使用__product_name__.exe启动扫描.",
                at_least_one_partition_journaled: "某些数据已被记录并且无法清理。若要解决这个问题，请访问我们的网站并更新您的__product_name__。",
                encryption_detected: "__product_name__无法扫描您的一个或多个BitLocker加密驱动器",
                encryption_detected_metadefender: "一个或多个卷已加密且无法扫描。 要扫描这些卷，请从Windows重新启动并按照棒的NTFS分区的/ tools / bitlocker文件夹中的“README.txt”中的说明进行操作.",
                hfs_filevault_detected: "一个或多个卷使用早期版本的Apple Filevault加密，无法扫描。请从macOs禁用Filevault并重新启动__product_name__以扫描这些卷。",
                apfs_filevault_detected: "使用Apple Filevault加密一个或多个卷。",
                hfs_filevault_detected_metadefender: "一个或多个卷使用早期版本的Apple Filevault加密，无法扫描。请在控制面板下的Apple菜单>系统偏好设置>安全和隐私下选择“关闭FileVault”。",
                apfs_filevault_detected_metadefender: "使用Apple Filevault加密一个或多个卷。 <br> <br>加密卷：__encrypted_volumes__",
                quick_scan: "__product_name__正在运行快速扫描。",
                safe: "计算机状态：安全。",
                safe_so_far: "计算机状态：到目前为止安全。",
                safe_so_far_metadefender: "计算机状态：正在进行检查。",
                not_safe: "计算机状态：发现威胁。",
                not_safe_review_when_finished: "初步扫描结果显示：您的系统中可能存在恶意软件。您可以在扫描完成后检查检测到的项目。",
                safe_all_infections_quarantined: "已成功清除所有病毒。",
                throttling_too_hot: "这台电脑的温度正在不断上升，为防止电脑过热，扫描速度开始减慢。",
                keep_cool_mode: '激活并保持清凉模式',
                reduced_functionality:"__product_name__正在资源保存模式下运行。",
                quick_scan:"__product_name__正在运行快速扫描。"
            },
            no_files_marked_quarantine: '没有文件被标记为“移除”。',
            threats_found : "__product_name__在您的计算机上检测到潜在威胁。",
            no_threats_found : "好消息！扫描过程中未检测到任何威胁。",
            scan_complete_message : "共扫描 __num_items__，用时 __time__。",
            button_apply_actions : "应用操作",
            button_skip_updates: "跳过更新",
            applying_update_packages: "在MetaDefender Drive更新目录中应用包。包__current_package__ / __total_packages__...",
            engines_init: "引擎初始化。",
            applying_update: "应用更新。__product_name__将很快重启……",
            details :  {
                time_elapsed : "已用时间：",
                time_remaining : "剩余时间：",
                items_scanned : "扫描的项目数：",
                total_items : "总项目数：",
                item : "项目："
            },
            results:  {
                scan_results_caption : "发现威胁",
                cleaning_results_caption : "清除威胁",
                file : "文件",
                file_size: "文件大小",
                last_modified: "上一次更改",
                threats : "威胁",
                action : "操作",
                result : "结果",
                cleaning_state: {
                    ignored: "无法移除",
                    disconnected:"驱动器已断开连接",
                    quarantined: "移除",
                    disinfected: "杀毒",
                    manual_clean: "必须手动清理。<br><a href='' onclick='ShowManualCleanModal();'>说明.</a>"
                }
            },
            steps: {
                checking_internet_connection: "检查<BR>网络连接",
                checking_for_product_updates: "检查<BR>产品更新",
                updating_malware_definition: "更新<BR>恶意软件定义库",
                initializing_malware_scanners: "初始化<BR>恶意软件扫描工具",
                scanning_computer: "扫描<BR>这台电脑",
                results: "结果"
            },
            steps_metadefender: {
                checking_internet_connection: "检查<BR> Internet连接",
                checking_for_product_updates: "检查__product_shortname__更新并验证许可证",
                updating_malware_definition: "更新<BR>恶意软件和漏洞定义",
                initializing_malware_scanners: "初始化<BR> __product_shortname__",
                scanning_computer: "使用__product_shortname__扫描恶意软件和漏洞",
                results: "结果"
            },
            endscan: {
                checking_startup_programs: "检查启动程序...",
                checking_hard_links: "正在检查硬链接...",
                checking_lnk_shortcuts: "正在检查Lnk快捷方式...",
                checking_hosts_files: "正在检查主机文件...",
                waiting_on_cloud_scanner: "正在等待Cloud Scanner ..."
            }
        },
        undo: {
            title: "恢复所有隔离项",
            success: "<B>成功恢复所有隔离项!</B>  所有文件都恢复到其原始位置。",
            partial: "<B>隔离部分撤消。</B>某些文件未还原。",
            item_success: "<B>__quarantined_item__</B> 已被恢复到您的计算机中。",
            no_quarantines: "如果您怀疑某些文件移除后导致您的计算机出错，您可以使用恢复功能从特定的扫描阶段恢复所需文件。<BR><BR><B>__product_name__隔离区中已无项目。</B>",
            some_quarantines: "如果您怀疑某些文件移除后导致您的计算机出错，您可以使用恢复功能从下列特定的扫描阶段恢复所需文件。",
            table: {
                caption: "扫描阶段",
                col_date: "日期",
                col_items: "项目",
                col_action: "操作",
                button_undo: "恢复",
                button_undo_item: "恢复隔离项"
            }
        },
        custom: {
            title: "自定义扫描",
            button_apply: "应用",
            select_folders: "选择要扫描的磁盘和文件夹：",
            select_at_least_one_folder: "请至少选择一个文件夹。"
        },
        quick: {
            title: "快速扫描",
            message: "计算机运行很缓慢？快速扫描會检查计算机最常见的受威胁位置。",
            in_progress_message: "快速扫描目前正在进行中......",
            no_file: "<B>要获得最佳的快速扫描结果，请退出__product_name__，重新启动计算机，然后双击__product_name__.exe再次扫描。这能让__product_name__收集有关计算机上主要的其他威胁信息。</ B>",
            button: "开始快速扫描"
        }

    },
    scan_report: {
        header: "扫描报告",
        summary: {
            header: "扫描摘要:",
            scan_type: "扫描类型: ",
            computer_name: "计算机名称: ",
            start_time: "扫描时间: ",
            duration: "持续时间: ",
            app_version: "客户端版本: ",
            live_os_version: "LiveOs 版: ",
            metadefender_drive_os_version: "MetaDefender Drive OS 版: ",
            num_files_scanned: "扫描的文件总数: ",
            num_malware_files: "被感染的文件: ",
            num_vulnerabilities: "总漏洞: "
        },
        definitions: {
            header: "引擎定义版本:",
            definition: "数据库版本: ",
            last_updated: "最近更新时间: "
        },
        threats: {
            header_infections: "威胁报告:",
            header_vulnerabilities: "漏洞:",
            index: "#",
            filename: "文件名",
            size: "文件大小",
            modified: "上一次更改",
            threats: "威胁"
        }
    },
    button_continue_scan_only: "仍要继续",
    button_exit_scan : "退出__product_name__",
    button_see_results : "查看结果",
    button_ok : "确定",
    button_cancel : "取消",
    button_renew: "快速续订",
    button_retry: "重试",
    button_send_email: "发电子邮件",
    undoing_quarantine : "恢复隔离区。请稍等片刻……",
    mounting_disks : "检查您的硬盘驱动器。请稍等片刻……",
    jqgrid : {
        recordtext: "查看第{0}-{1}条记录，共{2}条记录",
        emptyrecords: "无记录",
        loadtext: "加载中……",
        pgtext : "第{0}页，共{1}页"
    }
}

if (GetExternal().IsLocaleSupportedByUi(cn.locale))
{
    arrLocalizedStrings.push(cn);

    // In case of Chinese we also need to add a keyboard input option.
    // Do not want to display the keyboard option if language is ont supported by LiveOS otherwise the keyboard name will show in strange squares.
    g_keyboardOptions.push(["ibus-libpinyin", "中文 (拼)"]);
    g_keyboardOptions.push([cn.locale, cn.localeName]);
}

