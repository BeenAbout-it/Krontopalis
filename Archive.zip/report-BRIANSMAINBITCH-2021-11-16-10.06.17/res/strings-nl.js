var nl = {
    locale: "nl",
    localeName: "Nederlands",
    locale_selector_title: "Aangeboden in:",
    remoteConnection: {
        initializing : "Bezig met het initiëren van een verbinding op afstand..."
    },
    connectDialog: {
        title: "Verbinden met internet",
        click_network_manager: "Klik __img__ rechtsboven aan in je scherm om beschikbare draadloze netwerken te zien.",
        please_plug_wire: "Sluit je computer aan op een beschikbaar netwerk.",
        dialog_will_auto_close: "Deze melding zal automatisch sluiten als er verbinding is.",
        continue_without_internet: "Je kunt doorgaan zonder internet alleen wordt de __product_name__ dan niet ge-update om u tegen de meest recente bedreigingen te beschermen.",
        continue_without_metadefender_update_packages: "<br><b>MetaDefender Core heeft onlangs een update gehad en moet zijn antivirusengine bestanden vernieuwen om te kunnen scannen. Maak verbinding met internet om door te gaan.</b>",
        button_skip: "Sla internet connectie over",
        proxy_url_prompt: "Host:Poort",
        proxy_user_prompt: "Gebruiker",
        proxy_password_prompt: "Wachtwoord",
        enter_proxy_url_dimmed: "Host:poort",
        enter_proxy_user_dimmed: "Alleen indien nodig",
        button_submit_proxy_url: "Ga",
        proxy_setting: "Heeft uw netwerk een HTTP proxy nodig?",
        confirm_invalid_proxy_info: "Ongeldige proxy configuratie",
        confirm_proxy_set : "De HTTP proxy is ingesteld.",
        confirm_proxy_removed : "De HTTP proxy is verwijderd."
    },
    dialogBluetoothMouse: {
        title: 'Bluetooth muis instellen',
        message: "<span class=\"searchingBluetooth\"><B>Zoekt draadloze muis.</B></span><BR>Zorg ervoor dat je draadloze muis \"aan staat.\" Als je een draadloze muis van Apple gebruikt, zet deze dan uit en weer aan. De LED op je muis zal dan gaan knipperen. Als u een ander merk draadloze muis gebruikt, zet deze dan in \"pairing mode.\"<BR><BR>Controleer of de USB kabel goed is aangesloten als je een USB muis wil gebruiken.<BR><BR>Indien de __product_name__ geen connectie maakt met de muis die je wilt gebruiken, dan kun je je computer uitzetten door de uit-knop 5 seconden ingedrukt te houden.",
        details_waiting_for_ack: "Muis gevonden <B>__device_name__.</B>  Indien het koppelen akkoord is, klik op <B>Ga door</B>.  Als uw muis de aanwijzer niet verplaatst en er is een andere muis beschikbaar, dan is het mogelijk dat uw computer probeert een koppeling te maken met een andere draadloze muis.",
        button_ack_mouse: "Ga door"
    },
    dialogInputDevicesIncompatible:{
        title: "Toetsenbord of muis niet compatibel",
        message: "__product_name__ ondervindt problemen met het herkennen van je toetsenbord of muis. Sluit een bekabeld toetsenbord of muis aan om door te gaan met scannen. <br> Als u geen bekabeld toetsenbord of muis hebt, houdt u de aan uit-knop vijf seconden ingedrukt om __product_name__ af te sluiten. <br>",
        confirmed: "&nbsp; Invoerapparaat gevonden! __product_name__ wordt binnenkort voortgezet",
        button_skip_detection: "Ga door"
    },
    dialogPartitionsReadOnly: {
        partitions_journaled: {
            title_all_volumes_journaled: "Alleen scan modus actief",
            title_some_volumes_journaled: "Sommige data locaties zijn alleen te scannen",
            message_all_volumes_journaled: "Alle volumes op deze computer hebben een journaalfunctie. __product_name__ zal deze computer scannen, "
                + "maar om op te ruimen, moet je Factory Upgrade van je __product_name__ maken en vervolgens de scan opnieuw starten. <BR> <BR>",
            message_some_volumes_journaled: "Sommige volumes op deze computer hebben een journaalfunctie. Volumes met journaal uit worden gescand en schoongemaakt, "
                + "maar volumes waarop journaling is ingeschakeld, worden alleen gescand (zodat u ten minste ontdekt of de computer is geïnfecteerd)."
                + "Om schoon te maken, Factory Upgrade uw __product_name__ en start dan de scan opnieuw. <BR> <BR>",
        },
        partitions_readonly_unclean_ntfs: {
            title: "Windows is niet volledig afgesloten",
            message: "Windows is niet volledig afgesloten. Om het risico op misbruik te voorkomen moet je alsjeblieft <BR>"
                     + "&nbsp; 1. Verlaat __product_name__ en start Windows opnieuw op.<BR>"
                     + "&nbsp; 2. Installeer __product_name__ en dubbelklik op <B> __product_name__.exe</B>.<BR>"
                     + "&nbsp; 3. Volg de instructies op het scherm.<BR>"
                     + "Als je Windows, om welke reden dan ook, niet kunt opstarten, klik je op \"Toch doorgaan\"",
        }
    },
    dialogUncleanMountWarning: {
        title: "Windows is niet volledig afgesloten",
        message: "Windows is niet volledig afgesloten. Het opschonen van een computer, die niet volledig is afgesloten, loopt een klein risico op misbruik. Als het mogelijk is, moet je om het risico op misbruik te voorkomen, alsjeblieft <BR>"
                 + "&nbsp; 1. Verlaat __product_name__ en start Windows opnieuw op.<BR>"
                 + "&nbsp; 2. Installeer __product_name__ en dubbelklik op <B> __product_name__.exe</B>.<BR>"
                 + "&nbsp; 3. Volg de instructies op het scherm.<BR>"
                 + "Als je Windows, om welke reden dan ook, niet kunt opstarten, klik je op \"Doorgaan met opschonen\"",
        undo: "Windows is niet volledig afgesloten. Het herstellen van bestanden naar een computer , die niet volledig is afgesloten, loopt een klein risico op misbruik. Als het mogelijk is, moet je om het risico op misbruik te voorkomen, alsjeblieft <BR>"
                 + "&nbsp; 1. Verlaat __product_name__ en start Windows opnieuw op.<BR>"
                 + "&nbsp; 2. Installeer __product_name__ en dubbelklik op <B> __product_name__.exe</B>.<BR>"
                 + "&nbsp; 3. Volg de instructies op het scherm.<BR>"
                 + "Als je Windows, om welke reden dan ook, niet kunt opstarten, klik je op \"Doorgaan met maak ongedaan\"",
        button_cancel: "Annuleer",
        button_continue: "Doorgaan met opschonen",
        button_undo: "Doorgaan met maak ongedaan"
    },
    dialogBluetoothKeyboard: {
        title: 'Bluetooth toetsenbord instellen',
        message: "<span class=\"searchingBluetooth\"><B>Zoekt draadloos toetsenbord.</B></span><BR>Zorg ervoor dat je draadloze toetsenbord \"aan staat.\" Als je een draadloos toetsenbord van Apple gebruikt, zet deze dan uit en weer aan. De LED zou dan moeten gaan knipperen. Als u een ander merk draadloos toetsenbord gebruikt, zet deze dan in \"pairing mode.\".<BR><BR>Check of de USB kabel goed is aangesloten als je een USB toetsenbord wil gebruiken.",
        details_waiting_for_ack: "Toetsenbord gevonden <B>__device_name__.</B>  Indien het koppelen akkoord is, typ <B>\"__pin_code__\"</B> en druk dan op <B>ENTER</B>.",
        pin_acknowledged: "&nbsp;Poging om verbinding te maken",
        pin_error: "Het koppelen is mislukt. Probeer het opnieuw met een nieuwe punaise"
    },
    dialogInputRequired: {
        title: "Druk op een toets of beweeg met de muis",
        message: "__product_name__ wacht op uw invoer. <BR> Als uw toetsenbord of muis niet werkt, sluit dan een bekabeld toetsenbord of muis aan. <BR> Als u geen bekabeld toetsenbord of muis hebt, houdt u de aan uitknop 5 ingedrukt seconden om __product_name__ af te sluiten."
    },
    dialogUsbDisconnect: {
        title: "__product_name__ USB losgekoppeld",
        message: "De __product_name__ is losgekoppeld van de USB poort. Misschien is deze eruit gehaald?<BR><BR>Zet uw PC uit door de uit-knop 5 seconden in te drukken. Probeer daarna de __product_name__ weer op te starten."
    },
    dialogNotAuthorized: {
        title: "Neem contact op met een support medewerker",
        not_authorized_for_pcs: "Deze __product_name__ is alleen voor Mac computers en dit is een PC.<BR> <BR> Als u de verkeerde __product_name__ hebt besteld, kan ons ondersteuningsteam uw __product_name__ gratis naar PC rennen. Stuur een e-mail naar <B> support@__product_name__.com </B>. Neem het serienummer op aan de zijkant van uw __product_name__ in de aanvraag.",
        not_authorized_for_macs: "Deze __product_name__ is alleen voor PC's en dit is een Mac.<BR> <BR> Als u de verkeerde __product_name__ hebt besteld, kan ons ondersteuningsteam uw __product_name__ gratis naar Mac rennen. Stuur een e-mail naar <B> support@__product_name__.com </B>. Neem het serienummer op aan de zijkant van uw __product_name__ in de aanvraag.",
        invalid_serial_number: "Deze __product_name__ is niet geautoriseerd om te starten.",
        no_serial_number: "Sluit de __product_name__ af, plaats hem in een andere USB-poort en probeer het opnieuw. Gebruik je een USB-poort van een printer of een USB hub? Plaats de __product_name__ dan direct in een USB-poort van je computer.",
        opswat_contact_message: "<B>Dien via ons ondersteuningssysteem via https://portal.opswat.com/ een verzoek in of neem contact met ons op via +1(415) 590-7300.</B>",
        ticket_for_support: "Ticket voor support:",
    },
    dialogNotAuthorizedEnterKey: {
        title: "Activeer de __product_name__",
        enter_key: " Voer de product code in om de __product_name__ te activeren.",
        enter_key_dimmed: "Voer de product code in",
        button_continue: "Ga door",
        invalid_key: "Ongeldige code. Probeer het opnieuw."
    },
    dialogExpired : {
        title: "Verlenging vereist",
        message: "Je __product_name__ abonnement is verlopen.<BR><BR>Verleng het abonnement om __product_name__ te kunnen blijven gebruiken.<BR><BR>Dit kan al in minder dan 1 minuut.",
    },
    dialogDeviceCountExceeded: {
        title: "Computers toe te voegen aan uw abonnement",
        message: "Deze __product_name__ is gebruikt op het maximale aantal computers.",
    },
    dialogResultsInfected : {
        title: "Scan Compleet - Infecties gevonden",
        button_clean_computer: "Maak je computer schoon",
        message: "__product_name__ heeft infecties gevonden.<BR><BR>(Om alleen bepaalde bestanden op te schonen, kies \"Resultaten bekijken.\")"
    },
    dialogResultsInfectedButAllJournaled : {
        title: "Scan Voltooid - Infecties gevonden",
        message: "__product_name__ heeft infecties op uw computer aangetroffen. <BR> <BR> Om de bedreigingen op te ruimen, sluit u __product_name__, Factory Upgrade uw __product_name__ en start u __product_name__ opnieuw op."
    },
    dialogResultsFilevaultEmail: {
        title: "Scan Voltooid - Infecties gevonden",
        messageFilevault: "__product_name__ har fundet infektioner på din computer <BR><BR> Fordi dine mængder er krypteret med FileVault, skal disse trusler fjernes manuelt at rengøre de trusler, skal du enten: <BR>"
                 + "&nbsp; 1. Indtast din e-mail nedenfor. Manuelle fjernelse instruktioner vil blive sendt til din indbakke. <BR>",
        messageApfs: "__product_name__ har fundet infektioner på din computer <BR><BR> Fordi dine mængder er formateret med Apfs, skal disse trusler fjernes manuelt at rengøre de trusler, skal du enten: <BR>"
                 + "&nbsp; Indtast din e-mail nedenfor. Manuelle fjernelse instruktioner vil blive sendt til din indbakke. <BR><BR>",
        messageFilevaultContinued: "&nbsp; 2. Exit __product_name__, slå FileVault (besøg support.__product_name__.com og søg \"FileVault\" for at få instruktioner), og derefter genstarte en __product_name__ scanning. Bemærk at slukke FileVault kan tage flere timer at gennemføre. <BR>",
        emailSent: "Email verzonden!",
        emailFailure: "Verzenden van e-mail mislukt. Controleer de internetverbinding en verifieer het e-mailadres.",
        failedValidation: "E-mail is niet geldig. Probeer het opnieuw."
    },
    dialogResultsClean: {
        title: "Scan Voltooid - Geen infecties gevonden",
        message: "Er zijn geen infecties gevonden."
    },
    dialogCleaningDone: {
        title: "Schoonmaken computer",
        action_required: "Actie vereist",
        mac_readonly_message: "Sommige infecties moeten handmatig worden verwijderd. Om handmatig te verwijderen, opnieuw opstarten op uw Mac-besturingssysteem, opent u de __product_name__ USB in Finder en dubbelklikt u op het QUARANTINE-bestand",
        threats_found_but_not_cleaned:"Potentiële bedreigingen werden gedetecteerd, maar er werden geen verwijderd. Deze bedreigingen blijven op uw computer.",
        partial_message: "Alle geselecteerde bedreigingen zijn succesvol in quarantaine gezet, maar er zijn nog potentiële bedreigingen op uw computer.",
        complete_message: "Alle infecties zijn succesvol in quarantaine gezet."
    },
    dialogCleaning: {
        title: "Opschonen computer",
        message: "De __product_name__ is bezig met het opschonen van je computer."
    },
    dialogExit: {
        title: "Sluit de __product_name__",
        message: "Je computer zal afsluiten. Als deze uit staat, verwijder je de __product_name__ en druk je op de aan-/uitknop om opnieuw op te starten.",
    },
    dialogExitWithInfections: {
        title: "Verlaat __product_name__",
        button_exit_anyway: "Toch __product_name__ verlaten",
        message: 'Als je de __product_name__ nu verwijdert, staat er nog steeds schadelijke software op je computer.  Klik "Annuleer" en daarna "Acties doorvoeren" om de schadelijke software in quarantaine te zetten.'
    },
    dialogConfirmUndo: {
        title: "Maak quarantaine ongedaan",
        message: "Alle items die in quarantaine zijn gezet tijdens de geselecteerde scan zullen weer op uw computer worden gezet, inclusief potentiële bedreigingen."
    },
    dialogConfirmUndoItem: {
        title: "Quarantaine ongedaan maken",
        message: "Dit bestand is mogelijk geïnfecteerd. Weet je zeker dat je het wil terugzetten?"
    },
    dialogConfirmImprovementProgram: {
        title: "Kundeforbedringsprogram",
        message: "Ved at tillade os at sende dig en e-mail, du accepterer at automatisk sende diagnostiske data og potentielt skadelige filer til __product_name__ Technologies Inc.",
        button_ok: "E-Mail senden",
        button_cancel: "Afbestille"
    },
    dialogRestartScan: {
        title: "Herstart scan",
        message: "Dit annuleert de huidige scan en start een nieuwe scan."
    },
    dialogEula: {
        title: "__company_name__ licentieovereenkomst voor eindgebruikers",
        button_accept_and_run: "Accepteer en start",
        message: "Lees de licentie voorwaarden",
        improvement_program: "Automatisch verzenden diagnostische gegevens en potentieel kwaadaardige bestanden naar __company_legal_name__."
    },
    dialogDoesNotMeetMinReqs: {
        title: "Systeemeisen",
        message: "Deze pc heeft niet ten minste __min_ram__ intern geheugen, daarom werkt de __product_name__ niet.",
        min_ram: "512 MB",
        min_ram_metadefender_stick: "8 GB"
    },
    dialogLinkEmail: {
        title: "Registreer je __product_name__",
        message: "Voer je e-mail in om deze __product_name__ te registreren.",
        email: "E-mail",
        confirm_email: "Bevestig Email",
        name: "Naam",
        first_name: "Voornaam",
        last_name: "Achternaam",
        registering: "__product_name__ registreren.",
        INVALID_EMAIL: "Het e-mailadres is ongeldig.",
        emails_dont_match: "De e-mails komen niet overeen.",
        button_skip : "Overslaan"
    },
    dialogUnlockFilevault: {
        title: "Nogle af dine mængder er krypteret med Filevault",
        unlocking: "Frigørelse Filevault",
        message: "Indtast venligst din Mac kodeord nedenfor Dit password vil blive brugt til midlertidigt at låse dine mængder til scanning Dit kodeord bliver ikke gemt.",
        metadefender_second_message: "Experimentele functie: als MetaDefender Drive uw volumes niet kan ontgrendelen, moet u FileVault uitschakelen om door te gaan met verwerken. Selecteer \"Turn Off FileVault\" onder het Apple-menu> Systeemvoorkeuren> Beveiliging en privacy onder uw controlepanelen.",
        not_all_drives_unlocked: "Nogle bind forbliver låst prøve en anden Mac-adgangskode for at låse op for disse mængder.",
        could_not_unlock: "Kan ikke låse FileVault prøve en anden Mac-adgangskode Bemærk eksterne drev er ikke i øjeblikket.",
        password: "Mac adgangskode",
        button_skip: "Overslaan"
    },
    dialogFactoryUpgradeInstructionsEmail: {
        title: "ZEND INSTRUCTIES VOOR FABRIEKS UPGRADE",
        header: "Reset naar Fabrieksinstellingen",
        stepsListPartOne: "1. Voer hieronder uw e-mailadres in. Instructies zullen naar uw e-mail worden verzonden.",
        stepsListPartTwo: "2. Sluit __product_name__ af, start uw computer opnieuw op en volg de instructies in de e-mail.<BR>3. Start een nieuwe scan met uw in de fabriek opgewaardeerde __product_name__.",
        emailSent: "E-mail verzonden naar uw inbox!",
        emailFailure: "Verzenden van e-mail mislukt. Controleer de internetverbinding en verifieer het e-mailadres.",
        failedValidation: "E-mail is niet geldig. Probeer het opnieuw.",
        button_skip: "Overslaan"
    },
    dialogSettings:{
        title: "instellingen",
        button_send_instructions: "Verzend instructies"
    },
    dialogLoadingRenewal: {
        title: "Licentie verlenging wordt geladen"
    },
    notif : {
        take_a_break: {
            title: "Neem even pauze!",
            title_metadefender: "De scan is gestart",
            message: "Deze scan duurt tussen de 30 minuten en een paar uur. Je hulp is niet nodig tot het einde.",
            message_plug_suffix: '<BR><BR>Plug de adapter in zodat je computer niet zonder stroom komt te zitten tijdens de scan.'
        },
        recovered_from_crash: {
            title: "Automatische opnieuw opstarten",
            message: "De laatste __product_name__ scan heeft een incident gevonden.. maakt u zich geen zorgen. We hebben het gezien en automatisch een andere scan gestart, beginnend bij het punt waar de vorige is gestopt. Bedankt voor uw aandacht."
        },
        restored_dnsapi_dll: {
            title: "Herstelde systeembestand",
            message: "__product_name__ opgespoord en hersteld van een ontbrekende kritische systeem bestand met de naam Dnsapi.dll."
        },
        restored_netfilter2_sys: {
            title: "Onjuist in quarantaine geplaatst bestand hersteld",
            message: "__product_name__ heeft een verkeerd in quarantaine geplaatst bestand met de naam netfilter2.sys gedetecteerd en automatisch hersteld.<BR>Als u geen scan wilt uitvoeren, kunt u __product_name__ nu veilig afsluiten door op de X in de rechterbovenhoek te klikken."
        },
        right_click_detected: {
            title: "Gebruikt u de juiste muisknop?",
            message: "__product_name__ vraagt je om de linker muisknop te gebruiken (zelfs als je linkshandig bent ;))."
        },
        left_click: {
            title: "Tip",
            message: "Als links klikken niet werkt, druk dan op \"Tab\" totdat de juiste knop is geselecteerd. Druk daarna op \"Enter\"."
        },
        bluetooth_reconnect: {
            title: "Bluetooth Tip",
            message: "Wees niet verrast als je computer je vraagt om een Bluetooth apparaat te repareren nadat je __product_name__ hebt verlaten en je computer opnieuw hebt opgestart. Dit is normaal."
        },
        device_pci: {
            title: "Niet ondersteunde netwerkkaart",
            message: "Stuur een e-mail naar support@__product_name__.com met onderstaande informatie zodat we ondersteuning voor deze netwerkkaart kunnen toevoegen. <BR>"
        },
        keyboard_layout: {
            title: "Ongewone tekens?",
            message: "Zie je tijdens het typen rare tekens?<BR>Klik dan op <i class=\"fa fa-keyboard-o\" aria-hidden=\"true\"></i> om de juiste toetsenbord indeling te kiezen."
        },
        scan_report: {
            title: "Scanrapport gegenereerd",
            message: "Raadpleeg het rapport in de directory 'reports' op uw __product_name__!",
            message_meta_defender_stick: "__scan_report_path__ gegenereerd, neem een ​​kijkje in de NTFS-partitie van uw __product_name__-apparaat voor gedetailleerde scanresultaten!"
        },
    },
    action: {
        keep: "Behouden",
        quarantine: "Quarantaine",
        journaled: "Fabrieksupgrade en opnieuw scannen om schoon te maken",
        readonly_non_journaled: "Af te sluiten en opnieuw starten van Run__product_name__.exe om schoon te maken",
        manual_clean: "Skal manuelt rengøres.<br><a href='' onclick='ShowManualCleanModal();'>Instrukser.</a>"
    },
    time: {
        day: "__count__ dag",
        day_plural: "__count__ dagen",
        hour: "__count__ uur",
        hour_plural: "__count__ uren",
        minute: "__count__ minuut",
        minute_plural: "__count__ minuten",
        second: "__count__ seconde",
        second_plural: "__count__ seconden",
        ago: "__time__ geleden",
        calculating: "Berekenen...",
        complete : "Klaar",
        left : "nog te gaan",
        several_hours: "Enkele uren"
    },
    accordion: {
        scan: {
            title: "Scannen",
            filevault_configuration_not_supported: "Deze Mac gebruikt een FileVault-configuratie die nog niet door __product_name__ wordt ondersteund. Volumes die zijn gecodeerd met FileVault, worden niet gescand.",
            filevault_need_to_factory_upgrade: "Uw __product_name__ heeft een gratis, eenmalige fabrieksupgrade nodig om te kunnen omgaan met een technologie die door uw Mac wordt gebruikt (FileVault).<br> <a href=\"#\" onclick='return ShowFactoryUpgradeInstructionsSendingModal(\"MAC\");'>Klik hier</a> om uzelf een e-mail te sturen over het upgraden van de fabriek en vervolgens een nieuwe scan te starten.",
            apfs_need_to_factory_upgrade: "Uw __product_name__ heeft een gratis, eenmalige fabrieksupgrade nodig om te kunnen omgaan met een technologie die door uw Mac wordt gebruikt (APFS).<br> <a href=\"#\" onclick='return ShowFactoryUpgradeInstructionsSendingModal(\"MAC\");'>Klik hier</a> om uzelf een e-mail te sturen over het upgraden van de fabriek en vervolgens een nieuwe scan te starten.",
            status: {
                need_to_run_chk_disk: "Sommige van uw partities bevinden zich in een onveilige staat en kunnen niet worden gescand. U moet een opdracht voor schijfcontrole uitvoeren vanuit Windows. Ga naar 'www.fixmestick.com/run-chkdsk' voor instructies.",
                at_least_one_partition_read_only: "Windows is niet volledig afgesloten. Verlaat, indien mogelijk __product_name__, start Windows opnieuw op en voer een scan uit met __product_name__.exe.",
                at_least_one_partition_journaled: "Sommige volumes zijn geregistreerd en kunnen niet worden opgeschoond. Om dit te kunnen herstellen, moet je onze website bezoeken en je __product_name__ updaten.",
                encryption_detected: "De __product_name__ kan een of meerdere van uw BitLocker-geëncrypteerde schijven niet scannen.",
                encryption_detected_metadefender: "Er zijn een of meer volumes gecodeerd en die kunnen niet worden gescand. Om deze volumes te kunnen scannen, start je Windows opnieuw op en volg je de instructies in de 'README.txt' in de /tools/bitlocker in het NTFS-gedeelte van jouw stick.",
                hfs_filevault_detected: "Een of meer volumes zijn gecodeerd met een eerdere versie van Apple Filevault en kunnen niet worden gescand. Schakel Filevault uit macOs uit en start __product_name__ opnieuw om deze volumes te scannen.",
                apfs_filevault_detected: "Een of meer volumes zijn gecodeerd met Apple Filevault.",
                hfs_filevault_detected_metadefender: "Een of meer volumes zijn gecodeerd met een eerdere versie van Apple Filevault en kunnen niet worden gescand. Selecteer \"Turn Off FileVault\" onder het Apple-menu> Systeemvoorkeuren> Beveiliging en privacy onder uw controlepanelen.",
                apfs_filevault_detected_metadefender: "Een of meer volumes zijn gecodeerd met Apple Filevault. <br> <br> Versleutelde volumes: __encrypted_volumes__",
                safe: "Computer status: Veilig.  ",
                safe_so_far: "Computer status: Tot nu toe veilig.",
                safe_so_far_metadefender: "Computer status: Bezig met onderzoek.",
                not_safe: "Computer status: Risico.",
                not_safe_review_when_finished: "Eerste scan resultaten laten zien dat er waarschijnlijk bedreigende software aanwezig is op je systeem. Je kunt de details hiervan bekijken als de scan klaar is.",
                safe_all_infections_quarantined: "Alle infecties zijn in quarantaine gezet.",
                throttling_too_hot: "De computer wordt erg heet. De scan gaat langzamer om oververhitting te voorkomen.",
                keep_cool_mode: 'Keep cool modus is geactiveerd',
                reduced_functionality:"__product_name__ wordt uitgevoerd in de resourcebesparende modus.",
                quick_scan:"__product_name__ voert een snelle scan uit."
            },
            no_files_marked_quarantine: 'Er zijn geen bestanden geselecteerd voor "Quarantaine".',
            threats_found : "__product_name__ heeft mogelijke bedreigingen gedetecteerd op je computer.",
            no_threats_found : "Goed nieuws! Er zijn tijdens deze scan geen bedreigingen gedetecteerd op je computer.",
            scan_complete_message : "Scan van __num_items__ items is klaar in __time__.",
            button_apply_actions : "Acties toepassen",
            button_skip_updates: "Sla updates over",
            applying_update_packages: "Pakketten toepassen in de MetaDefender forensische stick-updatemap. Pakket __current_package__ van __total_packages__...",
            engines_init: "motoren geïnitialiseerd.",
            applying_update: "Update aan het uitvoeren. __product_name__ zal binnen enkele ogenblikken opnieuw opstarten...",
            details :  {
                time_elapsed : "Verstreken tijd:",
                time_remaining : "Resterende tijd:",
                items_scanned : "Gescande items:",
                total_items : "Totaal aantal items:",
                item : "Item:"
            },
            results:  {
                scan_results_caption : "Gevonden bedreiging(en)",
                cleaning_results_caption : "Opschoon resultaten",
                file : "File",
                file_size: "Bestandsgrootte",
                last_modified: "Laatst gewijzigd",
                threats : "Bedreigingen",
                action : "Actie",
                result : "Resultaat",
                cleaning_state: {
                    ignored: "Kon niet verwijderen",
                    quarantined: "In quarantaine gezet",
                    disinfected: "Gedesinfecteerd",
                    manual_clean: "Skal manuelt rengøres.<br><a href='' onclick='ShowManualCleanModal();'>Instrukser.</a>"
                }
            },
            steps: {
                checking_internet_connection: "Internet connectie<BR>wordt gecheckt",
                checking_for_product_updates: "Product updates<BR>controleren",
                updating_malware_definition: "Malware definities<BR>worden bijgewerkt",
                initializing_malware_scanners: "Malware scanners<BR>initialiseren",
                scanning_computer: "Computer<BR>wordt gescand",
                results: "Resultaten"
            },
            steps_metadefender: {
                checking_internet_connection: "Überprüfen Sie die Internetverbindung",
                checking_for_product_updates: "Controleren op updates van __product_shortname__ en validatie van de licentie",
                updating_malware_definition: "Aktualisierung der Malware- und Sicherheitslücken-Definition",
                initializing_malware_scanners: "__product_shortname__ initialisieren",
                scanning_computer: "Scannen nach Malware und Sicherheitslücken mit __product_shortname__",
                results: "Ergebnisse"
            }
        },
        undo: {
            title: "Maak quarantaine ongedaan",
            success: "<B>Quarantaine succesvol ongedaan gemaakt!</B>  Alle bestanden zijn terug geplaatst naar hun originele locatie.",
            item_success: "<B>__quarantined_item__</B> is op je computer teruggezet.",
            no_quarantines: "Gebruik 'ongedaan maken' om bestanden van een bepaalde scan sessie te verplaatsen als je vermoedt dat sommige verwijderde bestanden fouten op je computer hebben veroorzaakt.<BR><BR><B>Er staan geen items in de __product_name__ quarantaine.</B>",
            some_quarantines: "Gebruik 'ongedaan maken' om bestanden van een bepaalde scan sessie zoals hieronder vermeldt te verplaatsen als je vermoedt dat sommige verwijderde bestanden fouten op je computer hebben veroorzaakt.",
            table: {
                caption: "Scan sessie(s)",
                col_date: "Datum",
                col_items: "Items",
                col_action: "Actie",
                button_undo: "Maak ongedaan",
                button_undo_item: "Ongedaan maken"
            }
        },
        custom: {
            title: "Aangepaste scan",
            button_apply: "Pas toe",
            select_folders: "Selecteer de schijf en mappen die u wilt scannen:",
            select_at_least_one_folder: "Selecteer tenminste 1 map."
        },
        quick: {
            title: "Quick Scan",
            message: "Heb je weinig tijd? Quick Scan controleert systeemgebieden waar de meest veelvoorkomende bedreigingen in voorkomen.",
            in_progress_message: "Quick scan is bezig ...",
            no_file: "<B>Voor de beste Quick Scan resultaten sluit je __product_name__ af, herstart je je computer, en start je een nieuwe scan door tweemaal op __product_name__.exe te klikken. Hierdoor kan __product_name__ extra informatie verzamelen over actieve bedreigingen op je computer.</B>",
            button: "Start Quick Scan"
        }
    },
    scan_report: {
        header: "Scanbericht",
        summary: {
            header: "Scan-Zusammenfassung:",
            scan_type: "Scan type: ",
            computer_name: "Computername: ",
            start_time: "Scan Zeit: ",
            duration: "Dauer: ",
            app_version: "Anwendungsversion: ",
            live_os_version: "LiveOs-Version: ",
            metadefender_drive_os_version: "MetaDefender Drive OS Version: ",
            num_files_scanned: "Gescannte Dateien insgesamt: ",
            num_malware_files: "Infizierte Dateien: ",
            num_vulnerabilities: "Totale kwetsbaarheden: "
        },
        definitions: {
            header: "Engine-Definitionsversionen:",
            definition: "DB-versie: ",
            last_updated: "Laatst bijgewerkt: "
        },
        threats: {
            header_infections: "Bedrohungsbericht:",
            header_vulnerabilities: "Kwetsbaarheden:",
            index: "#",
            filename: "Dateiname",
            size: "Dateigröße",
            modified: "Zuletzt bearbeitet",
            threats: "Bedrohungen"
        }
    },
    button_continue_scan_only: "Toch doorgaan",
    button_exit_scan : "__product_name__ afsluiten",
    button_see_results : "Zie resultaten",
    button_ok : "OK",
    button_cancel : "Annuleer",
    button_renew: "Snel verlengen",
    button_retry: "Opnieuw proberen",
    button_send_email: "Verzend e-mail",
    undoing_quarantine : "Quarantine wordt ongedaan gemaakt. Gelieve even te wachten.",
    mounting_disks : "Uw harde schijven worden onderzocht. Een ogenblik geduld a.u.b...",
    jqgrid : {
        recordtext: "Bekijk {0} - {1} van {2}",
        emptyrecords: "Geen records om te bekijken",
        loadtext: "Aan het laden...",
        pgtext : "Bladzijde {0} van {1}"
    }
}

if (GetExternal().IsLocaleSupportedByUi(nl.locale))
{
    arrLocalizedStrings.push(nl);
}
