var en = {
    locale: "en",
    localeName: "English",
    locale_selector_title: "Offered in:",
    remoteConnection: {
        initializing : "Initiating Remote Connection..."
    },
    connectDialog: {
        title: "Connect to your Network",
        click_network_manager: "Click __img__ at the top right of your screen to view available wireless networks.",
        please_plug_wire: "Please plug your computer into a wired network.",
        dialog_will_auto_close: "This dialog will automatically close when a connection is established.",
        continue_without_internet: "You can continue without an Internet connection, but __product_name__ will not get updates to protect you from the latest threats.",
        continue_without_metadefender_update_packages: "<br><b>MetaDefender Core has recently had an update and must refresh its anti-virus engine files in order to scan. Please connect to the Internet to continue.</b>",
        button_skip: "Skip Internet Connection",
        proxy_url_prompt: "Host:Port",
        proxy_user_prompt: "User",
        proxy_password_prompt: "Password",
        enter_proxy_url_dimmed: "host:port",
        enter_proxy_user_dimmed: "Only if required",
        button_submit_proxy_url: "Set",
        proxy_setting: "Does your network require an HTTP proxy?",
        confirm_invalid_proxy_info: "Invalid proxy configuration",
        confirm_proxy_set : "The HTTP proxy has been set.",
        confirm_proxy_removed : "The HTTP proxy has been removed."
    },
    dialogBluetoothMouse: {
        title: 'Bluetooth Mouse Setup',
        message: "<span class=\"searchingBluetooth\"><B>Searching for wireless mouse.</B></span><BR>Make sure your wireless mouse is \"discoverable.\" If you are using an Apple wireless mouse, turn it off and then on.  The LED on your mouse should start flashing.  If you are using a non-Apple wireless mouse, put it in \"pairing mode.\"<BR><BR>Check your cables if you expect to use a USB mouse.<BR><BR>If the __product_name__ fails to connect with your mouse, you can turn off your computer by holding down the power button for 5 seconds.",
        details_waiting_for_ack: "Found mouse <B>__device_name__.</B>  To acknowledge pairing, click <B>Continue</B>.  If your mouse doesn't move the pointer and there is another wireless mouse available, then your computer may be trying to pair with another wireless mouse.",
        button_ack_mouse: "Continue"
    },
    dialogInputDevicesIncompatible:{
        title: "Keyboard or Mouse Incompatible",
        message: "__product_name__ is having difficulty recognizing your keyboard or mouse. Please attach a wired keyboard or mouse to continue to scan.<br> If you don't have a wired keyboard or mouse, hold down the power button for 5 seconds to exit __product_name__.<br>",
        confirmed: "&nbsp; Input Device Found! __product_name__ will continue shortly.",
        button_skip_detection: "Continue"
    },
    dialogPartitionsReadOnly: {
        partitions_journaled: {
            title_all_volumes_journaled: "Scan-only mode",
            title_some_volumes_journaled: "Some volumes are in scan-only mode",
            message_all_volumes_journaled: "All volumes on this computer have journaling on.  __product_name__ will scan this computer, "
                + "but to clean, you'll have to Factory Upgrade your __product_name__ and then restart the scan.<BR><BR>",
            message_some_volumes_journaled: "Some volumes on this computer have journaling on.  Volumes with journaling off will be scanned and cleaned, "
                + "but volumes with journaling on will only be scanned (so you will at least discover if the computer is infected). "
                + " To clean, Factory Upgrade your __product_name__ and then restart the scan.<BR><BR>",
        },
        partitions_readonly_unclean_ntfs: {
            title: "Windows did not fully shutdown",
            message: "Windows did not fully shutdown. To prevent any risk of corruption, please: <BR>"
                + "&nbsp; 1. Exit __product_name__ and restart Windows.<BR>"
                + "&nbsp; 2. Insert __product_name__ and double-click <B>__product_name__.exe</B>.<BR>"
                + "&nbsp; 3. Follow the on-screen instructions.<BR>"
                + "If you unable to restart Windows for any reason, click \"Proceed Anyway\""
        }
    },
    dialogUncleanMountWarning: {
        title: "Windows did not fully shutdown.",
        message: "Windows did not fully shutdown. Cleaning a computer that did not fully shut down has a very small risk of causing corruption. If possible, to prevent any risk of corruption, please<BR>"
                 + "&nbsp; 1. Exit __product_name__ and restart Windows.<BR>"
                 + "&nbsp; 2. Insert __product_name__ and double-click <B>__product_name__.exe</B>.<BR>"
                 + "&nbsp; 3. Follow the on-screen instructions.<BR>"
                 + "If you are unable to start Windows for any reason, click \"Proceed to Clean\"",
        undo: "Windows did not fully shutdown. Restoring files to a computer that did not fully shut down has a very small risk of causing corruption. If possible, to prevent any risk of corruption, please<BR>"
                 + "&nbsp; 1. Exit __product_name__ and restart Windows.<BR>"
                 + "&nbsp; 2. Insert __product_name__ and double-click <B>__product_name__.exe</B>.<BR>"
                 + "&nbsp; 3. Follow the on-screen instructions.<BR>"
                 + "If you are unable to start Windows for any reason, click \"Proceed to Undo Quarantine\"",
        button_cancel: "Cancel",
        button_continue: "Proceed to Clean",
        button_undo: "Proceed to Undo Quarantine"
    },
    dialogBluetoothKeyboard: {
        title: 'Bluetooth Keyboard Setup',
        message: "<span class=\"searchingBluetooth\"><B>Searching for wireless keyboard.</B></span><BR>Make sure your wireless keyboard is \"discoverable.\" If you are using an Apple wireless keyboard, turn it off and then on.  The LED on your keyboard should start flashing.  If you are using a non-Apple wireless keyboard, put it in \"pairing mode.\".<BR><BR>Check your cables if you expect to use a USB keyboard.",
        details_waiting_for_ack: "Found keyboard <B>__device_name__.</B>  To acknowledge pairing, type <B>\"__pin_code__\"</B> and then hit <B>ENTER</B>.",
        pin_acknowledged: "&nbsp; Attempting to Connect",
        pin_error: "Pairing failed. Please retry with new pin"
    },
    dialogInputRequired: {
        title: "Please press a key or move your mouse",
        message: "__product_name__ is waiting for your input.<BR>If your keyboard or mouse is not working, please connect a wired keyboard or mouse.<BR>If you don't have a wired keyboard or mouse, please hold down the power button for 5 seconds to exit __product_name__."
    },
    dialogUsbDisconnect: {
        title: "__product_name__ USB Disconnected",
        message: "The __product_name__ has disconnected from the USB port. Perhaps it got knocked?<BR><BR>Please power down the PC by holding down the power button for 5 seconds and try running __product_name__ again."
    },
    dialogNotAuthorized: {
        title: "Please Contact Support",
        not_authorized_for_pcs: "This __product_name__ is for Macs only and this is a PC.<BR><BR> If you ordered the wrong __product_name__, our support team can convert your __product_name__ to run on PC for free. Please send an email to <B>support@__product_name__.com</B>. Include the serial number from the side of your __product_name__ in the request.<BR><BR>",
        not_authorized_for_macs: "This __product_name__ is for PCs only and this is Mac. <BR><BR> If you ordered the wrong __product_name__, our support team can convert your __product_name__ to run on Mac for free. Please send an email to <B>support@__product_name__.com</B>. Include the serial number from the side of your __product_name__ in the request.<BR><BR>",
        invalid_serial_number: "This __product_name__ is not authorized to run.  If your __product_name__ is plugged into a hub or printer, please exit __product_name__, plug it into your computer directly, and try again.<BR><BR>",
        no_serial_number: "Please exit __product_name__, plug it into a different USB port and try again.  If your __product_name__ is plugged into a hub or printer, please try plugging it directly into your computer.<BR><BR>",
        contact_information: "<BR><BR>&nbsp;&nbsp;&nbsp;e. help@__product_name__.com<BR>&nbsp;&nbsp;&nbsp;w. support.__product_name__.com",
        opswat_contact_message: "<B>Please file a ticket through our support system at https://portal.opswat.com/, or contact us at +1(415) 590-7300.</B><BR><BR>",
        ticket_for_support: "Ticket for support:"
    },
    dialogNotAuthorizedEnterKey: {
        title: "Activate __product_name__",
        enter_key: "Please enter the product key to activate __product_name__.",
        enter_key_dimmed: "Enter product key",
        button_continue: "Continue",
        invalid_key: "Invalid key.  Please try again."
    },
    dialogExpired : {
        title: "Renewal Required",
        message: "Your __product_name__ subscription has expired.<BR><BR>Renew your subscription to continue using your __product_name__.<BR><BR>Renewing your __product_name__ takes less than a minute.",
    },
    dialogDeviceCountExceeded: {
        title: "Add computers to your subscription",
        message: "This __product_name__ has been used on the maximum number of computers.",
    },
    dialogResultsInfected : {
        title: "Scan Complete - Infections Found",
        button_clean_computer: "Clean Computer",
        message: "__product_name__ has found infections on your computer.<BR><BR>(To clean only certain files, select \"See Results.\")",
    },
    dialogResultsInfectedButAllJournaled : {
        title: "Scan Complete - Infections Found",
        message: "__product_name__ has found infections on your computer.<BR><BR> To clean the threats, please exit __product_name__, Factory Upgrade your __product_name__, and then restart __product_name__."
    },
    dialogResultsFilevaultEmail: {
        title: "Action Required",
        messageFilevault: "__product_name__ has found infections on your computer.<BR><BR> Because your volumes are encrypted with FileVault, these threats must be manually removed.  To clean the threats, please either: <BR>"
                 + "&nbsp; 1. Enter your email below.  Manual removal instructions will be sent to your inbox. <BR>",
        messageApfs: "__product_name__ has found infections on your computer.<BR><BR> Because your volumes are formatted with Apfs, these threats must be manually removed.  To clean the threats, please enter your email below.  Manual removal instructions will be sent to your inbox. <BR><BR>",
        messageFilevaultContinued: "&nbsp; 2. Exit __product_name__, turn off FileVault (visit support.__product_name__.com and search “FileVault” for instructions), and then restart a __product_name__ scan.  Note turning off FileVault can take several hours to complete. <BR>",
        emailSent: "Email sent to your inbox!",
        emailFailure: "Failed to send e-mail. Check internet connection and verify e-mail address.",
        failedValidation: "Email is not valid. Please try again."
    },
    dialogResultsClean: {
        title: "Scan Complete - No Infections Found",
        message: "No infections were found."
    },
    dialogCleaningDone: {
        title: "Cleaning Computer",
        action_required: "Action Required",
        threats_found_but_not_cleaned: "Potential threats were detected but none were removed. These threats remain on your computer.",
        partial_message: "All selected threats were successfully removed, but potential threats remain on your computer.",
        mac_readonly_message: "Some threats need to be manually removed. To manually remove, reboot into your Mac operating system, open the __product_name__ USB in Finder and double-click the QUARANTINE file",
        complete_message: "All infections were successfully removed."
    },
    dialogCleaning: {
        title: "Cleaning Computer",
        message: "The __product_name__ is cleaning your computer."
    },
    dialogExit: {
        title: "Exiting __product_name__",
        message: "Your computer will shutdown.  When it is off, please remove the __product_name__ and press the power button to restart.",
        macQuarantineScript: "Your computer will shutdown.  When it is off, please leave the  __product_name__ plugged in and press the power button to restart."
    },
    dialogExitWithInfections: {
        title: "Exiting __product_name__",
        button_exit_anyway: "Exit Anyway",
        message: 'If you exit __product_name__ now, malicious software might still exist on your computer.  Click "Cancel" and then "Apply Actions" to remove the malicious software.'
    },
    dialogConfirmUndo: {
        title: "Undo Quarantine",
        message: "All items that were removed during the selected scan will be restored to your computer, including potential threats."
    },
    dialogConfirmUndoItem: {
        title: "Undo Quarantined Item",
        message: "This item is a potential threat. Are you sure you want to restore it to your computer?"
    },
    dialogConfirmImprovementProgram: {
        title: "Customer Improvement Program",
        message: "By allowing us to send you an e-mail you agree to automatically send diagnostic data and potentially malicious files to __product_name__ Technologies Inc.",
        button_ok: "Send E-mail",
        button_cancel: "Cancel"
    },
    dialogRestartScan: {
        title: "Restart Scan",
        message: "This will cancel the current scan and restart a new scan."
    },
    dialogEula: {
        title: "__company_name__ End User License Agreement",
        button_accept_and_run: "Accept and Run",
        message: "Please read the license terms",
        improvement_program: "Automatically send diagnostic data and potentially malicious files to __company_legal_name__."
    },
    dialogDoesNotMeetMinReqs: {
        title: "System Requirements",
        message: "This PC does not have at least __min_ram__ of RAM, so __product_name__ cannot run.",
        min_ram: "512 MB",
        min_ram_metadefender_stick: "8 GB"
    },
    dialogLinkEmail: {
        title: "Register your __product_name__",
        message: "Please enter your email to register your __product_name__.",
        email: "Email",
        confirm_email: "Confirm Email",
        name: "Name",
        first_name: "First Name",
        last_name: "Last Name",
        registering: "Registering your __product_name__.",
        INVALID_EMAIL: "The email address is invalid.",
        emails_dont_match: "The emails don't match.",
        button_skip : "Skip"
    },
    dialogUnlockFilevault: {
        title: "Some of your volumes are encrypted with Filevault",
        unlocking: "Unlocking Filevault",
        message: "Please enter your Mac password below. Your password will be used to temporarily unlock your volumes for scanning. Your password will not be stored.",
        metadefender_second_message: "Experimental Feature: If MetaDefender Drive fails to unlock your volumes you will have to disable FileVault to continue processing. Please select \"Turn Off FileVault\" under the Apple Menu > System Preferences > Security & Privacy under your control panels.",
        not_all_drives_unlocked: "Some volumes remain locked. Please try a different Mac password to unlock these volumes.",
        could_not_unlock: "Unable to unlock FileVault.  Please try a different Mac password. Note external drives are not currently supported.",
        password: "Mac Password",
        button_skip: "Skip"
    },
    dialogSettings: {
        title: "Settings",
        button_send_instructions: "Send Instructions"
    },
    dialogFactoryUpgradeInstructionsEmail: {
        title: "SEND INSTRUCTIONS FOR FACTORY UPGRADE",
        header: "Reset to Factory Settings",
        stepsListPartOne: "1. Enter your email below. Instructions will be sent to your email.",
        stepsListPartTwo: "2. Exit __product_name__, restart your computer, and follow the instructions in the email.<BR>3. Start another scan with your factory upgraded __product_name__.",
        emailSent: "Email sent to your inbox!",
        emailFailure: "Failed to send e-mail. Check internet connection and verify e-mail address.",
        failedValidation: "Email is not valid. Please try again.",
        button_skip: "Skip"
    },

    dialogLoadingRenewal: {
        title: "Loading Express Renewal"
    },
    notif : {
        take_a_break: {
            title: "You can go take a break!",
            title_metadefender: "The scan has started",
            message: "This scan could take up to a few hours.  Your input will not be needed until the very end.",
            message_plug_suffix: '<BR><BR>Please plug in the AC adapter so your computer does not run out of power during the scan.'
        },
        recovered_from_crash: {
            title: "Automatic restart",
            message: "The last __product_name__ scan hit an issue.  Not to worry... we noticed and automatically launched another scan resuming from where the last one left off. Just wanted to let you know."
        },
        restored_dnsapi_dll: {
            title: "Restored system file",
            message: "__product_name__ detected and restored a missing critical system file named dnsapi.dll."
        },
        restored_netfilter2_sys: {
            title: "Restored incorrectly quarantined file",
            message: "__product_name__ detected and automatically restored an incorrectly quarantined file named netfilter2.sys.<BR>If you don't want to run a scan, you can now safely exit __product_name__ by clicking the X in the upper right corner."
        },
        right_click_detected: {
            title: "Are you using the right mouse button?",
            message: "__product_name__ needs you to use the left mouse button (even if you're left handed ;))."
        },
        left_click: {
            title: "Tip",
            message: "If left clicking doesn't seem to be working, you can hit \"Tab\" until a button is selected and then hit \"Enter\"."
        },
        bluetooth_reconnect: {
            title: "Bluetooth Tip",
            message: "Do not be alarmed if your computer prompts you to re-pair your Bluetooth device after you exit __product_name__ and restart your computer. This is normal."
        },
        device_pci: {
            title: "Unsupported Network Card",
            message: "Please email support@__product_name__.com with the information below so we can add support for your network card.<BR>"
        },
        keyboard_layout: {
            title: "Unusual Characters",
            message: "Typing and not seeing the characters you expect?<BR>Click on the <i class=\"fa fa-keyboard-o\" aria-hidden=\"true\"></i> icon to change your keyboard."
        },
        scan_report: {
            title: "Scan Report Generated",
            message: "Please see the report in the 'reports' directory on your __product_name__!",
            message_meta_defender_stick: "__scan_report_path__ generated, take a look in the NTFS partition of your __product_name__ device for your detailed scan results!"
        },
    },
    action: {
        keep: "Keep",
        quarantine: "Remove",
        journaled: "Factory Upgrade and re-scan to clean",
        readonly_non_journaled: "Exit and re-launch from Run__product_name__.exe in order to clean",
        manual_clean: "Must be manually cleaned.<br><a href='' onclick='ShowManualCleanModal();'>Instructions.</a>"
    },
    time: {
        day: "__count__ day",
        day_plural: "__count__ days",
        hour: "__count__ hour",
        hour_plural: "__count__ hours",
        minute: "__count__ minute",
        minute_plural: "__count__ minutes",
        second: "__count__ second",
        second_plural: "__count__ seconds",
        ago: "__time__ ago",
        calculating: "Calculating...",
        complete : "Complete",
        left : "left",
        several_hours: "Several hours..."
    },
    accordion: {
        scan: {
            title: "Scan",
            filevault_configuration_not_supported: "This Mac uses a FileVault encryption configuration which is not presently supported by __product_name__. Volumes encrypted with FileVault will not be scanned.",
            filevault_need_to_factory_upgrade: "Your __product_name__ needs a free, one-time factory upgrade to handle a technology your Mac is using (FileVault).<br> Please <a href=\"#\" onclick='return ShowFactoryUpgradeInstructionsSendingModal(\"MAC\");'>click here</a> to send yourself an email on how to factory upgrade and then launch another scan.",
            apfs_need_to_factory_upgrade: "Your __product_name__ needs a free, one-time factory upgrade to handle a technology your Mac is using (APFS).<br> Please <a href=\"#\" onclick='return ShowFactoryUpgradeInstructionsSendingModal(\"MAC\");'>click here</a> to send yourself an email on how to factory upgrade and then launch another scan.",
            status: {
                need_to_run_chk_disk: "Some of your partitions are in an unsafe state and can not be scanned. You will need to exit the scan and run a check disk command from Windows. Please visit 'fixmestick.com/run-chkdsk' for instructions.",
                at_least_one_partition_read_only: "Windows did not fully shutdown. If possible, exit __product_name__, restart Windows, and start a scan using __product_name__.exe.",
                at_least_one_partition_journaled: "Some volumes are journaled and can't be cleaned. To fix this, please visit our website and update your __product_name__.",
                encryption_detected: "One or more volumes are encrypted and cannot be scanned. To scan these volumes, please restart __product_name__ from Windows and follow the instructions.",
                encryption_detected_metadefender: "One or more volumes are encrypted and cannot be scanned. To scan these volumes, please restart from Windows, and follow the instructions in 'README.txt' in the /tools/bitlocker folder in the NTFS partition of your stick.",
                hfs_filevault_detected: "One or more volumes are encrypted with an earlier version of Apple Filevault and cannot be scanned. Please disable Filevault from macOs and restart __product_name__ to scan these volumes.",
                apfs_filevault_detected: "One or more volumes are encrypted with Apple Filevault.",
                hfs_filevault_detected_metadefender: "One or more volumes are encrypted with an earlier version of Apple Filevault and cannot be scanned. Please select \"Turn Off FileVault\" under the Apple Menu > System Preferences > Security & Privacy under your control panels.",
                apfs_filevault_detected_metadefender: "One or more volumes are encrypted with Apple Filevault.",
                safe: "Computer status: Safe.  ",
                safe_so_far: "Computer status: Safe so far.",
                safe_so_far_metadefender: "Computer status: Examination in progress.",
                not_safe: "Computer status: At risk.",
                not_safe_review_when_finished: "Preliminary scan results show that malicious software might exist on your system. You can review detected items when the scan has completed.",
                safe_all_infections_quarantined: "All infections were removed.",
                throttling_too_hot: "The computer is getting very hot.  The scan is slowing down to prevent overheating.",
                keep_cool_mode: 'Activated keep cool mode',
                reduced_functionality:"__product_name__ is running in resource-saving mode.",
                quick_scan:"__product_name__ is running a Quick Scan"
            },
            no_files_marked_quarantine: 'No files are marked "Remove".',
            threats_found : "__product_name__ detected potential threats on your computer.",
            no_threats_found : "Good news! No threats were detected on your computer during this scan.",
            scan_complete_message : "Scan of __num_items__ items completed in __time__.",
            button_apply_actions : "Apply Actions",
            button_skip_updates: "Skip Updates",
            applying_update_packages: "Applying Packages in MetaDefender Drive Update Directory. Package __current_package__ of __total_packages__...",
            engines_init: "engines initialized.",
            applying_update: "Applying update. __product_name__ will restart shortly...",
            details :  {
                time_elapsed : "Time elapsed:",
                time_remaining : "Time remaining:",
                items_scanned : "Items scanned:",
                total_items : "Total items:",
                item : "Item:"
            },
            results:  {
                scan_results_caption : "Threat(s) Found",
                cleaning_results_caption : "Cleaning Result(s)",
                file : "File",
                file_size: "File Size",
                last_modified: "Last Modified",
                threats : "Threats",
                action : "Action",
                result : "Result",
                cleaning_state: {
                    ignored:"Failed to Remove",
                    quarantined: "Removed",
                    disinfected: "Disinfected",
                    manual_clean: "Must be Manually Removed<br><a href='' onclick='ShowManualCleanModal();'>Instructions.</a>"
                }
            },
            steps: {
                checking_internet_connection: "Checking<BR>Internet Connection",
                checking_for_product_updates: "Checking For<BR>Product Updates",
                updating_malware_definition: "Updating<BR>Malware Definitions",
                initializing_malware_scanners: "Initializing<BR>Malware Scanners",
                scanning_computer: "Scanning<BR>Computer",
                results: "Results"
            },
            steps_metadefender: {
                checking_internet_connection: "Checking<BR>Internet Connection",
                checking_for_product_updates: "Checking For<BR>__product_shortname__ Updates and Validating License",
                updating_malware_definition: "Updating<BR>Malware and Vulnerability Definition",
                initializing_malware_scanners: "Initializing<BR>__product_shortname__",
                scanning_computer: "Scanning For<BR>Malware and Vulnerability with __product_shortname__",
                results: "Results"
            }
        },
        undo: {
            title: "Undo Quarantine",
            success: "<B>Quarantine successfully undone!</B>  All files were restored to their original location.",
            item_success: "<B>__quarantined_item__</B> was restored to your computer.",
            no_quarantines: "Use undo to restore files from a particular scan session if you suspect any of the removed files caused errors on your computer.<BR><BR><B>There are no items in the __product_name__ quarantine.</B>",
            some_quarantines: "Use undo to restore files from a particular scan session below if you suspect any of the removed files caused errors on your computer.",
            table: {
                caption: "Scan session(s)",
                col_date: "Date",
                col_items: "Items",
                col_action: "Action",
                button_undo: "Undo",
                button_undo_item: "Undo Item"
            }
        },
        custom: {
            title: "Custom Scan",
            button_apply: "Apply",
            select_folders: "Select the disks and folders you want to scan:",
            select_at_least_one_folder: "Please select at least one folder."
        },
        quick: {
            title: "Quick Scan",
            message: "Running low on time? Quick Scan checks the most common threat locations.",
            in_progress_message: "Quick Scan is currently in progress...",
            no_file: "<B>For the best Quick Scan results, please exit __product_name__, restart your computer, and start another scan by double clicking on __product_name__.exe. This will allow __product_name__ to gather additional information about the active threats on your computer.</B>",
            button: "Start Quick Scan"
        }
    },
    scan_report: {
        header: "Scan Report",
        summary: {
            header: "Scan Summary:",
            scan_type: "Scan Type: ",
            computer_name: "Computer Name: ",
            start_time: "Scan Time: ",
            duration: "Duration: ",
            app_version: "Client Version: ",
            live_os_version: "LiveOs Version: ",
            metadefender_drive_os_version: "MetaDefender Drive OS Version: ",
            num_files_scanned: "Total Files Scanned: ",
            num_malware_files: "Infected Files: ",
            num_vulnerabilities: "Total Vulnerabilities: "
        },
        definitions: {
            header: "Engine Definition Versions:",
            definition: "DB Version: ",
            last_updated: "Last Updated: "
        },
        threats: {
            header_infections: "Threat Report:",
            header_vulnerabilities: "Vulnerabilities:",
            index: "#",
            filename: "Filename",
            size: "File size",
            modified: "Last modified",
            threats: "Threats"
        }
    },
    button_continue_scan_only: "Proceed Anyway",
    button_exit_scan : "Exit __product_name__",
    button_see_results : "See Results",
    button_ok : "OK",
    button_cancel : "Cancel",
    button_renew: "Express Renewal",
	button_retry: "Retry",
    button_send_email: "Send E-Mail",
    undoing_quarantine : "Undoing Quarantine. Please wait a few moments...",
    mounting_disks : "Examining your hard drives. Please wait a few moments...",
    jqgrid : {
        recordtext: "View {0} - {1} of {2}",
        emptyrecords: "No records to view",
        loadtext: "Loading...",
        pgtext : "Page {0} of {1}"
    }
}

if (GetExternal().IsLocaleSupportedByUi(en.locale))
{
    arrLocalizedStrings.push(en);
}
