var it = {
    locale: "it",
    localeName: "Italiano",
    locale_selector_title: "Offerto in:",
    remoteConnection: {
        initializing: "Inizio Connessione Remota..."
    },
    connectDialog: {
        title: "Connetti alla tua Rete",
        click_network_manager: "Clicca __img__ in alto a destra del tuo schermo per visualizzare le reti wireless disponibili.",
        please_plug_wire: "Per favore collega il tuo computer ad una rete cablata.",
        dialog_will_auto_close: "Questa finestra si chiuderà automaticamente una volta stabilita una connessione.",
        continue_without_internet: "Puoi continuare senza connessione Internet, __product_name__ non riceverà gli aggiornamenti per difenderti dalle minacce più recenti.",
        continue_without_metadefender_update_packages: "<br><b>MetaDefender Core ha recentemente avuto un aggiornamento e deve aggiornare i suoi file del motore antivirus per la scansione. Connettiti a Internet per continuare.</b>",
        button_skip: "Salta Connessione Internet",
        proxy_url_prompt: "Host:Port",
        proxy_user_prompt: "Utente",
        proxy_password_prompt: "Password",
        enter_proxy_url_dimmed: "host:port",
        enter_proxy_user_dimmed: "Solo se richiesto",
        button_submit_proxy_url: "Imposta",
        proxy_setting: "La tua rete richiede un proxy HTTP?",
        confirm_invalid_proxy_info: "Configurazione proxy non valida",
        confirm_proxy_set: "Il proxy HTTP è stato impostato.",
        confirm_proxy_removed: "Il proxy HTTP è stato rimosso."
    },
    dialogBluetoothMouse: {
        title: "Setup Mouse Bluetooth",
        message: "<span class=\"searchingBluetooth\"><B>Ricerca mouse wireless.</B></span><BR> Assicurati che il tuo mouse wireless possa essere \"scoperto.\" Se utilizzi un mouse wireless Apple, spegnilo e poi riaccendilo. La luce LED sul tuo mouse dovrebbe iniziare a lampeggiare. Se utilizzi un mouse wireless non-Apple, mettilo in \"modalità accoppiamento.\"<BR><BR> Controlla i cavi se andrai ad usare un mouse USB.<BR><BR>Se __product_name__ non riesce a connettersi al tuo mouse, puoi spegnere il computer tenendo premuto il pulsante di accensione per 5 secondi.",
        details_waiting_for_ack: "Mouse rilevato <B>__device_name__.</B> Per riconoscere l'accoppiamento, fai clic su <B>Continua</B>.  Se il puntatore del tuo mouse non si muove ed è disponibile un altro mouse wireless, allora il tuo computer potrebbe cercare di accoppiarsi con un altro mouse wireless.",
        button_ack_mouse: "Continua"

    },
    dialogInputDevicesIncompatible:{
        title: "Tastiera o mouse incompatibili",
        message: "__product_name__ ha difficoltà a riconoscere la tastiera o il mouse. Si prega di allegare una tastiera o un mouse cablati per continuare a scansionare. <br> Se non si dispone di una tastiera o di un mouse cablati, tenere premuto il pulsante di accensione per 5 secondi per uscire da __product_name__. <br> ",
        confirmed: "&nbsp; Trovato dispositivo di input! __product_name__ continuerà a breve.",
        button_skip_detection: "Continua"
    },
    dialogPartitionsReadOnly: {
        partitions_journaled: {
            title_all_volumes_journaled: "Modalità Scan-only",
            title_some_volumes_journaled: "Alcuni volumi sono in modalità scan-only",
            message_all_volumes_journaled: "Tutti i volumi su questo computer hanno l'inserimento nel diario. __product_name__ eseguirà la scansione del computer "
                + "ma per pulire, dovrai Factory Aggiorna il tuo __product_name__ e poi riavvia la scansione. <BR> <BR>",
            message_some_volumes_journaled: "Alcuni volumi su questo computer hanno l'inserimento nel diario. I volumi con journaling off verranno scansionati e puliti, "
                + "ma i volumi con journaling su saranno solo scansionati (così almeno scoprirai se il computer è infetto)."
                + "Per pulire, Factory Aggiorna il tuo __product_name__ e quindi riavvia la scansione. <BR> <BR>",
        },
        partitions_readonly_unclean_ntfs: {
                            title: "Windows non si è chiuso completamente",
                            message: "__product_name__ continuerà in modalità solo scansione per vedere se questo PC è infetto. Per pulire da ogni infezione, chiudi completamente Windows e poi avvia nuovamente __product_name__. <BR>Per spegnere completamente Windows: <BR>"
                                + "&nbsp; 1. Esci da __product_name__ e riavvia Windows.<BR>"
                                + "&nbsp; 2. Inserisci __product_name__ e fai doppio click <B>Run__product_name__.exe</B>.<BR>"
                                + "&nbsp; 3. Segui le istruzioni in Run__product_name__.exe.<BR>"
                                + "Se non riesci a riavviare Windows per qualsiasi motivo, fai clic su \"Continua\""
        }
    },
    dialogUncleanMountWarning: {
        title: "Windows did not fully shutdown.",
        message: "Windows did not fully shutdown. Cleaning a computer that did not fully shut down has a very small risk of causing corruption. If possible, to prevent any risk of corruption, please<BR>"
                 + "&nbsp; 1. Exit __product_name__ and restart Windows.<BR>"
                 + "&nbsp; 2. Insert __product_name__ and double-click <B>__product_name__.exe</B>.<BR>"
                 + "&nbsp; 3. Follow the on-screen instructions.<BR>"
                 + "If you unable to restart Windows for any reason, click \"Proceed to Clean\"",
        undo: "Windows did not fully shutdown. Restoring files to a computer that did not fully shut down has a very small risk of causing corruption. If possible, to prevent any risk of corruption, please<BR>"
                 + "&nbsp; 1. Exit __product_name__ and restart Windows.<BR>"
                 + "&nbsp; 2. Insert __product_name__ and double-click <B>__product_name__.exe</B>.<BR>"
                 + "&nbsp; 3. Follow the on-screen instructions.<BR>"
                 + "If you unable to restart Windows for any reason, click \"Proceed to Undo Quarantine\"",
        button_cancel: "Cancel",
        button_continue: "Proceed to Clean",
        button_undo: "Proceed to Undo Quarantine"
    },
    dialogBluetoothKeyboard: {
        title: "Setup Tastiera Bluetooth",
        message: "<span class=\"searchingBluetooth\"><B>Ricerca tastiera wireless.</B></span><BR>Assicurati che la tua tastiera wireless possa essere \"scoperta.\" Se utilizzi una tastiera Apple, spegnila e poi riaccendila.  Il LED dovrebbe iniziare a lampeggiare.  Se utilizzi una tastiera wireless non-Apple, mettila in \"modalità accoppiamento.\".<BR><BR>Controlla i cavi se andrai ad usare una tastiera USB.",
        details_waiting_for_ack: "Tastiera rilevata <B>__device_name__.</B>  Per riconoscere l'accoppiamento, digita <B>\"__pin_code__\"</B> e poi premi <B>INVIO</B>.",
        pin_acknowledged: "&nbsp; Tentativo di connettersi",
        pin_error: "L'abbinamento non è riuscito. Riprova con un nuovo pin"
    },
    dialogInputRequired: {
        title: "Si prega di premere un tasto o spostare il mouse",
        message: "__product_name__ sta aspettando il tuo input. <BR> Se la tastiera o il mouse non funzionano, ti preghiamo di collegare una tastiera o un mouse cablato. <BR> Se non hai una tastiera o un mouse cablato, tieni premuto il pulsante di accensione per 5 secondi per uscire da __product_name__."
    },
    dialogFixMeStickDisconnect: {
        title: "__product_name__ USB Disconnesso",
        message: "__product_name__ si è disconnesso dalla porta USB. Forse è stato colpito? <BR><BR>Per favore spegni il PC tenendo premuto il pulsante di accensione per 5 secondi e prova ad eseguire nuovamente __product_name__."
    },
    dialogNotAuthorized: {
        title: "Per favore Contatta il Supporto",
        not_authorized_for_pcs: "Questo __product_name__ è solo per Macs e questo è un PC. <BR> <BR> Se hai ordinato il __product_name__ sbagliato, il nostro team di supporto può convertire il tuo __product_name__ da eseguire gratuitamente su PC. Si prega di inviare un'email al <B> support@__product_name__.com </B> Includi il numero di serie dal lato del tuo __product_name__ nella richiesta",
        not_authorized_for_macs: "Questo __product_name__ è solo per PCs e questo è un Mac.<BR> <BR> Se hai ordinato il __product_name__ sbagliato, il nostro team di supporto può convertire il tuo __product_name__ da eseguire gratuitamente su Mac. Si prega di inviare un'email al  <B> support@__product_name__.com </B> Includi il numero di serie dal lato del tuo __product_name__ nella richiesta",
        invalid_serial_number: "Questo __product_name__ non ha l'autorizzazione per l'esecuzione. Se il tuo __product_name__ è collegato ad un hub o ad una stampante, per favore esci da __product_name__, collegano direttamente al computer, e riprova.",
        no_serial_number: "Per favore esci da __product_name__, collegalo ad una porta USB differente e riprova. Se il tuo __product_name__ è collegato ad un hub o ad una stampante, per favore prova a collegarlo direttamente al tuo computer.",
        opswat_contact_message: "<B>Si prega di presentare un biglietto attraverso il nostro sistema di assistenza all'indirizzo https://portal.opswat.com/, oppure di contattarci al +1(415) 590-7300.</B>",
        ticket_for_support: "Ticket per il supporto:",
    },
    dialogNotAuthorizedEnterKey: {
        title: "Attiva __product_name__",
        enter_key: "Per favore inserisci la chiave prodotto per attivare __product_name__.",
        enter_key_dimmed: "Inserisci la chiave prodotto",
        button_continue: "Continua",
        invalid_key: "Chiave non valida. Per favore riprova."
    },
    dialogExpired: {
        title: "Rinnovo Richiesto",
        message: "La tua iscrizione __product_name__ è scaduta.<BR><BR>Rinnova l'iscrizione per continuare ad utilizzare il tuo __product_name__.<BR><BR>Rinnovare il tuo __product_name__ richiede meno di un minuto.",
    },
    dialogDeviceCountExceeded: {
        title: "Aggiungere i computer per l'abbonamento",
        message: "Questo __product_name__ è stato utilizzato sul numero massimo di computer.",
    },
    dialogResultsInfected: {
        title: "Scansione Completa - Infezioni Rilevate",
        button_clean_computer: "Ripulisci Computer",
        message: "__product_name__ ha rilevato delle infezioni sul tuo computer.<BR><BR>(Per ripulire solo certi file, seleziona \"Vedi Risultati.\")"
    },
    dialogResultsInfectedButAllJournaled: {
        title: "Scansione Completa - Infezioni Rilevate",
        message: "__product_name__ ha rilevato infezioni sul tuo computer. <BR> <BR> Per pulire le minacce, esci da __product_name__, Factory Aggiorna il tuo __product_name__, quindi riavvia __product_name__."
    },
    dialogResultsFilevaultEmail: {
        title: "Scansione Completa - Trovate Infezioni",
        messageFilevault: "__product_name__ ha trovato delle infezioni sul tuo computer.<BR><BR> Poiché i tuoi volumi sono criptati con FileVault, queste minacce devono essere rimosse manualmente. Per eliminare le minacce, puoi: <BR>"
                 + "&nbsp; 1. Inserire la tua email in basso.  Invieremo delle istruzioni per la rimozione manuale alla tua casella di posta. <BR>",
        messageApfs: "__product_name__ ha trovato delle infezioni sul tuo computer.<BR><BR> Poiché i tuoi volumi sono formattati con Apfs, queste minacce devono essere rimosse manualmente. Per eliminare le minacce, puoi inserire la tua email in basso.  Invieremo delle istruzioni per la rimozione manuale alla tua casella di posta. <BR><BR>",
        messageFilevaultContinued: "&nbsp; 2. Esci da __product_name__, disattiva FileVault (visita support.__product_name__.com e cerca \"FileVault\" per le istruzioni), poi riavvia una scansione con __product_name__. Nota che la disattivazione di FileVault può richiedere diverse ore per essere completata. <BR>",
        emailSent: "Email inviata!",
        emailFailure: "Impossibile inviare e-mail. Controllare la connessione internet e verificare l'indirizzo e-mail.",
        failedValidation: "L'email non è valida. Per favore riprova."
    },
    dialogResultsClean: {
        title: " Scansione Completa - Nessuna Infezione Rilevata",
        message: "Nessuna Infezione Rilevata."
    },
    dialogCleaningDone: {
        title: "Pulizia Computer",
        action_required: "Azione richiesta",
        mac_readonly_message: "Alcune infezioni devono essere rimosse manualmente. Per rimuovere manualmente, riavviare il sistema operativo Mac, aprire il file __product_name__ USB nel Finder e fare doppio clic sul file QUARANTINE",
        threats_found_but_not_cleaned:"Potenziali minacce sono state rilevate ma nessuna è stata rimossa. Queste minacce rimangono sul computer.",
        partial_message: "Tutte le minacce selezionate sono state rimosse con successo, ma rimangono delle potenziali minacce sul tuo computer.",
        complete_message: "Tutte le infezioni sono state rimosse con successo."
    },
    dialogCleaning: {
        title: "Pulizia Computer",
        message: "__product_name__ sta pulendo il tuo computer."
    },
    dialogExit: {
        title: "Uscita da __product_name__",
        message: "Il tuo computer si spegnerà. Una volta spento, per favore rimuovi __product_name__ e premi il pulsante di accensione per riavviare.",
    },
    dialogExitWithInfections: {
        title: "Uscita da __product_name__",
        button_exit_anyway: "Esci Comunque",
        message: 'Se esci da __product_name__ adesso, potrebbe rimanere ancora del software nocivo sul tuo computer. Fai clic su "Annulla" e poi su "Applica Azioni" per rimuovere il software nocivo.'
    },
    dialogConfirmUndo: {
        title: "Annulla Quarantena",
        message: "Tutti gli oggetti che sono stati rimossi durante la scansione selezionata saranno ripristinati sul tuo computer, incluse le potenziali minacce."
    },
    dialogConfirmUndoItem: {
        title: "Annulla Quarantena Oggetto",
        message: "Questo oggetto è una potenziale minaccia. Sei sicuro di volerlo ripristinare sul tuo computer?"
    },
    dialogConfirmImprovementProgram: {
        title: "Programma Miglioramento Cliente",
        message: "Consentendoci di inviarti una e-mail, accetti che noi mandiamo dati diagnostici e file potenzialmente infettati a __product_name__ Technologies.",
        button_ok: "Manda E-mail",
        button_cancel: "Cancella"
    },
    dialogRestartScan: {
        title: "Riavvia Scansione",
        message: "Questo annullerà la scansione corrente e avvierà una nuova."
    },
    dialogEula: {
        title: "Accordo Licenza Utente Finale __company_name__",
        button_accept_and_run: "Accetta ed Esegui",
        message: "Per favore leggi i termini della licenza",
        improvement_program: "Invia automaticamente dati diagnostici e file potenzialmente dannosi a __company_legal_name__."
    },
    dialogDoesNotMeetMinReqs: {
        title: "Requisiti di Sistema",
        message: "Questo PC non possiede almeno __min_ram__ di RAM, quindi __product_name__ non può essere eseguito.",
        min_ram: "512 MB",
        min_ram_metadefender_stick: "8 GB"
    },
    dialogLinkEmail: {
        title: "Registra il tuo __product_name__",
        message: "Per favore inserisci la tua e-mail per registrare il tuo __product_name__.",
        email: "Email",
        name: "Nome",
        confirm_email: "Conferma email",
        first_name: "Nome",
        last_name: "Cognome",
        registering: "Registrazione del tuo __product_name__.",
        INVALID_EMAIL: "L'indirizzo e-mail non è valido.",
        emails_dont_match: "Le e-mail non corrispondono.",
        button_skip : "Salta"
    },
    dialogUnlockFilevault: {
        title: "Alcuni dei tuoi volumi sono criptati con Filevault",
        unlocking: "Sblocco Filevault",
        message: "Per favore, inserisci la password del tuo Mac in basso. La tua password verrà usata per sbloccare temporaneamente i tuoi volumi per la scansione. La tua password non verrà salvata.",
        metadefender_second_message: "Caratteristica sperimentale: se MetaDefender Drive non riesce a sbloccare i volumi, dovrai disabilitare FileVault per continuare l'elaborazione. Seleziona \"Disattiva FileVault\" sotto il menu Apple> Preferenze di Sistema> Sicurezza e Privacy sotto i tuoi pannelli di controllo.",
        not_all_drives_unlocked: "Alcuni volumi sono ancora bloccati. Per favore, prova con un'altra password del Mac per sbloccare questi volumi.",
        could_not_unlock: "Impossibile sbloccare FileVault.  Per favore, prova con un'altra password del Mac. Nota che al momento le unità esterne non sono supportate.",
        password: "Password del Mac",
        button_skip: "Salta"
    },
    dialogFactoryUpgradeInstructionsEmail: {
        title: "INVIA ISTRUZIONI PER L'AGGIORNAMENTO DELLA FABBRICA",
        header: "Ripristina le impostazioni di fabbrica",
        stepsListPartOne: "1. Inserisci la tua email qui sotto. Le istruzioni saranno inviate alla tua email.",
        stepsListPartTwo: "2. Esci da __product_name__, riavvia il computer e segui le istruzioni nell'email.<BR>3. Avvia un'altra scansione con __product_name__ aggiornato in fabbrica.",
        emailSent: "Email inviata alla tua casella di posta!",
        emailFailure: "Impossibile inviare e-mail. Controllare la connessione internet e verificare l'indirizzo e-mail.",
        failedValidation: "L'email non è valida. Per favore riprova.",
        button_skip: "Salta"
    },
    dialogSettings: {
        title: "Impostazioni",
        button_send_instructions: "Invia istruzioni"
    },
    dialogLoadingRenewal: {
        title: "Caricamento Rinnovo Espresso"
    },
    notif : {
        take_a_break: {
            title: "Puoi fare una pausa!",
            title_metadefender: "La scansione è iniziata",
            message: "Questa scansione potrebbe richiedere da una a diverse ore. Non sarà necessario il tuo input fino alla conclusione.",
            message_plug_suffix: "<BR><BR>Per favore collega l'adattatore AC al tuo computer in modo che non esaurisca l'energia durante la scansione."
        },
        recovered_from_crash: {
            title: "Riavvio automatico",
            message: "L'ultima scansione __product_name__ ha riscontrato un problema. Non c'è da preoccuparsi… lo abbiamo notato e abbiamo lanciato automaticamente un'altra scansione riprendendo da dove si era interrotta la precedente. Volevamo soltanto farcelo sapere."
        },
        restored_dnsapi_dll: {
            title: "File di sistema è ripristinato",
            message: "__product_name__ ha rilevato è ripristinato un file di sistema mancante critico di nome dnsapi.dll."
        },
        restored_netfilter2_sys: {
            title: "File in quarantena ripristinato in modo errato",
            message: "__product_name__ ha rilevato e ripristinato automaticamente un file in quarantena errato chiamato netfilter2.sys.<BR>Se non si desidera eseguire una scansione, ora è possibile uscire in modo sicuro da __product_name__ facendo clic sulla X nell'angolo in alto a destra."
        },
        right_click_detected: {
            title: "Stai utilizzando il pulsante destro del mouse?",
            message: "__product_name__ necessita che tu utilizzi il pulsante sinistro del mouse (anche se sei mancino ;))."
        },
        left_click: {
            title: "Consiglio",
            message: "Se il clic sinistro non sembra funzionare, puoi premere \"Tab\" fino a che non viene selezionato un pulsante e poi premere \"Invio\"."
        },
        bluetooth_reconnect: {
            title: "Consiglio Bluetooth",
            message: "Non allarmarti se il computer visualizza un messaggio per il ri-accoppiamento del tuo dispositivo Bluetooth dopo essere uscito da __product_name__ e aver riavviato il tuo computer. È normale."
        },
        device_pci: {
            title: "Scheda di Rete Non Supportata",
            message: "Per favore invia una e-mail a support@__product_name__.com con le informazioni sotto in modo da poter aggiungere il supporto per la tua scheda di rete.<BR>"
        },
        keyboard_layout: {
            title: "Caratteri Non Usuali",
            message: "Digiti e non vedi i caratteri che ti aspetti?<BR>Clicca sull'icona <i class=\"fa fa-keyboard-o\" aria-hidden=\"true\"></i> per cambiare la tua tastiera."
        },
        scan_report: {
            title: "Rapporto di scansione generato",
            message: "Si prega di consultare il rapporto nella directory 'reports' sul tuo __product_name__",
            message_meta_defender_stick: "__scan_report_path__ generato, dai uno sguardo alla partizione NTFS del tuo dispositivo __product_name__ per i risultati di scansione dettagliati!"
        },
    },
    action: {
        keep: "Conserva",
        quarantine: "Rimuovi",
        journaled: "Aggiornamento di fabbrica e ri-scansione per pulire",
        readonly_non_journaled: "Esegui un Check Disk e ri-scansiona per pulire",
        manual_clean: "Deve essere rimosso manualmente.<br><a href='' onclick='ShowManualCleanModal();'>Istruzioni.</a>"
    },
    time: {
        day: "__count__ giorno",
        day_plural: "__count__ giorni",
        hour: "__count__ ora",
        hour_plural: "__count__ ore",
        minute: "__count__ minuto",
        minute_plural: "__count__ minuti",
        second: "__count__ secondo",
        second_plural: "__count__ secondi",
        ago: "__time__ ago",
        calculating: "Calcolo in corso...",
        complete : "Completo",
        left : "rimasti",
        several_hours: "Alcune ore..."
    },
    accordion: {
        scan: {
            title: "Scansiona",
            filevault_configuration_not_supported: "Questo Mac utilizza una configurazione FileVault che non è ancora supportata da __product_name__. I volumi crittografati con FileVault non verranno scansionati.",
            filevault_need_to_factory_upgrade: "Il tuo __product_name__ ha bisogno di un aggiornamento di fabbrica gratuito, una tantum, per gestire una tecnologia che il tuo Mac sta usando (FileVault).<br> <a href=\"#\" onclick='return ShowFactoryUpgradeInstructionsSendingModal(\"MAC\");'>Fare clic</a> qui per inviare una e-mail su come effettuare l'aggiornamento di fabbrica e quindi avviare un'altra scansione.",
            apfs_need_to_factory_upgrade: "Il tuo __product_name__ ha bisogno di un aggiornamento di fabbrica gratuito, una tantum, per gestire una tecnologia che il tuo Mac sta usando (APFS).<br> <a href=\"#\" onclick='return ShowFactoryUpgradeInstructionsSendingModal(\"MAC\");'>Fare clic</a> qui per inviare una e-mail su come effettuare l'aggiornamento di fabbrica e quindi avviare un'altra scansione.",
            status: {
                need_to_run_chk_disk: "Alcune delle tue partizioni sono in uno stato non sicuro e non possono essere scansionate. Dovrai eseguire un comando check disk da Windows. Per istruzioni, visita 'www.fixmestick.com/run-chkdsk'.",
                at_least_one_partition_read_only: "Almeno un volume è in esecuzione in modalità scan-only.",
                encryption_detected: "Il __product_name__ non sarà in grado di eseguire la scansione di uno o più di uno delle vostre unità criptato con Bitlocker.",
                at_least_one_partition_journaled: "Alcuni volumi sono registrati su giornale e non possono essere puliti. Per risolvere questo problema, visita il nostro sito Web e aggiorna il tuo __product_name__.",
                encryption_detected_metadefender: "Uno o piu' volumi sono cripati e non possono essere scannerizzati. Per scansionare questi volumi, si prega di ricominciare da Windows, e di seguire le istruzioni su 'README.txt' nella cartella di /tools/bitlocker nella partizione NTFS della tua barra.",
                hfs_filevault_detected: "Uno o più volumi sono crittografati con una versione precedente di Apple Filevault e non possono essere scansionati. Disattivare Filevault da macOs e riavviare __product_name__ per analizzare questi volumi.",
                apfs_filevault_detected: "Uno o più volumi sono crittografati con Apple Filevault.",
                hfs_filevault_detected_metadefender: "Uno o più volumi sono crittografati con una versione precedente di Apple Filevault e non possono essere scansionati. Seleziona \"Disattiva FileVault\" sotto il menu Apple> Preferenze di Sistema> Sicurezza e Privacy sotto i tuoi pannelli di controllo.",
                apfs_filevault_detected_metadefender: "Uno o più volumi sono crittografati con Apple Filevault. <br> <br> Volumi cifrati: __encrypted_volumes__",
                safe: "Stato computer: Sicuro.  ",
                safe_so_far: "Stato computer: Sicuro finora.",
                safe_so_far_metadefender: "Stato computer: esame in corso.",
                not_safe: "Stato computer: A rischio.",
                not_safe_review_when_finished: "I risultati preliminari della scansione mostrano che potrebbe esistere del software nocivo sul tuo sistema. Potrai rivedere gli oggetti rilevati una volta completata la scansione.",
                safe_all_infections_quarantined: "Tutte le infezioni sono state rimosse.",
                throttling_too_hot: "Il computer computer si sta scaldando molto. La scansione rallenterà per prevenire surriscaldamento.",
                keep_cool_mode: 'Attivata modalità keep cool',
                reduced_functionality:"__product_name__ è in esecuzione in modalità di risparmio delle risorse.",
                quick_scan:"__product_name__ sta eseguendo una scansione rapida."
            },
            no_files_marked_quarantine: 'Nessun file contrassegnato come "Rimuovi".',
            threats_found : "__product_name__ ha rilevato delle potenziali minacce sul tuo computer.",
            no_threats_found : "Ottime notizie! Nessuna minaccia è stata rilevata sul tuo computer durante questa scansione.",
            scan_complete_message : "Scansione di __num_items__oggetti completata in__time__.",
            button_apply_actions : "Applica Azioni",
            button_skip_updates: "Salta gli aggiornamenti",
            applying_update_packages: "Applicazione di pacchetti in MetaDefender Directory di aggiornamento Drive. Pacchetto __current_package__ di __total_packages__...",
            engines_init: "motori inizializzati.",
            applying_update: "Applicazione aggiornamento. __product_name__ si riavvierà a breve...",
            details :  {
                time_elapsed : "Tempo trascorso:",
                time_remaining : "Tempo rimanente:",
                items_scanned : "Oggetti analizzati:",
                total_items : "Oggetti totali:",
                item : "Oggetto:"
            },
            results:  {
                scan_results_caption : "Minacce Rilevate",
                cleaning_results_caption : "Risultati Pulizia",
                file : "File",
                file_size: "Dimensione del file",
                last_modified: "Ultima modifica",
                threats : "Minacce",
                action : "Azione",
                result : "Risultato",
                cleaning_state: {
                    ignored: "Rimozione Fallita",
                    quarantined: "Rimosso",
                    disinfected: "Disinfettato",
                    manual_clean: "Deve essere rimosso manualmente.<br><a href='' onclick='ShowManualCleanModal();'>Istruzioni.</a>."
                }
            },
            steps: {
                checking_internet_connection: "Controllo<BR>Connessione Internet",
                checking_for_product_updates: "Controllo <BR>Product Aggiornamenti",
                updating_malware_definition: "Aggiornamento<BR>Definizioni Malware",
                initializing_malware_scanners: "Inizializzazione<BR>Scanner Malware",
                scanning_computer: "Scansione<BR>Computer",
                results: "Risultati"
            },
            steps_metadefender: {
                checking_internet_connection: "Controllo della connessione Internet ",
                checking_for_product_updates: "Verifica degli aggiornamenti di __product_shortname__ e convalida della licenza",
                updating_malware_definition: "Aggiornamento della definizione di malware e vulnerabilità",
                initializing_malware_scanners: "L'inizializzazione <BR> __product_shortname__",
                scanning_computer: "Scansione per malware e vulnerabilità di <BR> con __product_shortname__",
                results: "Risultati"
            }
        },
        undo: {
            title: "Annulla Quarantena",
            success: "<B>Quarantena annullata con successo!</B> tutti i file sono stati ripristinati nelle loro posizioni originali.",
            item_success: "<B>__oggetto in quarantena__</B> ripristinato sul tuo computer.",
            no_quarantines: "Usa annulla per ripristinare i file di una particolare sessione di scansione se sospetti che uno qualsiasi dei file rimossi abbia causato errori sul tuo computer.<BR><BR><B>Non ci sono oggetti nella quarantena __product_name__.</B>",
            some_quarantines: "Usa annulla per ripristinare i file di una particolare sessione di scansione sotto se sospetti che uno qualsiasi dei file rimossi abbia causato errori sul tuo computer.",
            table: {
                caption: "Sessione/i Scansione",
                col_date: "Data",
                col_items: "Oggetti",
                col_action: "Azione",
                button_undo: "Annulla",
                button_undo_item: "Annulla Oggetto"
            }
        },
        custom: {
            title: "Personalizza Scansione",
            button_apply: "Applica",
            select_folders: "Seleziona i dischi e le cartelle che desideri analizzare:",
            select_at_least_one_folder: "Per favore seleziona almeno una cartella."
        },
        quick: {
            title: "Quick Scan",
            message: "Hai poco tempo? Quick Scan controlla le posizioni delle minacce più recenti.",
            in_progress_message: "La scansione rapida è attualmente in corso ...",
            no_file: "<B>Per avere risultati di Quick Scan più rapidi, esci da __product_name__, riavvia il computer e lancia un'altra scansione facendo doppio clic su __product_name__.exe. Questo permetterà a __product_name__ di raccogliere informazioni aggiuntive riguardo alle minacce attive sul tuo computer.</ B>",
            button: "Lancia Quick Scan"
        }
    },
    scan_report: {
        header: "Rapporto di scansione",
        summary: {
            header: "Riepilogo scansione:",
            scan_type: "Tipo di scansione",
            computer_name: "Nome del computer: ",
            start_time: "Tempo di scansione: ",
            duration: "Durata: ",
            app_version: "Versione client: ",
            live_os_version: "Versione LiveOs: ",
            metadefender_drive_os_version: "Versione MetaDefender Drive OS: ",
            num_files_scanned: "File totali scansionati: ",
            num_malware_files: "File infetti: ",
            num_vulnerabilities: "Vulnerabilità totali: "
        },
        definitions: {
            header: "Versioni di definizione del motore:",
            definition: "Versione DB: ",
            last_updated: "Ultimo aggiornamento: "
        },
        threats: {
            header_infections: "Rapporto sulle minacce:",
            header_vulnerabilities: "Vulnerabilità:",
            index: "#",
            filename: "Nome del file",
            size: "Dimensione del file",
            modified: "Ultima modifica",
            threats: "Minacce"
        }
    },
    button_continue_scan_only: "Continua con i volumi in modalità scan-only",
    button_exit_scan : "Esci da __product_name__",
    button_see_results : "Visualizza Risultati",
    button_ok : "OK",
    button_cancel : "Annulla",
    button_renew: "Rinnovo Espresso",
    button_retry : "Riprova",
    button_send_email: "Invia una email",
    undoing_quarantine : "Annullamento Quarantena. Per favore attendi qualche istante...",
    mounting_disks : "Analisi dei tuoi hard drive. Per favore attendi qualche istante...",
    jqgrid : {
        recordtext: "Visualizza {0} - {1} di {2}",
        emptyrecords: "Nessuna registrazione da visualizzare",
        loadtext: "Caricamento...",
        pgtext : "Pagina {0} di {1}"
    }
}

if (GetExternal().IsLocaleSupportedByUi(it.locale))
{
    arrLocalizedStrings.push(it);
}
