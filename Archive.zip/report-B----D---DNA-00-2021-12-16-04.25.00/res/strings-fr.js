var fr = {
    locale : "fr",
    localeName : "Français",
    locale_selector_title: "Disponible en :",
    remoteConnection: {
        initializing : "Lancement de la connexion à distance..."
    },
    connectDialog : {
        title: "Connection à votre réseau",
        click_network_manager : "Cliquez sur le __img__ en haut à droite de votre écran pour afficher les réseaux sans fil disponibles.",
        please_plug_wire : "Veuillez brancher votre ordinateur à un réseau câblé.",
        dialog_will_auto_close : "Cette boîte de dialogue se fermera automatiquement lorsqu'une connexion sera établie.",
        continue_without_internet : "Vous pouvez continuer sans connexion Internet, mais __product_name__ ne pourra pas obtenir les mises à jour nécessaires pour vous protéger contre les menaces les plus récentes.",
        button_skip : "Sans Connexion Internet",
        proxy_url_prompt: "Hôte:Port",
        proxy_user_prompt: "Nom d'utilisateur",
        proxy_password_prompt: "Mot de passe",
        enter_proxy_url_dimmed: "hôte:port",
        enter_proxy_user_dimmed: "Seulement si nécessaire",
        button_submit_proxy_url: "Appliquer",
        proxy_setting: "Votre réseau exige un proxy HTTP?",
        confirm_invalid_proxy_info: "La configuration de proxy n'est pas valide",
        confirm_proxy_set : "Le proxy HTTP a été configuré.",
        confirm_proxy_removed : "Le proxy HTTP a été supprimé."
    },
    dialogBluetoothMouse: {
        title: 'Configuration Souris Bluetooth',
        message: "<span class=\"searchingBluetooth\"><B>Rechercher une souris sans fil.</B></span><BR>Assurez-vous que votre souris sans fil est \"découvrable.\" Si vous utilisez une souris sans fil Apple, l'éteindre et le rallumer. La LED sur votre souris devrait commencer à clignoter. Si vous utilisez une souris sans fil à partir d'un autre fabricant, le mettre dans \"mode d'appariement.\"<BR><BR>Vérifiez vos câbles si vous prévoyez d'utiliser une souris USB.<BR><BR>Si le __product_name__ ne connecter pas avec votre souris, vous pouvez éteindre votre ordinateur en appuyant sur le bouton d'alimentation pendant 5 secondes.",
        details_waiting_for_ack: "Trouvé souris <B>__device_name__.</B> Pour accepter la liaison, cliquez <B>Continuer</ B>. Si votre souris ne se déplace pas le pointeur et il ya une autre souris sans fil disponible, votre ordinateur peut être essayer de jumeler avec une autre souris sans fil.",
        button_ack_mouse: "Continuer"

    },
    dialogInputDevicesIncompatible:{
        title: "Clavier ou souris incompatible",
        message: "__product_name__ a du mal à reconnaître votre clavier ou votre souris. S'il vous plaît joindre un clavier ou une souris filaire pour continuer à numériser. <br> Si vous n'avez pas un clavier ou une souris câblés, maintenez le bouton d'alimentation enfoncé pendant 5 secondes pour quitter __product_name__. <br> ",
        confirmed: "&nbsp; Périphérique d'entrée trouvé! __product_name__ va continuer sous peu.",
        button_skip_detection: "Continuer"
    },
    dialogPartitionsReadOnly: {
        partitions_journaled: {
            title_all_volumes_journaled: "Exécution en mode analyse-seulement",
            title_some_volumes_journaled: "Quelques volumes sont en mode analyse-seulement",
            message_all_volumes_journaled: "Tous les volumes de cet ordinateur sont journalisés. __product_name__ va scanner cet ordinateur, "
                + "mais pour nettoyer, vous devrez mettre à niveau votre __product_name__ puis relancer l'analyse. <BR> <BR>",
            message_some_volumes_journaled: "Certains volumes de cet ordinateur sont journalisés. Les volumes avec journalisation désactivée seront numérisés et nettoyés "
                + "mais les volumes avec journalisation sont uniquement analysés (vous allez donc au moins découvrir si l'ordinateur est infecté)."
                + "Pour nettoyer, mettez à niveau votre __product_name__ puis relancez l’analyse. <BR> <BR>",
        },
        partitions_readonly_unclean_ntfs: {
            title: "Windows ne s'est pas éteint complètement",
            message: "Windows ne s'est pas éteint complètement. Pour prévenir tout risque de corruption: <BR>"
                + "&nbsp; 1. Quitter __product_name__ et redémarrez Windows.<BR>"
                + "&nbsp; 2. Insérer __product_name__ et faites un double click sur <B>Run__product_name__.exe</B>.<BR>"
                + "&nbsp; 3. Suivez les instructions dans Run__product_name__.exe.<BR>"
                + "Si vous n'etes pas en mesure de redémarrer Windows, pour n'importe quelle raison, cliquez sur \"Continuer\"",
        }
    },
    dialogUncleanMountWarning: {
        title: "Windows ne s'est pas éteint complètement",
        message: "Windows ne s'est pas éteint complètement. Nettoyer un ordinateur qui n'est pas complètement éteint présente un risque minime de corruption. Si possible, pour supprimer tout risque de corruption, s'il vous plaît: <BR>"
                 + "&nbsp; 1. Quitter __product_name__ et redémarrez Windows.<BR>"
                 + "&nbsp; 2. Insérer __product_name__ et faites un double click sur <B>Run__product_name__.exe</B>.<BR>"
                 + "&nbsp; 3. Suivez les instructions dans Run__product_name__.exe.<BR>"
                 + "Si vous n'êtes pas en mesure de redémarrer Windows, pour n'importe quelle raison, cliquez sur \"Continuer a l'étape nettoyage\"",
        undo: "Windows ne s'est pas éteint complètement. Restaurer des fichiers sur un ordinateur qui n'est pas complètement éteint présente un risque minime de corruption. Si possible, pour supprimer tout risque de corruption, s'il vous plaît: <BR>"
                 + "&nbsp; 1. Quitter __product_name__ et redémarrez Windows.<BR>"
                 + "&nbsp; 2. Insérer __product_name__ et faites un double click sur <B>Run__product_name__.exe</B>.<BR>"
                 + "&nbsp; 3. Suivez les instructions dans Run__product_name__.exe.<BR>"
                 + "Si vous n'êtes pas en mesure de redémarrer Windows, pour n'importe quelle raison, cliquez sur \"Continuer à la restauration des fichiers\"",
        button_cancel: "Annuler",
        button_continue: "Continuer a l'étape nettoyage",
        button_undo: "Continuer à la restauration des fichiers"
    },
    dialogBluetoothKeyboard: {
        title: 'Configuration Clavier Bluetooth',
        message: "<span class=\"searchingBluetooth\"><B>Rechercher un clavier bluetooth.</B></span><BR>Assurez-vous que votre clavier sans fil est \"découvrable.\" Si vous utilisez un clavier sans fil Apple, l'éteindre et le rallumer.  La LED sur votre clavier devrait commencer à clignoter.  Si vous utilisez un clavier sans fil à partir d'un autre fabricant, le mettre dans \"mode d'appariement.\"<BR><BR>Vérifiez vos câbles si vous prévoyez d'utiliser un clavier USB.",
        details_waiting_for_ack: "Trouvé clavier <B>__device_name__.</B> Pour accepter la liaison, tapez <B>\"__pin_code__\"</B> et puis appuyez sur <B>ENTRER</B>.",
        pin_acknolwedged: "&nbsp; Tentative de connexion",
        pin_error: "L'association a échoué. Veuillez réessayer avec une nouvelle broche"
    },
    dialogInputRequired: {
        title: "S'il vous plaît appuyez sur une touche ou déplacez votre souris",
        message: "__product_name__ attend votre saisie. <BR> Si votre clavier ou votre souris ne fonctionne pas, veuillez connecter un clavier ou une souris câblé. <BR> Si vous n'avez pas de clavier ou de souris, maintenez le bouton d'alimentation enfoncé pendant 5 secondes pour quitter __product_name__."
    },
    dialogUsbDisconnect: {
        title: "__product_name__ USB Déconnecté",
        message: "Le __product_name__ s'est déconnecté du port USB.<BR><BR>S'il vous plaît éteindre l'ordinateur en appuyant sur le bouton d'alimentation pendant 5 secondes, puis essayez à nouveau."
    },
    dialogNotAuthorized : {
        title : "Veuillez contacter le soutien technique",
        not_authorized_for_pcs: "Ce __product_name__ est pour Mac seulement et cette ordinateur est un PC. <BR> <BR> Si vous avez commandé le mauvais __product_name__, notre équipe de support technique peut convertir votre __product_name__ pour qu'il fonctionne sur PC gratuitement.Veuillez envoyer un email à <B> support@__product_name__.com </B> .Inclure le numéro de série du côté de votre __product_name__ dans la demande.",
        not_authorized_for_macs: "Ce __product_name__ est pour PC seulement et cette ordinateur est un Mac. <BR> <BR> Si vous avez commandé le mauvais __product_name__, notre équipe de support technique peut convertir votre __product_name__ pour qu'il fonctionne sur Mac gratuitement.Veuillez envoyer un email à <B> support@__product_name__.com </B> .Inclure le numéro de série du côté de votre __product_name__ dans la demande.",
        invalid_serial_number : "Ce __product_name__ n'est pas autorisé pour exécution.  Si votre __product_name__ est branché à un concentrateur USB ou à une imprimante, s'il vous plaît quitter __product_name__, le brancher directement sur votre ordinateur, et essayez à nouveau.",
        no_serial_number: "S'il vous plaît quitter __product_name__, le brancher dans un different port USB, et essayez à nouveau.  Si votre __product_name__ est branché à un concentrateur USB ou à une imprimante, s'il vous plaît le brancher directement sur votre ordinateur.",
        opswat_contact_message: "<B>S'il vous plaît, placez une demande à travers notre système de support à https://portal.opswat.com/ , ou appelez-nous à +1(415) 590-7300.</B>",
        ticket_for_support : "Demande de soutien technique:",
    },
    dialogNotAuthorizedEnterKey : {
        title : "Activer mon __product_name__",
        enter_key : "Veuillez entrer la clé de produit pour activer mon __product_name__.",
        enter_key_dimmed : "Entrer la clé de produit",
        button_continue : "Continuer",
        invalid_key : "Clé non valide. Veuillez essayer à nouveau."
    },
    dialogExpired : {
        title: "How To Renew",
        message_1: "Your __product_name__, __serial_number__, expired on __expiration_date__.",
        message_2: "You can renew right here then continue to clean and backup this computer.",
        message_3: "You can renew right here and then continue to clean this computer",
        message_4: "Votre __product_name__ a expiré."
    },
    dialogDeviceCountExceeded: {
        title: "Ajouter des ordinateurs à votre abonnement",
        message: "Ce __product_name__ a été utilisé sur le nombre maximal d'ordinateurs.",
    },
    dialogResultsInfectedButAllJournaled : {
        title: "Analyse terminée",
        message: "__product_name__ a détecté des infections sur votre ordinateur. <BR> <BR> Pour nettoyer les menaces, quittez __product_name__, usine, mettez à niveau votre __product_name__, puis redémarrez __product_name__."
    },
    dialogResultsFilevaultEmail: {
        title: "Action Requise",
        messageFilevault: "__product_name__ a trouvé des infections sur votre ordinateur.<BR><BR> Parce que vos volumes sont chiffrés avec FileVault, ces menaces doivent être supprimes manuellement.  Pour nettoyer les infections, s'il vous plaît: <BR>"
                 + "&nbsp; 1. Entrez votre addresse courriel ci-dessous.  Les instructions pour le nettoyage manuel seront envoyés à votre boîte courriel. <BR>",
        messageApfs: "__product_name__ a trouvé des infections sur votre ordinateur.<BR><BR> Parce que vos volumes sont formatés en Apfs, ces menaces doivent être supprimées manuellement.  Pour nettoyer les infections, s'il vous plaît entrez votre addresse courriel ci-dessous.  Les instructions pour le nettoyage manuel seront envoyés à votre boîte courriel. <BR><BR>",
        messageFilevaultContinued: "&nbsp; 2. Quittez __product_name__, désactivez Filevault (visitez support.__product_name__.com et cherchez \"FileVault\" pour les instructions), et ensuite recommencez une analyse à nouveau. Prenez note que désactiver FileVault peut prendre plusieurs heures à compléter. <BR>",
        emailSent: "Courriel envoyé!",
        emailFailure: "Échec d'envoi du courrier électronique. Vérifier la connexion Internet et vérifier l'adresse e-mail",
        failedValidation: "L'email n'est pas valide. Veuillez réessayer."
    },
    dialogResults: {
        full_title: "L'analyse antivirus et la sauvegarde sont terminées",
        scan_title: "Analyse terminée",
        scan_summary: "Résumé de l'analyse",
        backup_summary: "Résumé de la sauvegarde",
        scan_viruses: "Virus détectés: ",
        scan_files: "Nombre total de fichiers analysés: ",
        backup_files: "Nombre total de fichiers analysés: ",
        backup_size: "Taille de sauvegarde: ",
        button_clean_computer: "Nettoyer",
    },
    dialogCleaningDone : {
        title : "Nettoyage de votre ordinateur",
        action_required: "Action requise",
        threats_found_but_not_cleaned: "Les menaces potentielles ont été détectées mais aucune n'a été supprimée. Ces menaces restent sur votre ordinateur.",
        partial_message : "Toutes les menaces sélectionnées ont été mises en quarantaine, mais des menaces potentielles subsistent.",
        failed_message: "Les menaces sélectionnées n'ont pas pu être supprimées.",
        partial_fail_message: "Certaines menaces, mais pas toutes, ont été supprimées avec succès.",
        mac_readonly_message: "Certaines menaces doivent être supprimées manuellement. Pour supprimer manuellement cette installation, redémarrez votre système d'exploitation Mac, ouvrez le __product_name__ USB dans le Finder et double-cliquez sur le fichier QUARANTINE",
        complete_message : "Toutes les infections ont été mises en quarantaine."
    },
    dialogCleaning : {
        message : "Mise en quarantaine des virus..."
    },
    dialogExit : {
        title : "Quitter __product_name__",
        message : "Votre ordinateur va s'éteindre. Lorsqu'il sera éteint, veuillez enlever le __product_name__ et appuyez sur le bouton d'alimentation pour redémarrer.",
    },
    dialogExitWithInfections : {
        title : "Quitter __product_name__",
        button_exit_anyway : "Quitter quand même",
        message : 'Si vous quittez __product_name__ maintenant, des logiciels malveillants pourraient être encore présents dans votre ordinateur. Cliquez sur "Annuler” puis "Appliquer Action" pour mettre les logiciels malveillants en quarantaine.'
    },
    dialogExitOngoingBackup: {
        title : "Quitter __product_name__",
        button_exit_anyway : "Quitter quand même",
        message: 'Si vous quittez __product_name__ maintenant, votre sauvegarde sera incomplète. Cliquez sur "Annuler" et attendez que la sauvegarde atteigne 100% avant de quitter.'
    },
    dialogConfirmUndo : {
        title : "Annuler Quarantaine",
        message : "Tous les éléments qui ont été mis en quarantaine durant l'analyse seront restaurés sur votre ordinateur, y compris les menaces potentielles.",
        readonly_message: "La plupart des éléments supprimés lors de l'analyse sélectionnée seront restaurés sur votre ordinateur, y compris les menaces potentielles. Certains éléments ne seront pas restaurés en raison du montage d'une ou plusieurs partitions en lecture seule."
    },
    dialogConfirmUndoItem: {
        title: "Défaire l'item en quarantaine",
        message: "Cet item est une menace potentielle. Êtes-vous sûr(e) de vouloir le restorer sur votre ordinateur?",
        readonly_tooltip: "Cet élément ne peut pas être restauré car la partition a été montée en lecture seule"
    },
    dialogConfirmImprovementProgram: {
        title: "Programme d'amélioration du produit",
        message: "En nous autorisant à vous envoyer un courriel, vous acceptez d'envoyer automatiquement des données de diagnostic à __product_name__ Technologies Inc.",
        button_ok: "Envoyer courriel",
        button_cancel: "Annuler"
    },
    dialogRestartScan : {
        title : "Redémarrer l’analyse",
        message : "Ceci va annuler l’analyse en cours et démarrer une nouvelle analyse."
    },
    dialogToggle: {
        title: "Désactiver __operation__",
        message: "Cela suspendra la __operation__ en cours.",
        shutdown: "Lorsque l'analyse et la sauvegarde sont désactivées, FixMeStick ne fera rien jusqu'à ce que vous en réactiviez un. Es-tu sur de vouloir continuer?",
        button_shutdown: "Éteindre"
    },
    dialogEula : {
        title : "__company_name__ contrat de licence de l'utilisateur",
        button_accept_and_run : "Accepter et Exécuter",
        message : "Veuillez lire les termes de la licence",
        improvement_program : "Envoyez automatiquement des données de diagnostic à __company_legal_name__."
    },
    dialogDoesNotMeetMinReqs: {
        title: "Configuration Requise",
        message: "Ce PC n'a pas au moins __min_ram__ de RAM, alors le __product_name__ ne peut pas fonctionner dans ce PC.",
        min_ram: "512 Mo",
    },
    dialogLinkEmail: {
        title: "Enregistrez votre __product_name__",
        message: "S'il vous plaît, entrez votre courriel pour enregistrer votre __product_name__.",
        email: "Courriel",
        confirm_email: "Confirmez votre e-mail",
        name: "Nom",
        first_name: "Prénom",
        last_name: "Nom",
        registering: "L'enregistrement de votre __product_name__.",
        INVALID_EMAIL: "Le courriel n'est pas valide.",
        emails_dont_match: "Les courriels ne correspondent pas.",
        button_skip : "Sautez"
    },
    dialogChangeEmail: {
        title: "Changer l'addresse courriel",
        invalid_email: "Le courriel n'est pas valide.",
        server_error: "Une erreur s'est produite lors de la communication avec le serveur. Veuillez réessayer.",
        email_changed: "Votre adresse e-mail a été modifiée avec succès.",
        email_registered: "Votre adresse e-mail a été enregistrée avec succès."
    },
    dialogUnlockFilevault: {
        title: "Certains de vos volumes sont cryptés avec Filevault.",
        unlocking: "En cours de dévérouillement",
        message: "S'il vous plaît entrez votre mot de passe Mac ci-dessous. Votre mot de passe sera utilisé pour dévérouiller vos volumes pour l'analyse. Votre mot de passe ne sera pas conservé.",
        not_all_drives_unlocked: "Certains de vos volumes demeurent vérouillés. S'il vous plaît éssayez a nouveau avec un autre mot de passe. ",
        could_not_unlock: "Vos volumes demeurent vérouillés. S'il vous plaît éssayez a nouveau avec un autre mot de passe. Veuillez noter que les disques externes ne sont pas support S'il vous plaît éssayez a nouveau avec un autre mot de passe. Veuillez noter que les disques externes ne sont pas supportés.",
        password: "Mot de passe Mac",
        button_skip: "Sautez"
    },
    dialogSettings: {
        title: "Réglages",
        button_send_instructions: "Envoyez Instructions"
    },
    dialogFactoryUpgradeInstructionsEmail: {
        title: "ENVOYER LES INSTRUCTIONS POUR LA MISE À JOUR",
        header: "Réinitialiser aux réglages d'usine",
        stepsListPartOne: "1. Entrez votre courriel ci-dessous. Les instructions seront envoyées à votre adresse courriel.",
        stepsListPartTwo: "2. Quittez __product_name__, redémarrez votre ordinateur et suivez les instructions du courriel.<BR>3. Commencez une autre analyse avec votre __product_name__ mis à jour.",
        emailSent: "Courriel envoyé á votre boîte de réception!",
        emailFailure: "Échec d'envoi du courrier électronique. Vérifier la connexion Internet et vérifier l'adresse e-mail",
        failedValidation: "L'email n'est pas valide. Veuillez réessayer.",
        button_skip : "Sautez"
    },
    dialogLoadingRenewal: {
        title: "Chargement en cours"
    },
    notif : {
        take_a_break: {
            title : "Vous pouvez prendre une pause!",
            message_scan_only : "Cette analyse peut prendre entre une et quelques heures.  Vous n'avez plus besoin d'intervenir.",
            message_scan_and_backup : "Ça peut prendre plusieurs heures avant que l'analyze et la sauvegarde de vos fichiers se termine.  Vous n'avez plus besoin d'intervenir.",
            message_plug_suffix : '<BR><BR>SVP branchez votre ordinateur, pour qu’il ne manque pas d’alimentation pendant l’analyse.'
        },
        recovered_from_crash: {
            title: "Redémarrage automatique",
            message: "Un problème a été rencontré au cours de la dernière analyse. Ne vous inquiétez pas ... nous avons automatiquement lancé une autre analyse a l'endroit où il y avais le problème."
        },
        restored_dnsapi_dll: {
            title: "Fichier système restauré",
            message: "__product_name__ a détecté et a restauré le fichier système critique dnsapi.dll."
        },
        restored_netfilter2_sys: {
            title: "Fichier incorrect mis en quarantaine restauré",
            message: "__product_name__ a détecté et restauré automatiquement un fichier incorrectement mis en quarantaine nommé netfilter2.sys.<BR>Si vous ne voulez pas exécuter un scan, vous pouvez maintenant quitter __product_name__ en toute sécurité en cliquant sur le X dans le coin supérieur droit."
        },
        right_click_detected: {
            title: "Est-ce que vous utilisez le bouton droit de la souris?",
            message: "__product_name__ vous oblige à utiliser le bouton gauche de la souris (même si vous êtes gaucher;))."
        },
        left_click: {
            title: "Conseil",
            message: "Si le clic gauche ne semble pas fonctionner, vous pouvez frapper \"Tab\" jusqu'à ce qu'un bouton est sélectionné, puis appuyez sur \"Entrée\"."
        },
        bluetooth_reconnect: {
            title: "Conseil Bluetooth",
            message: "Ne vous inquiétez pas si votre ordinateur vous invite à re-lier votre appareil Bluetooth lorsque vous quittez __product_name__ et redémarrez votre ordinateur. Ceci est normal."
        },
        device_pci: {
            title: "Problème de carte réseau",
            message: "S'il vous plaît écrivez support@__product_name__.com avec les informations ci-dessous afin que nous puissions ajouter le support pour votre carte réseau.<BR>"
        },
        keyboard_layout: {
            title: "Caractères Inhabituels",
            message: "Est-ce que vous avez entré des caractères inhabituels?<BR>Cliquez sur l'icône <i class=\"fa fa-keyboard-o\" aria-hidden=\"true\"></i> pour le changer le configuration du clavier."
        },
        scan_report: {
            title: "Rapport d'analyse généré",
            message: "Veuillez consulter le rapport dans le répertoire 'reports' sur votre __product_name__!",
            message_meta_defender_stick: "__scan_report_path__ généré, jetez un oeil dans la partition NTFS de votre périphérique __product_name__ pour obtenir des résultats d'analyse détaillés!"
        },
    },
    action : {
        keep : "Conserver",
        quarantine : "Mettre en quarantaine",
        journaled: "Mise à jour et re-numériser pour nettoyer",
        readonly_non_journaled: "Quitter et redémarrer de Run__product_name__.exe afin de nettoyer",
        manual_clean: "Doivent être nettoyés manuellement.<br><a href='' onclick='ShowManualCleanModal();'>Instructions.</a>"
    },
    time: {
        day: "j",
        hour: "h",
        minute: "m",
        second: "s",
        ago : "il y a __time__",
        calculating : "calcule",
        calculating_time: "calcule le temps",
        complete : "Terminée",
        left : "restant",
        less_than_1_minute: "moins d'une m",
        several_hours: "Plusieurs heures...",
        finishing_up: "Finition..."
    },
    accordion : {
        scan : {
            title : "Analyser",
            filevault_configuration_not_supported: "Ce Mac utilise une configuration FileVault qui n'est pas encore prise en charge par __product_name__. Les volumes chiffrés avec FileVault ne seront pas analysés.",
            filevault_need_to_factory_upgrade: "Votre __product_name__ a besoin d'une mise à jour unique et gratuite pour gérer une technologie utilisée par votre Mac (FileVault).<br> S'il vous plaît <a href=\"#\" onclick='return ShowFactoryUpgradeInstructionsSendingModal(\"MAC\");'>cliquez ici</a> pour vous envoyer un courriel sur comment faire la mise à jour, et ensuite lancer une autre analyse.",
            apfs_need_to_factory_upgrade: "Votre __product_name__ a besoin d'une mise à jour unique et gratuite pour gérer une technologie utilisée par votre Mac (APFS).<br> S'il vous plaît <a href=\"#\" onclick='return ShowFactoryUpgradeInstructionsSendingModal(\"MAC\");'>cliquez ici</a> pour vous envoyer un courriel sur comment faire la mise à jour, et ensuite lancer une autre analyse.",
            drive_disconnected: "L'un de vos disques s'est déconnecté pendant l'analyse.",
            status : {
                need_to_run_chk_disk: "Certaines de vos partitions sont dans un état non sécurisé et ne peuvent pas être analysées. Vous devrez exécuter une commande de vérification du disque à partir de Windows. Veuillez visiter 'www.fixmestick.com/run-chkdsk' pour des instructions.",
                at_least_one_partition_read_only: "Windows ne s'est pas éteint complètement. Si possible, quittez __product_name__, redemarrez Windows, et lancez __product_name__ de nouveau.",
                at_least_one_partition_journaled: "Certains volumes sont journalisés et ne peuvent pas être néttoyer. Pour corriger, s'il vous plait allez sur notre site web et mettez votre __product_name__ à jour.",
                encryption_detected: "Certains de vos lecteurs sont verouillés et ne peuvent être analyzés. Pour analyser ces lecteurs,  S'il vous plaît redémarrez __product_name__ à partir de Windows et suivez les instructions.",
                hfs_filevault_detected: "Un ou plusieurs volumes sont cryptés avec une version antérieure d'Apple Filevault et ne peuvent pas être analysés. Veuillez désactiver Filevault de macOs et redémarrer __product_name__ pour analyser ces volumes.",
                apfs_filevault_detected: "Un ou plusieurs volumes sont cryptés avec Apple Filevault.",
                safe: "État de l’ordinateur : Sécurisé.",
                safe_so_far : "État de l’ordinateur : Sécuritaire jusqu’à maintenant. ",
                not_safe : "État de l’ordinateur : À risque. ",
                not_safe_review_when_finished : "Les résultats préliminaires de l’analyse démontrent que certains logiciels malveillants peuvent être présents dans votre système.  Vous pourrez vérifier les éléments détectés lorsque l’analyse sera terminée.",
                safe_all_infections_quarantined : "Toutes les infections ont été mises en quarantaine.",
                throttling_too_hot: "Le PC devient très chaud. L'analyse se ralentit pour éviter la surchauffe.",
                keep_cool_mode: 'Activé mode de refroidissement',
                reduced_functionality:"__product_name__ s'exécute en mode d'économie de ressources.",
                quick_scan:"__product_name__ exécute une analyse rapide."
            },
            no_files_marked_quarantine: 'Aucun fichier n’est marqué “Mis en Quarantaine”.',
            threats_found : "__product_name__ a détecté des menaces potentielles sur votre ordinateur.",
            no_threats_found : "Bonne nouvelle! Aucune menace n’a été détectée sur votre ordinateur pendant l’analyse.",
            scan_complete_message : "L’analyse des __num_items__ éléments accomplis en __time__.",
            button_apply_actions : "Appliquer",
            button_skip_updates: "Ignorer les mises à jour",
            applying_update_packages: "Application de mises à jour. Mise à jour __current_package__ de __total_packages__...",
            engines_init: "__initialized_engines__/__total_engines__ moteurs initialisés...",
            applying_update: "Installation de la mise à jour.  __product_name__ va bientôt redémarrer...",
            toggle_disabled: "L'analyse est actuellement désactivée.",
            details :  {
                switch_virus_scan: "Analyse de virus",
                time: "Temps:",
                time_elapsed : "écoulé",
                time_remaining : "restant",
                scan_progress : "Progrès de l'analyse:",
                file: "fichier",
                file_plural: "fichiers",
                item : "Fichier actuel:",
                infected_files: "Fichiers infectés:",
                none_found: "Rien n'a été trouvé",
                scan_complete: "Analyse terminée:",
                found: "__num_infections__ trouvé(s)",
                removed: "supprimé(s)",
                disabled: "Analyse désactivé"
            },
            results :  {
                scan_results_caption : "Menaces Trouvées",
                cleaning_results_caption : "Résultats du nettoyage",
                file : "Fichier",
                file_size: "Taille du fichier",
                last_modified: "Dernière modification",
                threats : "Menaces",
                action : "Action",
                result : "Résultat",
                cleaning_state: {
                    ignored: "Supprimation échouée",
                    disconnected:"Disque déconnecté",
                    quarantined: "Mis en quarantaine",
                    disinfected: "Désinfecté",
                    manual_clean: "Doivent être nettoyés manuellement.<br><a href='' onclick='ShowManualCleanModal();'>Instructions.</a>"
                }
            },
            steps : {
                checking_internet_connection : "Vérification<BR>de la connexion<BR>internet",
                checking_for_product_updates: "Vérification de la<BR>mise à jour<BR> __product_name__",
                updating_malware_definition : "Mise à jour des<BR>définitions des<BR>logiciels malveillants",
                initializing_malware_scanners : "Initialisation des<BR>analyses de<BR>logiciels malveillants",
                scanning_computer : "Traitement des fichiers",
                results : "Complété",
            },
        },
        undo : {
            title : "Annuler la quarantaine",
            success : "<B>La quarantaine a été correctement défait!</B>  Tous les fichiers ont été restaurés à leur emplacement d’origine.",
            partial : "<B> La quarantaine a été partiellement annulée. </B> Certains fichiers n'ont pas été restaurés.",
            item_success: "<B>__quarantined_item__</B> a été restauré sur votre ordinateur.",
            no_quarantines : "Utilisez la commande “Défaire” pour restaurer des fichiers à partir d’une analyse particulière, si vous croyez que les fichiers supprimés ont causé des problèmes dans votre ordinateur..<BR><BR><B>Il n’y a pas d’éléments dans la quarantaine __product_name__.</B>",
            some_quarantines : "Utilisez la commande “Défaire” pour restaurer des fichiers à partir d’une analyse particulière, si vous croyez que les fichiers supprimés ont causé des erreurs sur votre ordinateur.",
            table : {
                caption : "Sessions d’analyse",
                col_date : "Date",
                col_items : "Éléments",
                col_action : "Action",
                button_undo : "Défaire",
                button_undo_item: "Défaire item"
            }
        },
        custom : {
            title : "Analyse de virus",
            button_apply : "Appliquer",
            select_folders_scan : "Sélectionnez les disques et les dossiers que vous voulez analyzer:",
            select_folders_backup : "Sélectionnez les disques et les dossiers que vous voulez sauvegarder:",
            select_at_least_one_folder : "Veullez sélectionner au moins un dossier.",
            save: "Save this selection for future scans on this computer"
        },
        quick: {
            title: "Analyse rapide",
            switch: "Analyse rapide: scannez uniquement les emplacements de virus les plus courants",
            message: "Pressé? L'analyse rapide vérifie les endroits où les menaces se cachent le plus souvent.",
            in_progress_message: "L'analyse rapide est en cours ...",
            no_file: "<B>Pour obtenir les meilleurs résultats avec l'analyse rapide, quittez __product_name__, redémarrez votre ordinateur et lancez une autre analyse en double-cliquant sur __product_name__.exe. Cela permettra à __product_name__ de recueillir des informations supplémentaires sur les menaces actives sur votre ordinateur. </ B>",
            button: "Démarrez l'analyse rapide"
        },
        backup: {
            title: "Sauvegarde de fichiers",
            insufficient_space: "Il n'y a pas assez d'espace sur le FixMeStick pour terminer votre sauvegarde. <a href=\"#\" onclick='return ShowBackupSettings();'> Cliquez ici </a> pour modifier la sélection du fichier de sauvegarde.",
            empty_folder_selection: "Impossible de trouver le répertoire par défaut à sauvegarder. Veuillez sélectionner les répertoires de l'explorateur de fichiers dans les paramètres.",
            customize: "<a href='' onclick='ShowBackupModal();'> Personnaliser. </a>",
            files: "fichiers",
            cancel_backup: "Annuler sauvegarde",
            close_backup : "Fermer",
            toggle_disabled: "La sauvegarde est actuellement désactivée.",
            details: {
                switch_backup: "Sauvegarde de fichiers",
                current_item: "Fichier actuel:",
                backup_progress: "Progrès de la sauvegarde:",
                backup_complete: "Sauvegarde terminée:",
                space_available: "Espace de sauvegarde:",
                tooltip: "<strong>File Backup</strong> </br>Files are scanned and clean files are copied to the FixMeStick. </br>To see your backed up files in Windows: when the Scan and Backup is Complete, exit the FixMeStick and return to Windows and find the Backup directory on the FixMeStick drive."
            },
            status: {
                up_to_date: "Sauvegarde à jour",
                backup_incomplete: "Sauvegarde partiellement terminée",
                no_room: "Aucun espace disponible",
                backup_complete: "Sauvegarde terminée",
                finding_files: "Recherche...",
                unknown: "Inconnu"
            },
            settings: {
                description: "Select the types of files to backup from within the drives and folders selected above",
                video: "Vidéo",
                music: "Musique",
                images: "Images",
                documents: "Documents",
                other: "Autre",
                save: "Save this selection for future backups on this computer"
            },
            results: {
                title: "Détails de la sauvegarde",
                message: "Sauvegarde de __size__ accomplie en __time__.",
                table_header: "Répartition par type:",
                video: "Vidéo",
                music: "Musique",
                images: "Images",
                documents: "Documents",
                other: "Autre"
            },
            fragments: {
                used: "utilisé"
            },
        },
        language: {
            title: "Langue",
            display: "Afficher",
            keyboard: "Clavier"
        },
        optionssettings: {
            title: "Options"
        },
        recprograms: {
            sidebar_title: "Programmes de<br> sécurité recommandés",
            title: "Programmes de sécurité recommandés",
            description:"__product_name__ recommande ces programmes de sécurité et a organisé des remises exclusives aux clients de __product_name__. Ce sont les produits de sécurité que nous utilisons dans __product_name__ sur les ordinateurs de bureau et personnels.",
            get_discount: "Obtenez un rabais",
            startmestick: "Donnez une nouvelle vie sécurisée aux vieux ordinateurs",
            system_mechanic: "Boostez les performances du PC",
            mcafee: "Prévenir les infections",
            nord_vpn: "Sécurité des réseaux privés virtuels"
        },
        account: {
            title: "Compte",
            serial_number: "Numéro de série",
            registered_to: "Enregistré à",
            license: "License",
            used_so_far: "Utilisé sur",
            expires: "Expiration",
            renews: "Renouvelle",
            computers: "ordinateurs",
            computer: "ordinateur",
            this_month: "ce mois.",
            change: "Modifier",
            register: "Enregistrer",
            button_add_computers: "Utilisez sur plus d'ordinateurs",
            subscribe_to_save: "Abonnez pour escompter",
            backend_error: "Les serveurs de FixMeStick ne répondent pas. Pour accéder à votre compte, réessayez dans quelques minutes.",
            no_connectivity: "Votre FixMeStick est hors ligne et ne peut donc pas accéder à votre compte. Si vous pouvez vous connecter à Internet, vous pourrez accéder à votre compte.",
            not_registered: "Votre FixMeStick n'est pas enregistré. <a href=\"#\" onclick=\"registerLink()\">Enregistrez-vous pour voir l'informations d'abonnement</a>."
        }
    },
    scan_report: {
        header: "Rapport d'analyse",
        summary: {
            header: "Résumé de l'analyse:",
            scan_type: "Type d'analyse: ",
            computer_name: "Nom de l'ordinateur: ",
            start_time: "Temps de balayage: ",
            duration: "Durée: ",
            app_version: "Version du logiciel: ",
            live_os_version: "Version du LiveOs: ",
            num_files_scanned: "Nombre total de fichiers analysés: ",
            num_malware_files: "Fichiers infectés: ",
            num_vulnerabilities: "Vulnérabilités Totales: "
        },
        definitions: {
            header: "Versions de définition de moteur:",
            definition: "Version DB: ",
            last_updated: "Dernière mise à jour: "
        },
        threats: {
            header_infections: "Rapport de menace:",
            header_vulnerabilities: "Vulnérabilités:",
            index: "#",
            filename: "Nom de fichier",
            size: "Taille du fichier",
            modified: "Dernière modification",
            threats: "Menaces"
        }
    },
    scan: "analyse",
    backup: "sauvegarde",
    button_continue_scan_only: "Continuer",
    button_exit_scan : "Quitter __product_name__",
    button_see_results : "Voir les détails",
    button_ok : "OK",
    button_cancel : "Annuler",
    button_default : "Restaurer les paramètres",
    button_renew: "Renouvellement Express",
    button_retry : "Réessayer",
    button_send_email: "Envoyer un e-mail",
    button_close: "Fermer",
    read_only_ttip: "Pour activer cette fonction, veuillez désengager le verrouillage physique FixMeStick et redémarrer FixMeStick.",
    undoing_quarantine : "Défaire la quarantaine..",
    mounting_disks : "L'examen de vos disques durs. S'il vous plaît patienter quelques instants...",
    jqgrid : {
        recordtext: "Enregistrements {0} - {1} sur {2}",
        emptyrecords: "Aucun enregistrement à afficher",
        loadtext: "Chargement...",
        pgtext : "Page {0} sur {1}"
    }
}

if (GetExternal().IsLocaleSupportedByUi(fr.locale))
{
    arrLocalizedStrings.push(fr);
}
